package serverGUI;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Represents information about a connected client in the server GUI. This model
 * class is used for displaying client details in a JavaFX TableView.
 * <p>
 * It includes the client's host name, IP address, and connection status.
 */
public class ClientConnInfo {
	/** The host name of the connected client. */
	private final StringProperty hostName;
	/** The IP address of the connected client. */
	private final StringProperty ipAddress;
	/** The connection status (e.g., "Connected", "Disconnected") of the client. */
	private final StringProperty status;

	/**
	 * Constructs a new ClientConnInfo object with specified details.
	 *
	 * @param hostName  the host name of the client
	 * @param ipAddress the IP address of the client
	 * @param status    the connection status of the client
	 */
	public ClientConnInfo(String hostName, String ipAddress, String status) {
		this.hostName = new SimpleStringProperty(hostName);
		this.ipAddress = new SimpleStringProperty(ipAddress);
		this.status = new SimpleStringProperty(status);
	}

	/**
	 * Returns the JavaFX property for the host name, enabling TableView binding.
	 *
	 * @return the hostName property
	 */
	// Property getters
	@SuppressWarnings("exports")
	public StringProperty hostNameProperty() {
		return hostName;
	}

	/**
	 * Returns the JavaFX property for the IP address, enabling TableView binding.
	 *
	 * @return the ipAddress property
	 */
	@SuppressWarnings("exports")
	public StringProperty ipAddressProperty() {
		return ipAddress;
	}

	/**
	 * Returns the JavaFX property for the connection status, enabling TableView
	 * binding.
	 *
	 * @return the status property
	 */
	@SuppressWarnings("exports")
	public StringProperty statusProperty() {
		return status;
	}

	/**
	 * Gets the host name of the client.
	 *
	 * @return the host name as a String
	 */
	public String getHostName() {
		return hostName.get();
	}

	/**
	 * Gets the IP address of the client.
	 *
	 * @return the IP address as a String
	 */
	public String getIpAddress() {
		return ipAddress.get();
	}

	/**
	 * Gets the current connection status of the client.
	 *
	 * @return the status as a String
	 */
	public String getStatus() {
		return status.get();
	}

	/**
	 * Sets the connection status of the client.
	 *
	 * @param status the new status value to set
	 */
	public void setStatus(String status) {
		this.status.set(status);
	}
}