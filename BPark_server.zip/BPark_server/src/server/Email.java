package server;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

/**
 * The Email class handles sending emails via Gmail SMTP. It is used to notify
 * BPark users with confirmations, codes, or general information.
 *
 * Example usage:
 * 
 * <pre>
 * Email.sendInfEmail("user@example.com", "Subject", "Message body");
 * </pre>
 */

public class Email {

	/**
	 * The system email address used to send messages.
	 */
	private final String fromEmail = "projectbpark@gmail.com";
	/**
	 * The app-specific password for authenticating with Gmail SMTP.
	 */
	private final String password = "hsgg ejuu mfdu vfef"; // app password

	/**
	 * Sends an email to a specific recipient with the given subject and body.
	 *
	 * @param toEmail The recipient's email address.
	 * @param subject The subject line of the email.
	 * @param body    The text content of the email.
	 */
	public void sendEmail(String toEmail, String subject, String body) {
		Properties properties = new Properties();
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.port", "587");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.ssl.trust", "smtp.gmail.com");

		Session session = Session.getInstance(properties, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmail, password);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromEmail));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
			message.setSubject(subject);
			message.setText(body);

			Transport.send(message);
			System.out.println("Email sent successfully to " + toEmail);

		} catch (MessagingException e) {
			e.printStackTrace();
			System.err.println("Error sending email: " + e.getMessage());
		}
	}

	/**
	 * A static helper method to send an informational email without needing to
	 * instantiate Email.
	 *
	 * @param newToEmail The recipient's email address.
	 * @param newSubject The subject of the email.
	 * @param newBody    The body of the email.
	 */

	public static void sendInfEmail(String newToEmail, String newSubject, String newBody) {
		Email emailSender = new Email();
		String toEmail = newToEmail; // recipient
		String subject = newSubject;
		String body = newBody;

		emailSender.sendEmail(toEmail, subject, body);
	}
}
