package server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.time.LocalDateTime; // Needed for parsing orderPlacementDateTimeStr
import java.time.format.DateTimeFormatter;
import javafx.application.Platform;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;
import serverGUI.ClientConnInfo;
import serverGUI.ServerGUIController;
import java.util.*;
import java.util.Random;

/**
 * BParkServer is the main server class for the Braude BPark system. It extends
 * AbstractServer from OCSF and manages client connections, request handling,
 * and communication with the MySQL database.
 *
 * Features: - Handles multiple concurrent client connections. - Supports a
 * range of client requests (login, order management, parking availability). -
 * Manages server-side logic with a message handler map for clear routing. -
 * Integrates with a MySQL database for persistent storage. - Provides real-time
 * status updates to a JavaFX GUI for server monitoring.
 *
 * Example usage: BParkServer server = new BParkServer(port, dbName, dbUser,
 * dbPassword); server.listen();
 *
 * Author: [G7]
 * 
 */

public class BParkServer extends AbstractServer {
	public static final int DEFAULT_PORT = 5555;
	// Declare a semaphore to ensure only one thread runs for seding an email for
	// the inparking orders
	private static final Semaphore inparkingLock = new Semaphore(1);
	// Declare a semaphore to ensure only one thread runs for seding an email for
	// the active orders
	private static final Semaphore activeOrderLock = new Semaphore(1);

	private static final String DB_URL = "jdbc:mysql://localhost:3306/";

	private BiConsumer<String, String> clientDetailsCallback;

	private final Map<String, ClientConnInfo> activeClients = new ConcurrentHashMap<>();

	private Map<String, Function<String[], String[]>> messageHandlers = new HashMap<>();

	@SuppressWarnings("unused")
	private Runnable clientDisconnectionCallback;

	private static Connection conn = null;

	/**
	 * Creates a new BParkServer instance on the given port.
	 * 
	 * @param port The port number to listen on.
	 */
	public BParkServer(int port) {
		super(port);
	}

	/**
	 * Creates a new BParkServer with database connection details.
	 * 
	 * @param port       The port number to listen on.
	 * @param dbName     The database name.
	 * @param dbUser     The database user.
	 * @param dbPassword The database password.
	 */
	public BParkServer(int port, String dbName, String dbUser, String dbPassword) {
		super(port);
		String fullDBUrl = DB_URL + dbName + "?serverTimezone=Asia/Jerusalem&useLegacyDatetimeCode=false";
		initializeMessageHandlers();
		try {
			conn = DriverManager.getConnection(fullDBUrl, dbUser, dbPassword);
		} catch (SQLException e) {
			System.out.println("Database connection failed: " + e.getMessage());
		}
	}

	/**
	 * Sets the callback to handle client connection details when a client connects.
	 * 
	 * @param callback A BiConsumer taking host and IP address.
	 */
	public void setClientDetailsCallback(BiConsumer<String, String> callback) {
		this.clientDetailsCallback = callback;
	}

	/**
	 * Sets the callback to run when a client disconnects.
	 * 
	 * @param callback A Runnable to execute on client disconnection.
	 */
	public void setClientDisconnectionCallback(Runnable callback) {
		this.clientDisconnectionCallback = callback;
	}

	/**
	 * Called when a client connects to the server. Registers client details and
	 * invokes the connection callback.
	 * 
	 * @param client The client connection.
	 */
	protected void clientConnected(ConnectionToClient client) {
		super.clientConnected(client);
		String ip = client.getInetAddress().getHostAddress();
		String host = client.getInetAddress().getCanonicalHostName();

		if (clientDetailsCallback != null) {
			clientDetailsCallback.accept(host, ip);
		}
	}

	/**
	 * Called when a client disconnects from the server. Updates internal client map
	 * and GUI with the disconnected status.
	 * 
	 * @param client The client connection.
	 */
	protected void clientDisconnected(ConnectionToClient client) {
		String ip = client.getInetAddress().getHostAddress();
		String host = client.getInetAddress().getHostName();
		// Update both internal map and GUI
		Platform.runLater(() -> {
			// 1. Update activeClients map
			ClientConnInfo info = activeClients.get(ip);
			if (info != null) {
				info.setStatus("Disconnected");
			} else {
				info = new ClientConnInfo(host, ip, "Disconnected");
				activeClients.put(ip, info);
			}

			// 2. Update GUI table via controller
			ServerGUIController controller = ServerGUIController.getInstance();
			if (controller != null) {
				controller.updateClientDisconnectionDetails(client);
			}
		});

		super.clientDisconnected(client);
	}

	/**
	 * Initializes the messageHandlers map with supported request types and their
	 * corresponding handler functions.
	 */
	private void initializeMessageHandlers() {
		messageHandlers.put("login", msg -> checkUserNumberIfExist(msg[1], msg[2]));
		messageHandlers.put("updateEmail", msg -> updateEmail(msg[1], msg[2], msg[3]));
		messageHandlers.put("updatePhoneNumber", msg -> updatePhoneNumber(msg[1], msg[2], msg[3]));
		messageHandlers.put("updatePassword", msg -> updatePassword(msg[1], msg[2], msg[3]));
		messageHandlers.put("showOrders", msg -> showOrders(msg[1], msg[2]));
		messageHandlers.put("cancelOrder", msg -> cancelOrder(msg[1], msg[2]));
		messageHandlers.put("receiveCar", msg -> ReceiveCar(msg[1], msg[2]));
		messageHandlers.put("sendParkingCodeViaEmail", this::handleSendParkingCode);
		messageHandlers.put("requestExtesnsion", this::handleRequestExtension);
		messageHandlers.put("viewParkings", msg -> getAllParkings(msg[1]));
		messageHandlers.put("addNewSubscriber", this::AddNewSubscriber);
		messageHandlers.put("ViewSubscriberDetails", msg -> ViewSubscriberDetails(msg[1], msg[2]));
		messageHandlers.put("AddParkings", msg -> HandleAddParkings(msg[1]));
		messageHandlers.put("reports", msg -> handleShowReports(msg[1], msg[2]));
		messageHandlers.put("addNewOrder", this::addNewOrder);
		messageHandlers.put("createImmediateOrder", this::addNewOrder);
		messageHandlers.put("checkAvailability", this::handleCheckAvailability);
		messageHandlers.put("checkAvailablityNow", this::handleCheckAvailablityNow);
		messageHandlers.put("depositeCar", this::handleDepositeCar);
		messageHandlers.put("viewUsersFromDB", this::handleShowUsers);
	}

	/**
	 * Handles incoming messages from clients. Supports special "Connect" and
	 * "DisConnect" strings, and dispatches String[] commands to their appropriate
	 * handlers.
	 *
	 * @param msg    The message received from the client. Can be a String or
	 *               String[].
	 * @param client The ConnectionToClient object representing the client.
	 */
	public void handleMessageFromClient(Object msg, @SuppressWarnings("exports") ConnectionToClient client) {
		try {
			if ("DisConnect".equals(msg)) {
				clientDisconnected(client);
			} else if ("Connect".equals(msg)) {
				clientConnected(client);
			} else if (msg instanceof String[]) {
				String[] message = (String[]) msg;
				String command = message[0];

				Function<String[], String[]> handler = messageHandlers.get(command);
				if (handler != null) {
					String[] response = handler.apply(message);
					client.sendToClient(response);
				} else {
					System.out.println("⚠️ No handler found for: " + command);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("❌ Error handling message from client.");
		}
	}

//	@SuppressWarnings("exports")
//	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
//		if ("DisConnect".equals(msg)) {
//			// Handle graceful disconnect
//			clientDisconnected(client);
//			return;
//		} else if ("Connect".equals(msg)) {
//			clientConnected(client);
//		} else {
//			String[] message = (String[]) msg;
//			try {
//				if (message[0].equals("login"))
//					client.sendToClient(checkUsernameIfExist(message[1], message[2]));
//				else if (message[0].equals("updateEmail"))
//					client.sendToClient(updateEmail(message[1], message[2], message[3]));
//				else if (message[0].equals("updatePhoneNumber"))
//					client.sendToClient(updatePhoneNumber(message[1], message[2], message[3]));
//				else if (message[0].equals("updatePassword"))
//					client.sendToClient(updatePassword(message[1], message[2], message[3]));
//				else if (message[0].equals("showOrders"))
//					client.sendToClient(showOrders(message[1], message[2]));
//				else if (message[0].equals("cancelOrder"))
//					client.sendToClient(cancelOrder(message[1], message[2]));
//				else if (message[0].equals("receiveCar"))
//					client.sendToClient(ReceiveCar(message[1], message[2]));
//				else if (message[0].equals("sendParkingCodeViaEmail"))
//					client.sendToClient(handleSendParkingCode(message));
//				else if (message[0].equals("requestExtesnsion"))
//					client.sendToClient(handleRequestExtension(message));
//				else if (message[0].equals("viewParkings"))
//					client.sendToClient(getAllParkings(message[1]));
//				else if (message[0].equals("addNewSubscriber"))
//					client.sendToClient(AddNewSubscriber(message));
//				else if (message[0].equals("ViewSubscriberDetails"))
//					client.sendToClient(ViewSubscriberDetails(message[1], message[2]));
//				else if (message[0].equals("AddParkings"))
//					client.sendToClient(HandleAddParkings(message[1]));
//				else if (message[0].equals("reports"))
//					client.sendToClient(handleShowReports(message[1], message[2]));
//				else if (message[0].equals("addNewOrder") || message[0].equals("createImmediateOrder"))
//					client.sendToClient(addNewOrder(message));
//				else if (message[0].equals("checkAvailability"))
//					client.sendToClient(handleCheckAvailability(message));
//				else if (message[0].equals("checkAvailablityNow"))
//					client.sendToClient(handleCheckAvailablityNow(message));
//				else if (message[0].equals("depositeCar"))
//					client.sendToClient(handleDepositeCar(message));
//				else if (message[0].equals("viewUsersFromDB"))
//					client.sendToClient(handleShowUsers(message));
//
//			} catch (Exception e) {
//			}
//		}
//	}
	/**
	 * Handles the request to retrieve counts of active and inactive users from the
	 * database.
	 *
	 * @param msg The received message array. Expected format: [ "viewUsersFromDB",
	 *            ... ]
	 * @return A String array containing the command and the counts: [command,
	 *         activeCount, inactiveCount].
	 */
	private String[] handleShowUsers(String[] msg) {
		String[] toReturn = new String[3];
		toReturn[0] = msg[0];

		int active = 0;
		int inactive = 0;

		try {
			String query = "SELECT subscriber_status FROM subscribers";
			PreparedStatement ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String status = rs.getString("subscriber_status");
				if ("active".equalsIgnoreCase(status)) {
					active++;
				} else if ("inactive".equalsIgnoreCase(status)) {
					inactive++;
				}
			}

			toReturn[1] = String.valueOf(active);
			toReturn[2] = String.valueOf(inactive);

		} catch (SQLException e) {
			e.printStackTrace();
			toReturn[1] = "error: database query failed";
			toReturn[2] = "";
		}

		return toReturn;
	}

	/**
	 * Handles the deposit car request. Validates arrival time constraints, updates
	 * order status to 'inparking', updates parking status to 'taken', and logs
	 * arrival in the daily report.
	 *
	 * @param msg The received message array. Expected format: [ "depositeCar",
	 *            username, orderNumber ].
	 * @return A String array with the command and a status message indicating
	 *         success or failure.
	 */
	private String[] handleDepositeCar(String[] msg) {
		String username = msg[1];
		String orderNumber = msg[2];
		String id = getId(username);

		String[] toReturn = new String[2];
		toReturn[0] = msg[0];

		try {
			if (!isArrivalTimeWithinAllowedWindow(orderNumber, id)) {
				toReturn[1] = "❌ Deposit denied. Your arrival time must be today and within the next 10 minutes.";
				return toReturn;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			toReturn[1] = "❌ SQL Error during deposit.";
			return toReturn;
		}
		try {
			// Step 1: Update order status to 'inparking'
			String updateOrder = "UPDATE `order` SET order_status = 'inparking' WHERE order_number = ? AND user_id = ?";
			PreparedStatement psOrder = conn.prepareStatement(updateOrder);
			psOrder.setString(1, orderNumber);
			psOrder.setString(2, id);
			int orderRows = psOrder.executeUpdate();

			if (orderRows < 1) {
				toReturn[1] = "Failed to enter the parking";
				return toReturn;
			}

			// Step 2: Update parking status to 'taken'
			String updateParking = """
					    UPDATE parking SET parking_status = 'taken'
					    WHERE parking_number = (
					        SELECT parking_number FROM `order`
					        WHERE order_number = ? AND user_id = ?
					    )
					""";
			PreparedStatement psParking = conn.prepareStatement(updateParking);
			psParking.setString(1, orderNumber);
			psParking.setString(2, id);
			int parkingRows = psParking.executeUpdate();

			if (parkingRows > 0) {
				toReturn[1] = "Deposit successful. Car is now parked.";
				updateActualArrivalTime(orderNumber);
				update_dailyReport_OrdersCnt();
			} else {
				toReturn[1] = "❌ Failed to deposit car. Parking not found.";
			}

		} catch (SQLException e) {
			e.printStackTrace();
			toReturn[1] = "❌ SQL Error during deposit.";
		}

		return toReturn;
	}

	/**
	 * Checks whether the arrival time for a given order is within an allowed time
	 * window. The allowed window is 5 minutes before to 15 minutes after the
	 * scheduled time.
	 *
	 * @param orderNumber The order number to check.
	 * @param userId      The user ID associated with the order.
	 * @return true if current time is within the allowed window, false otherwise.
	 * @throws SQLException if a database error occurs during the query.
	 */
	private boolean isArrivalTimeWithinAllowedWindow(String orderNumber, String userId) throws SQLException {
		String query = """
				    SELECT scheduled_date, scheduled_time_arrive
				    FROM `order`
				    WHERE order_number = ? AND user_id = ?
				""";

		try (PreparedStatement ps = conn.prepareStatement(query)) {
			ps.setString(1, orderNumber);
			ps.setString(2, userId);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				LocalDate scheduledDate = rs.getDate("scheduled_date").toLocalDate();
				LocalTime scheduledTime = rs.getTime("scheduled_time_arrive").toLocalTime();
				LocalDateTime scheduledDateTime = LocalDateTime.of(scheduledDate, scheduledTime);
				LocalDateTime now = LocalDateTime.now();

				// Create window: -5 minutes to +15 minutes
				LocalDateTime earliestAllowed = scheduledDateTime.minusMinutes(5);
				LocalDateTime latestAllowed = scheduledDateTime.plusMinutes(15);

				return !now.isBefore(earliestAllowed) && !now.isAfter(latestAllowed);
			}
		}

		return false;
	}

	/**
	 * Updates the actual_arrive_time field for the specified order to the current
	 * server time.
	 *
	 * @param orderNumber The order number whose arrival time should be updated.
	 */

	private void updateActualArrivalTime(String orderNumber) {
		String sql = "UPDATE `order` SET actual_arrive_time = CURTIME() WHERE order_number = ?";

		try (PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, orderNumber);
			int rowsAffected = ps.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("✅ Actual arrival time updated successfully for order " + orderNumber);
			} else {
				System.out.println("⚠️ No matching order found or update failed.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("❌ Error updating actual arrival time.");
		}
	}

	/**
	 * Updates the actual_leave_time field for the specified order to the current
	 * server time.
	 *
	 * @param orderNumber The order number whose leave time should be updated.
	 */
	private void updateActualLeaveTime(String orderNumber) {
		String sql = "UPDATE `order` SET actual_leave_time = CURTIME() WHERE order_number = ?";

		try (PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, orderNumber);
			int rowsAffected = ps.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("✅ Actual leave time updated successfully for order " + orderNumber);
			} else {
				System.out.println("⚠️ No matching order found or update failed.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("❌ Error updating actual leave time.");
		}
	}

	/**
	 * Handles immediate availability check for parking spaces between specified
	 * times on a given date. Returns "AVAILABLE" if at least one parking spot is
	 * free, or "FULL" otherwise.
	 *
	 * @param msg Expected format: [ "checkAvailablityNow", username, date,
	 *            startTime, endTime ].
	 * @return Response message array with availability status.
	 */
	private String[] handleCheckAvailablityNow(String[] msg) {
		String date = msg[2];
		String startTime = msg[3];
		String endTime = msg[4];
		List<String> availableParkings = new ArrayList<>();

		try {
			String query = """
					    SELECT parking_number
					    FROM parking
					    WHERE parking_number NOT IN (
					        SELECT parking_number
					        FROM `order`
					        WHERE scheduled_date = ?
					          AND (
					            (scheduled_time_arrive >= ? AND scheduled_time_arrive < ?)
					            OR (scheduled_time_leave > ? AND scheduled_time_leave <= ?)
					          )
					          AND order_status IN ('active', 'inparking')
					    )
					""";

			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, date);
			ps.setString(2, startTime);
			ps.setString(3, endTime);
			ps.setString(4, startTime);
			ps.setString(5, endTime);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				availableParkings.add(rs.getString("parking_number"));
			}

			if (!availableParkings.isEmpty()) {
				return new String[] { msg[0], "AVAILABLE" };
			} else {
				return new String[] { msg[0], "FULL" };
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return new String[] { msg[0], "❌ Error checking availability: " + e.getMessage() };
		}
	}

	/**
	 * Adds a new order to the system, reserving a parking spot if available. Sends
	 * a confirmation email with order details if successful.
	 *
	 * @param msg Expected format: [ "addNewOrder" or "createImmediateOrder",
	 *            scheduledDate, scheduledTimeArrive, scheduledTimeLeave, username,
	 *            confirmationCode, receiveCode ].
	 * @return Response message array indicating success or failure.
	 */
	private String[] addNewOrder(String[] msg) {
		String scheduledDate = msg[1];
		String scheduledTimeArrive = msg[2];
		String scheduledTimeLeave = msg[3];
		String username = msg[4];
		String confirmationCode = msg[5];
		String receiveCode = msg[6];
		String userId = getId(username);

		// Get current date and time for order_date and order_time
		LocalDateTime now = LocalDateTime.now();
		String orderDate = now.toLocalDate().toString();
		String orderTime = now.toLocalTime().toString().substring(0, 8); // HH:mm:ss
		try {
			String insertQuery = """
					    INSERT INTO `order`
					        (user_id, order_date, order_time, scheduled_date, scheduled_time_arrive, scheduled_time_leave,
					         parking_number, confirmation_code, receive_code, order_status)
					    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
					""";
			PreparedStatement psInsert = conn.prepareStatement(insertQuery);
			psInsert.setInt(1, Integer.parseInt(userId));
			psInsert.setString(2, orderDate);
			psInsert.setString(3, orderTime);
			psInsert.setString(4, scheduledDate);
			psInsert.setString(5, scheduledTimeArrive);
			psInsert.setString(6, scheduledTimeLeave);
			int parking_number = getAvailabelParkingNumber(scheduledDate, scheduledTimeArrive, scheduledTimeLeave);
			if (parking_number == -1) {
				return new String[] { msg[0], "Failed to insert order." };
			}
			psInsert.setInt(7, parking_number);
			psInsert.setInt(8, Integer.parseInt(confirmationCode));
			psInsert.setInt(9, Integer.parseInt(receiveCode));
			psInsert.setString(10, "active");
			int rows = psInsert.executeUpdate();
			if (rows > 0) {
				String subject = "BPark-new Order";
				String body = "Thanks for choosing to Park in Braude BPark\nYour Order Confirmation Number is: "
						+ confirmationCode + "\nYour Order Receive code is: " + receiveCode + " for the order: "
						+ getOrderNumber(confirmationCode, userId);
				Email.sendInfEmail(getEmail(username), subject, body);
				update_dailyReport_newOrder();
				return new String[] { msg[0],
						"Order added successfully. an email & SMS with the details was sent to your registered email address" };
			} else {
				return new String[] { msg[0], "Failed to insert order." };
			}

		} catch (Exception e) {
			e.printStackTrace();
			return new String[] { "❌ Error: " + e.getMessage() };
		}
	}

	/**
	 * Retrieves the order number for a given confirmation code and user ID.
	 *
	 * @param confirmation The confirmation code.
	 * @param id           The user ID.
	 * @return The order number if found, or null otherwise.
	 */
	private String getOrderNumber(String confirmation, String id) {
		String orderNumber = null;
		String query = "SELECT order_number FROM `order` WHERE confirmation_code = ? AND user_id = ?";

		try (PreparedStatement ps = conn.prepareStatement(query)) {
			ps.setString(1, confirmation);
			ps.setString(2, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				orderNumber = rs.getString("order_number");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return orderNumber;
	}

	/**
	 * Finds an available parking number for a given date and time window.
	 *
	 * @param date  The scheduled parking date.
	 * @param start The desired start time.
	 * @param end   The desired end time.
	 * @return A random available parking number, or -1 if none found.
	 */
	private int getAvailabelParkingNumber(String date, String start, String end) {
		List<Integer> availableParkings = new ArrayList<>();
		try {
			// Count overlapping orders
			String query = """
					    SELECT parking_number
					    FROM parking
					    WHERE parking_number NOT IN (
					        SELECT parking_number
					        FROM `order`
					        WHERE scheduled_date = ?
					          AND (
					             (scheduled_time_arrive >= ? AND scheduled_time_arrive < ?) -- arriving during interval
					      OR (scheduled_time_leave > ? AND scheduled_time_leave <= ?)   -- leaving during interval
					          )
					          AND order_status IN ('active', 'inparking')
					    )
					""";

			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, date); // Date
			ps.setString(2, start); // arrival >= start
			ps.setString(3, end); // arrival < end
			ps.setString(4, start); // leave > start
			ps.setString(5, end); // leave <= end

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				availableParkings.add(rs.getInt("parking_number"));
			}

			if (!availableParkings.isEmpty()) {
				Random random = new Random();
				return availableParkings.get(random.nextInt(availableParkings.size()));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return -1; // No available parking found
	}

	/**
	 * Handles checking general parking availability for a future order. Calculates
	 * the occupancy ratio for the time window and returns availability status.
	 *
	 * @param msg Expected format: [ "checkAvailability", scheduledDate, startTime,
	 *            endTime ].
	 * @return Response message array indicating whether the order can be placed.
	 */
	private String[] handleCheckAvailability(String[] msg) {
		String scheduledDate = msg[1];
		String startTime = msg[2];
		String endTime = msg[3];

		int overlappingOrders = 0;
		int totalParkings = 0;

		try {
			// Count overlapping orders
			String overlapQuery = """
					    SELECT COUNT(*) FROM `order`
					    WHERE scheduled_date = ?
					      AND (
					           (scheduled_time_arrive >= ? AND scheduled_time_arrive < ?) -- arriving during interval
					        OR (scheduled_time_leave > ? AND scheduled_time_leave <= ?)   -- leaving during interval
					      )
					      AND order_status IN ('active', 'inparking')
					""";

			PreparedStatement psOverlap = conn.prepareStatement(overlapQuery);
			psOverlap.setString(1, scheduledDate); // Date
			psOverlap.setString(2, startTime); // arrival >= start
			psOverlap.setString(3, endTime); // arrival < end
			psOverlap.setString(4, startTime); // leave > start
			psOverlap.setString(5, endTime); // leave <= end

			ResultSet rsOverlap = psOverlap.executeQuery();
			if (rsOverlap.next()) {
				overlappingOrders = rsOverlap.getInt(1);
			}

			// Count total parking spots
			String totalParkingQuery = "SELECT COUNT(*) FROM parking";
			PreparedStatement psParking = conn.prepareStatement(totalParkingQuery);
			ResultSet rsParking = psParking.executeQuery();
			if (rsParking.next()) {
				totalParkings = rsParking.getInt(1);
			}

			psOverlap.close();
			psParking.close();

			// Calculate threshold
			double occupancy = (double) overlappingOrders / totalParkings;
			if (occupancy < 0.6) {
				return new String[] { "checkAvailability", "Order can be placed" };
			} else {
				return new String[] { "checkAvailability", "Order could not be placed. Not enough availability." };
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return new String[] { "checkAvailability", "Server error occurred while checking availability." };
		}
	}

	/**
	 * Generates a report of aggregated parking statistics for a given date range.
	 * It sums new orders, total orders, extensions, cancellations, and parked time
	 * (converted to HH:MM:SS).
	 *
	 * @param fromDate The start date of the reporting period (inclusive).
	 * @param toDate   The end date of the reporting period (inclusive).
	 * @return A String array containing: [0] - "reports" [1] - "orders_cnt:<total>"
	 *         [2] - "extension_cnt:<total>" [3] - "cancel_cnt:<total>" [4] -
	 *         "new_order_cnt:<total>" [5] - "parked_time:<HH:MM:SS>" or error
	 *         messages.
	 */
	private String[] handleShowReports(String fromDate, String toDate) {
		String[] toReturn = new String[6];
		toReturn[0] = "reports";

		String query = "SELECT new_order_cnt, orders_cnt, extension_cnt, cancel_cnt, hours_parked, mins_parked, seconds_parked FROM daily_report WHERE date_of_day BETWEEN ? AND ?";

		int ordersSum = 0;
		int extensionsSum = 0;
		int cancelsSum = 0;
		int newOrdersSum = 0;
		long totalParkedSeconds = 0;

		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setDate(1, Date.valueOf(fromDate));
			stmt.setDate(2, Date.valueOf(toDate));
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				ordersSum += rs.getInt("orders_cnt");
				extensionsSum += rs.getInt("extension_cnt");
				cancelsSum += rs.getInt("cancel_cnt");
				newOrdersSum += rs.getInt("new_order_cnt");

				int hours = rs.getInt("hours_parked");
				int mins = rs.getInt("mins_parked");
				int secs = rs.getInt("seconds_parked");

				totalParkedSeconds += hours * 3600L + mins * 60L + secs;
			}

			// Convert totalParkedSeconds back to HH:MM:SS
			long hours = totalParkedSeconds / 3600;
			long minutes = (totalParkedSeconds % 3600) / 60;
			long seconds = totalParkedSeconds % 60;

			String formattedParkedTime = String.format("%02d:%02d:%02d", hours, minutes, seconds);

			toReturn[1] = "orders_cnt:" + ordersSum;
			toReturn[2] = "extension_cnt:" + extensionsSum;
			toReturn[3] = "cancel_cnt:" + cancelsSum;
			toReturn[4] = "new_order_cnt:" + newOrdersSum;
			toReturn[5] = "parked_time:" + formattedParkedTime;

		} catch (SQLException e) {
			e.printStackTrace();
			toReturn[1] = "Error: " + e.getMessage();
			toReturn[2] = "extension_cnt:Error";
			toReturn[3] = "cancel_cnt:Error";
			toReturn[4] = "new_order_cnt:Error";
			toReturn[5] = "parked_time:Error";
		}

		return toReturn;
	}

	/**
	 * Adds a specified number of new parking spots to the database, all initialized
	 * with 'available' status.
	 *
	 * @param number A String representing the number of parking spots to add.
	 * @return A String array containing: [0] - "AddParkings" [1] - Success message
	 *         with count, or an error message if input is invalid or a database
	 *         error occurs.
	 */
	private String[] HandleAddParkings(String number) {
		String[] toReturn = new String[2];
		toReturn[0] = "AddParkings";
		int count;

		try {
			count = Integer.parseInt(number);
		} catch (NumberFormatException e) {
			toReturn[1] = "Invalid number format.";
			return toReturn;
		}

		String insertQuery = "INSERT INTO parking (parking_status) VALUES (?)";

		try (PreparedStatement pstmtUser = conn.prepareStatement(insertQuery)) {
			for (int i = 0; i < count; i++) {
				pstmtUser.setString(1, "available");
				pstmtUser.addBatch();
			}

			pstmtUser.executeBatch();
			toReturn[1] = count + " parkings added successfully.";
		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[1] = "Database error: " + ex.getMessage();
		}

		return toReturn;
	}

	/**
	 * Retrieves detailed subscriber and user information for the given username. It
	 * includes user ID, subscriber number, personal details, and contact info.
	 *
	 * @param user     The username of the requesting client (for auditing or UI
	 *                 context).
	 * @param username The username of the subscriber whose details are being
	 *                 fetched.
	 * @return A String array containing: [0] - "ViewSubscriberDetails" [1] - The
	 *         requesting user [2..9] - Fetched subscriber details (username,
	 *         userId, subscriberNumber, firstName, lastName, phoneNumber, email,
	 *         password) [10] - Status: "success", "Subscriber Not Found", "User Not
	 *         Found", or "Error".
	 */
	private String[] ViewSubscriberDetails(String user, String username) {
		String[] toReturn = new String[11];
		String queryUser = "SELECT * FROM users WHERE username = ?";
		toReturn[0] = "ViewSubscriberDetails";
		toReturn[1] = user;
		String userId;
		String firstName;
		String lastName;
		String email;
		String password;
		String phoneNumber;
		int subscriberNumber;

		try (PreparedStatement pstmtUser = conn.prepareStatement(queryUser)) {
			pstmtUser.setString(1, username);
			ResultSet userRs = pstmtUser.executeQuery();

			if (userRs.next()) {
				// Extract user data
				userId = String.valueOf(userRs.getInt("user_id"));
				firstName = userRs.getString("first_name");
				lastName = userRs.getString("last_name");
				email = userRs.getString("email");
				password = userRs.getString("password");
				phoneNumber = userRs.getString("phone_number");

				subscriberNumber = getSubscriberNumber(userId);

				// Fill return array
				if (subscriberNumber != -1) {
					toReturn[2] = username;
					toReturn[3] = userId;
					toReturn[4] = String.valueOf(subscriberNumber);
					toReturn[5] = firstName;
					toReturn[6] = lastName;
					toReturn[7] = phoneNumber;
					toReturn[8] = email;
					toReturn[9] = password;
					toReturn[10] = "success";
				} else {
					toReturn[10] = "Subscriber Not Found";
				}

				return toReturn;
			} else {
				toReturn[10] = "User Not Found";
				return toReturn;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			System.out.println("Error while retrieving subscriber details.");
		}

		toReturn[10] = "Error";
		return toReturn;
	}

	/**
	 * Adds a new user to the system as either a subscriber or an attendant. -
	 * Checks for existing user ID to prevent duplicates. - Inserts user details
	 * into the users table. - Inserts into either the subscribers or attendants
	 * table with 'active' status. - Returns a success message with the assigned
	 * subscriber or attendant number.
	 *
	 * @param msg A String array with: [1] username, [2] firstName, [3] lastName,
	 *            [4] id (user ID), [5] phone, [6] email, [7] password, [8]
	 *            initiator (for response context), [9] type ("subscriber" or
	 *            "attendant").
	 * @return A String array with: [0] - "addNewSubscriber" [1] - initiator [2] -
	 *         Success or error message.
	 */
	private String[] AddNewSubscriber(String[] msg) {
		String username = msg[1];
		String firstName = msg[2];
		String lastName = msg[3];
		String id = msg[4];
		String phone = msg[5];
		String email = msg[6];
		String password = msg[7];
		String type = msg[9];
		String[] toReturn = new String[3];
		toReturn[0] = "addNewSubscriber";
		toReturn[1] = msg[8];

		String insertUser = "INSERT INTO users (user_id, first_name, last_name, username, email, password, user_type, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

		// ✅ Check if user already exists
		try (PreparedStatement checkStmt = conn.prepareStatement("SELECT * FROM users WHERE user_id = ?")) {
			checkStmt.setString(1, id);
			ResultSet rs = checkStmt.executeQuery();
			if (rs.next()) {
				toReturn[2] = "User with ID already exists.";
				return toReturn;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[2] = "Error checking existing user";
			return toReturn;
		}

		// ✅ Insert user
		try (PreparedStatement pstmt = conn.prepareStatement(insertUser)) {
			pstmt.setString(1, id);
			pstmt.setString(2, firstName);
			pstmt.setString(3, lastName);
			pstmt.setString(4, username);
			pstmt.setString(5, email);
			pstmt.setString(6, password);
			pstmt.setString(7, type);
			pstmt.setString(8, phone);

			int rowsInserted = pstmt.executeUpdate();
			if (rowsInserted == 0) {
				toReturn[2] = "Failed to insert new user.";
				return toReturn;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[2] = "Failed to insert new user.";
			return toReturn;
		}

		// ✅ Get auto-generated user_number
		int userNumber = -1;
		try (PreparedStatement stmt = conn.prepareStatement("SELECT user_number FROM users WHERE user_id = ?")) {
			stmt.setString(1, id);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				userNumber = rs.getInt("user_number");
			} else {
				toReturn[2] = "Could not retrieve user number.";
				return toReturn;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[2] = "Error retrieving user number.";
			return toReturn;
		}

		// ✅ Insert into correct table with userNumber
		String insertRoleQuery = type.equals("subscriber")
				? "INSERT INTO subscribers (user_id, subscriber_number, subscriber_status) VALUES (?, ?, 'active')"
				: "INSERT INTO attendants (user_id, attendant_number, attendant_status) VALUES (?, ?, 'active')";

		try (PreparedStatement pstmt = conn.prepareStatement(insertRoleQuery)) {
			pstmt.setString(1, id);
			pstmt.setInt(2, userNumber);

			int rowsInserted = pstmt.executeUpdate();
			if (rowsInserted == 0) {
				toReturn[2] = "Failed to insert into role-specific table.";
				return toReturn;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[2] = "Failed to insert into role-specific table.";
			return toReturn;
		}

		// ✅ Compose success response
		toReturn[2] = String.format("%s was added successfully. Their %s Number is %d",
				type.equals("subscriber") ? "Subscriber" : "Attendant",
				type.equals("subscriber") ? "Subscriber" : "Attendant", userNumber);

		// ✅ Send welcome email
		String subject = "Welcome to BPark 🎉";
		StringBuilder body = new StringBuilder("Hi " + firstName + ",\n\n");
		body.append("Your registration to BPark is successful! Here are your account details:\n\n");
		body.append("🆔 " + (type.equals("subscriber") ? "Subscriber" : "Attendant") + " Number: ").append(userNumber)
				.append("\n");
		body.append("🔐 Username: ").append(username).append("\n");
		body.append("📧 Email: ").append(email).append("\n");
		body.append("📞 Phone: ").append(phone).append("\n");
		body.append("👤 Full Name: ").append(firstName).append(" ").append(lastName).append("\n");
		body.append("🆔 ID: ").append(id).append("\n");
		body.append("👤 Type: ").append(type).append("\n");
		body.append("\nThanks for joining us!\nBPark Team");

		Email.sendInfEmail(email, subject, body.toString());

		return toReturn;
	}

	/**
	 * Retrieves the attendant number from the database for a given user ID.
	 *
	 * @param id The user ID to look up.
	 * @return The attendant number if found, or -1 if not found or error occurs.
	 */

	private int getSubscriberNumber(String id) {
		String query = "SELECT subscriber_number FROM subscribers WHERE user_id = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, id);

			ResultSet userRs = pstmt.executeQuery();
			if (userRs.next()) {
				return userRs.getInt("subscriber_number");
			} else {
				System.out.println("No subscriber found for user ID: " + id);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			System.out.println("Error while getting the subscriber number.");
		}
		return -1; // Indicate not found or error

	}

	/**
	 * Retrieves the attendant number for a given user ID from the database.
	 *
	 * @param id The user ID to look up.
	 * @return The attendant number if found, or -1 if not found or an error occurs.
	 */
	private int getAttendantNumber(String id) {
		String query = "SELECT attendant_number FROM attendants WHERE user_id = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, id);

			ResultSet userRs = pstmt.executeQuery();
			if (userRs.next()) {
				return userRs.getInt("attendant_number");
			} else {
				System.out.println("No attendant found for user ID: " + id);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			System.out.println("Error while getting the attendant number.");
		}
		return -1; // Indicate not found or error

	}

	/**
	 * Retrieves all parking spots from the database, separating them into taken and
	 * available. - Taken parkings are joined with order and user details. -
	 * Available parkings are retrieved directly.
	 *
	 * @param msg A string identifier (for request-response context).
	 * @return A String array with: [0] - "ViewParkings" [1] - Original request
	 *         identifier [2] - String with joined taken parking details [3] -
	 *         String with joined available parking details
	 */
	private static String[] getAllParkings(String msg) {
		List<Parking> takenList = new ArrayList<>();
		List<Parking> availableList = new ArrayList<>();

		// Query for taken parkings (joined with orders and users)
		String takenQuery = """
				    SELECT
				        p.parking_number,
				        p.parking_status,
				        o.user_id,
				        o.order_number,
				        o.scheduled_time_leave,
				        o.actual_arrive_time
				    FROM parking p
				    JOIN `order` o ON p.parking_number = o.parking_number
				    WHERE o.order_status = 'inparking'
				""";

		// Query for available parkings (no joins needed)
		String availableQuery = """
				    SELECT
				        p.parking_number,
				        p.parking_status
				    FROM
				        parking p
				    WHERE p.parking_status = 'available'
				""";

		try (PreparedStatement takenStmt = conn.prepareStatement(takenQuery);
				ResultSet takenRs = takenStmt.executeQuery()) {

			while (takenRs.next()) {
				Parking parking = new Parking(String.valueOf(takenRs.getInt("parking_number")),
						takenRs.getString("parking_status"), String.valueOf(takenRs.getInt("user_id")),
						String.valueOf(takenRs.getInt("order_number")), takenRs.getString("scheduled_time_leave"),
						takenRs.getString("actual_arrive_time"));
				takenList.add(parking);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return new String[] { "ViewParkings", "Error retrieving taken parkings" };
		}

		try (PreparedStatement availableStmt = conn.prepareStatement(availableQuery);
				ResultSet availableRs = availableStmt.executeQuery()) {

			while (availableRs.next()) {
				Parking parking = new Parking(String.valueOf(availableRs.getInt("parking_number")),
						availableRs.getString("parking_status"), "", "", "", "" // Empty for available parkings
				);
				availableList.add(parking);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return new String[] { "ViewParkings", "Error retrieving available parkings" };
		}

		String taken = takenList.stream().map(Parking::toString).collect(Collectors.joining("|"));
		String available = availableList.stream().map(Parking::toString).collect(Collectors.joining("|"));
		return new String[] { "ViewParkings", msg, taken, available };
	}

	/**
	 * Handles a request to extend the leave time of a car in parking. - Checks if
	 * the order exists and is currently 'inparking'. - Calculates the new proposed
	 * leave time. - Checks for conflicts with other orders. - Updates leave time if
	 * no conflict, logs the request as approved/declined.
	 *
	 * @param message A String array with: [1] - username [2] - order number [3] -
	 *                number of hours to extend (as string)
	 * @return A String array with: [0] - "requestExtesnsion" [1] - Result message
	 *         ("request accepted", "request denied", "error occurred", etc.)
	 */
	private String[] handleRequestExtension(String[] message) {
		String username = message[1];
		String orderNumber = message[2];
		int hoursToExtend = Integer.parseInt(message[3]);

		String[] toReturn = new String[2];
		toReturn[0] = "requestExtesnsion";

		String id = getId(username);
		if (id == null) {
			toReturn[1] = "user not found";
			return toReturn;
		}

		// Step 1: Get the requested order
		String queryOrder = "SELECT * FROM `order` WHERE order_number = ?";
		try (PreparedStatement stmt = conn.prepareStatement(queryOrder)) {
			stmt.setString(1, orderNumber);
			ResultSet rsOrder = stmt.executeQuery();

			if (!rsOrder.next()) {
				toReturn[1] = "order not found";
				return toReturn;
			}

			String status = rsOrder.getString("order_status");
			if (!status.equals("inparking")) {
				toReturn[1] = "car is not in the parking";
				return toReturn;
			}

			int parkingNumber = rsOrder.getInt("parking_number");
			Date scheduledDate = rsOrder.getDate("scheduled_date");
			Time currentLeaveTime = rsOrder.getTime("scheduled_time_leave");

			// Step 2: Compute the proposed new leave time
			long millis = currentLeaveTime.getTime() + (hoursToExtend * 60 * 60 * 1000);
			Time newLeaveTime = new Time(millis);

			// Step 3: Check for time conflicts with other orders in same parking
			String conflictQuery = "SELECT * FROM `order` WHERE parking_number = ? AND order_status IN ('active', 'inparking') AND order_number != ? AND scheduled_date = ? AND scheduled_time_arrive < ? AND scheduled_time_leave > ?";
			try (PreparedStatement conflictStmt = conn.prepareStatement(conflictQuery)) {
				conflictStmt.setInt(1, parkingNumber);
				conflictStmt.setString(2, orderNumber);
				conflictStmt.setDate(3, (java.sql.Date) scheduledDate);
				conflictStmt.setTime(4, newLeaveTime);
				conflictStmt.setTime(5, currentLeaveTime);

				ResultSet rsConflict = conflictStmt.executeQuery();
				if (rsConflict.next()) {
					toReturn[1] = "request denied";
					insertNewRequest(orderNumber, "declined");
				} else {
					toReturn[1] = "request accepted";
					updateLeaveTime(orderNumber, newLeaveTime);
					insertNewRequest(orderNumber, "approved");
					update_dailyReport_ExtensionCnt();
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			toReturn[1] = "error occurred";
		}

		return toReturn;
	}

	/**
	 * Inserts a new extension request record into the database.
	 *
	 * @param orderNumber The order number for which the extension is requested.
	 * @param status      The status of the request ("approved" or "declined").
	 */
	private void insertNewRequest(String orderNumber, String status) {
		String query = "INSERT INTO extension_request (order_number, date_of_request, time_of_request, request_status) VALUES (?, ?, ?, ?)";

		LocalDate currentDate = LocalDate.now();
		LocalTime currentTime = LocalTime.now();

		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, orderNumber);
			pstmt.setDate(2, Date.valueOf(currentDate));
			pstmt.setTime(3, Time.valueOf(currentTime));
			pstmt.setString(4, status);

			int rowsInserted = pstmt.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("New extension request inserted successfully.");
			} else {
				System.out.println("Failed to insert new extension request.");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			System.out.println("Error while inserting extension request.");
		}
	}

	/**
	 * Updates the scheduled leave time for an order in the database.
	 *
	 * @param orderNumber  The order number whose leave time is to be updated.
	 * @param newLeaveTime The new leave time to set.
	 */
	private void updateLeaveTime(String orderNumber, Time newLeaveTime) {
		String query = "UPDATE `order` SET scheduled_time_leave = ? WHERE order_number = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setTime(1, newLeaveTime);
			pstmt.setString(2, orderNumber);

			int rowsUpdated = pstmt.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("Leave time updated successfully for order " + orderNumber);
			} else {
				System.out.println("No order found with order number " + orderNumber);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			System.out.println("Failed to update leave time for order " + orderNumber);
		}
	}

	/**
	 * Handles sending the receive code of a parking order via email. Validates the
	 * order's ownership and status, and sends an email if valid.
	 *
	 * @param message String array: [1]=username, [2]=email, [3]=orderNumber
	 * @return String array: [0]="sendParkingCodeViaEmail", [1]=result message
	 */
	private String[] handleSendParkingCode(String[] message) {
		String[] toReturn = new String[2];
		String username = message[1];
		String email = message[2];
		String orderNumber = message[3];
		String id = getId(username);
		toReturn[0] = "sendParkingCodeViaEmail";
		if (id == null) {
			toReturn[1] = "Username is not correct!";
			return toReturn;
		}
		// query to get the order with the order number given
		String query = "SELECT * FROM `order` WHERE order_number = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, orderNumber);
			ResultSet rs = pstmt.executeQuery();
			/* rs now has the order with the order number */
			// now we need to check what was returned
			if (rs.next()) {
				// order was found
				String idToCheck = rs.getString("user_id");
				String statusToCheck = rs.getString("order_status");
				String receive_code = rs.getString("receive_code");

				// start checking
				if (!idToCheck.equals(id)) {
					toReturn[1] = "This Order is NOT for you";
				} else if (statusToCheck.equals("finished")) {
					toReturn[1] = "Order is taken long time ago";
				} else if (statusToCheck.equals("canceled")) {
					toReturn[1] = "Order has been cancelled before";
				} else {
					toReturn[1] = "You will get a Mail including your Receive_code soon.";
					String subject = "Receive Code Recovery";
					String body = "Your Car Receive_code is " + receive_code;
					Email.sendInfEmail(email, subject, body);
				}

			} else {
				toReturn[1] = "Order Number does not Exist!";
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[1] = "Error Sending Parking Code Error";
		}

		return toReturn;
	}

	/**
	 * Cancels an active order for a given user. Sets the order status to 'canceled'
	 * in the database.
	 *
	 * @param username    The username of the client.
	 * @param orderNumber The order number to cancel.
	 * @return String array: [0]="cancelOrder", [1]=result message
	 */
	private String[] cancelOrder(String username, String orderNumber) {
		String[] toReturn = new String[2];
		String id = getId(username);

		if (id == null) {
			toReturn[0] = "cancelOrder";
			toReturn[1] = "User not found";
			return toReturn;
		}
		// query to update the email
		String query = "UPDATE `order` SET order_status = 'canceled' WHERE user_id = ? AND order_number = ? AND order_status = ?;";
		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, id);
			pstmt.setString(2, orderNumber);
			pstmt.setString(3, "active");

			int rowsAffected = pstmt.executeUpdate();
			toReturn[0] = "cancelOrder";
			toReturn[1] = (rowsAffected == 1) ? "Canceled Successfully" : "Cancel Failed";
			update_dailyReport_CancelCnt();
		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[0] = "cancelOrder";
			toReturn[1] = "Error Canceling Error";
		}

		return toReturn;
	}

	/**
	 * Retrieves all orders for a user, optionally filtered by status.
	 *
	 * @param username The username of the client.
	 * @param status   "all" to retrieve all orders, or a specific status like
	 *                 "active".
	 * @return String array: [0]="showOrders", [1]=serialized list of Order objects
	 *         or error message
	 */
	private static String[] showOrders(String username, String status) {
		List<Order> ordersList = new ArrayList<>();
		String id = getId(username);
		if (id == null) {
			return new String[] { "showOrders", "User not found" };
		}

		String query;
		if (status.equals("all")) {
			query = "SELECT * FROM `order` WHERE user_id = ?";
		} else {
			query = "SELECT * FROM `order` WHERE user_id = ? AND order_status = ?";
		}

		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, id);
			if (!status.equals("all")) {
				pstmt.setString(2, status);
			}
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Order order = new Order(rs.getInt("parking_number"), rs.getInt("order_number"),
						rs.getString("order_date"), rs.getString("order_time"), rs.getString("scheduled_date"),
						rs.getString("scheduled_time_arrive"), rs.getString("scheduled_time_leave"),
						rs.getInt("user_id"), rs.getInt("confirmation_code"), rs.getString("order_status"));
				ordersList.add(order);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return new String[] { "showOrders", "Error retrieving orders" };
		}

		String[] toSend = new String[2];
		toSend[0] = "showOrders";
		toSend[1] = ordersList.toString();
		return toSend;
	}

	/**
	 * Updates the password for a user in the database.
	 *
	 * @param username    The username whose password is to be updated.
	 * @param oldPassword The current password.
	 * @param newPassword The new password to set.
	 * @return String array: [0]="updatePassword", [1]=result message
	 */
	private String[] updatePassword(String username, String oldPassword, String newPassword) {
		String[] toReturn = new String[2];

		// query to update the email
		String query = "UPDATE users SET password = ? WHERE password = ? AND username = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, newPassword);
			pstmt.setString(2, oldPassword);
			pstmt.setString(3, username); // Use the ID obtained earlier

			int rowsAffected = pstmt.executeUpdate();
			toReturn[0] = "updatePassword";
			toReturn[1] = (rowsAffected == 1) ? "Update Successful" : "Update Failed";
		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[0] = "updatePassword";
			toReturn[1] = "Error updating Password";
		}

		return toReturn;
	}

	/**
	 * Updates the phone number for a user in the database.
	 *
	 * @param username The username of the client.
	 * @param oldPhone The old phone number to verify.
	 * @param newPhone The new phone number to set.
	 * @return String array: [0]="updatePhoneNumber", [1]=result message
	 */
	private String[] updatePhoneNumber(String username, String oldPhone, String newPhone) {
		String[] toReturn = new String[2];
		String id = getId(username);

		if (id == null) {
			toReturn[0] = "updateEmail";
			toReturn[1] = "User not found";
			return toReturn;
		}

		// query to update the email
		String query = "UPDATE users SET phone_number = ? WHERE phone_number = ? AND user_id = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, newPhone);
			pstmt.setString(2, oldPhone);
			pstmt.setString(3, id); // Use the ID obtained earlier

			int rowsAffected = pstmt.executeUpdate();
			toReturn[0] = "updatePhoneNumber";
			toReturn[1] = (rowsAffected == 1) ? "Update Successful" : "Update Failed";
		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[0] = "updatePhoneNumber";
			toReturn[1] = "Error updating Phone Number";
		}

		return toReturn;
	}

	/**
	 * Updates the email address for a user in the database.
	 *
	 * @param username The username of the client.
	 * @param oldEmail The old email address to verify.
	 * @param newEmail The new email address to set.
	 * @return String array: [0]="updateEmail", [1]=result message
	 */
	private String[] updateEmail(String username, String oldEmail, String newEmail) {
		String[] toReturn = new String[2];
		String id = getId(username);

		if (id == null) {
			toReturn[0] = "updateEmail";
			toReturn[1] = "User not found";
			return toReturn;
		}
		// query to update the email
		String query = "UPDATE users SET email = ? WHERE email = ? AND user_id = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, newEmail);
			pstmt.setString(2, oldEmail);
			pstmt.setString(3, id); // Use the ID obtained earlier

			int rowsAffected = pstmt.executeUpdate();
			toReturn[0] = "updateEmail";
			toReturn[1] = (rowsAffected == 1) ? "Update Successful" : "Update Failed";

		} catch (SQLException ex) {
			ex.printStackTrace();
			toReturn[0] = "updateEmail";
			toReturn[1] = "Error updating email";
		}

		return toReturn;
	}

	/**
	 * Retrieves the user ID for a given username from the database.
	 *
	 * @param username The username to look up.
	 * @return The user ID as a string if found; null otherwise.
	 */
	private static String getId(String username) {
		String queryForId = "SELECT user_id FROM users WHERE username = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(queryForId)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getString("user_id");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null; // return null if user not found or exception occurs
	}

	/**
	 * Checks whether the provided username and password exist in the database. If
	 * valid, also retrieves the user type and updates subscriber's last login date.
	 *
	 * @param username The username provided by the client.
	 * @param password The password provided by the client.
	 * @return String array: [0]="login", [1]="isThere"/"notThere", [2]=user type
	 */
	private String[] checkUserNumberIfExist(String userNumberStr, String password) {
		String query = "SELECT * FROM users WHERE user_number = ? AND password = ?";
		String[] toReturn = new String[4];

		int userNumber;

		try {
			userNumber = Integer.parseInt(userNumberStr);
		} catch (NumberFormatException e) {
			// Handle invalid input
			System.out.println("Invalid user number format");
			return new String[] { "login", "notThere", null };
		}

		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userNumber);
			pstmt.setString(2, password);

			ResultSet rs = pstmt.executeQuery();
			String answer;
			String type = null;
			String username = null;

			if (rs.next()) {
				answer = "isThere";
				type = rs.getString("user_type");
				username = rs.getString("username");

				// 🧊 If subscriber, update last login using username
				if ("subscriber".equalsIgnoreCase(type)) {
					updateSubscriberLastLogin(username);
				}
			} else {
				answer = "notThere";
			}

			toReturn[0] = "login";
			toReturn[1] = answer;
			toReturn[2] = type;
			toReturn[3] = username;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return toReturn;
	}

	/**
	 * Updates the 'last_login' field for a subscriber to the current date.
	 *
	 * @param username The subscriber's username.
	 */
	private void updateSubscriberLastLogin(String username) {
		String query = """
				    UPDATE subscribers
				    SET last_login = CURRENT_DATE
				    WHERE user_id = (
				        SELECT user_id FROM users WHERE username = ?
				    )
				""";

		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Handles the "ReceiveCar" request from a client. Verifies the receive code,
	 * updates the order status to 'finished', sets the parking spot to 'available',
	 * and updates reporting tables.
	 *
	 * @param username       The username of the client.
	 * @param parkingCodeStr The receive code provided by the client.
	 * @return String array: [0]="ReceiveCar", [1]=result message
	 */
	private String[] ReceiveCar(String username, String parkingCodeStr) {
		String[] result = new String[2];
		result[0] = "ReceiveCar";

		String id = getId(username);

		try {
			int parkingCode = Integer.parseInt(parkingCodeStr);

			// Step 1: Check for an inparking order
			String selectQuery = "SELECT order_number, parking_number FROM `order` "
					+ "WHERE user_id = (SELECT user_id FROM users WHERE user_id = ?) "
					+ "AND receive_code = ? AND order_status = 'inparking'";

			PreparedStatement selectStmt = conn.prepareStatement(selectQuery);
			selectStmt.setString(1, id);
			selectStmt.setInt(2, parkingCode);

			ResultSet rs = selectStmt.executeQuery();

			if (rs.next()) {
				int orderNumber = rs.getInt("order_number");
				int parkingNumber = rs.getInt("parking_number");

				// Step 2: Update order status
				String updateOrder = "UPDATE `order` SET order_status = 'finished' WHERE order_number = ?";
				PreparedStatement updateOrderStmt = conn.prepareStatement(updateOrder);
				updateOrderStmt.setInt(1, orderNumber);
				updateOrderStmt.executeUpdate();

				// Step 3: Update parking status
				String updateParking = "UPDATE parking SET parking_status = 'available' WHERE parking_number = ?";
				PreparedStatement updateParkingStmt = conn.prepareStatement(updateParking);
				updateParkingStmt.setInt(1, parkingNumber);
				updateParkingStmt.executeUpdate();

				result[1] = "Car received successfully.";
				updateActualLeaveTime(String.valueOf(orderNumber));
				updateDaily_Report_timeParked(CalculateParkingTimeInMins(orderNumber));
			} else {
				result[1] = "No matching order found with status 'inparking'.";
			}

		} catch (NumberFormatException e) {
			result[1] = "Invalid parking code format.";
		} catch (SQLException e) {
			result[1] = "Database error: " + e.getMessage();
		}

		return result;
	}

	/**
	 * Calculates the parking duration in minutes for a completed order.
	 *
	 * @param orderNumber The order number to calculate duration for.
	 * @return The duration in minutes, or 0 if calculation fails.
	 */
	private int CalculateParkingTimeInMins(int orderNumber) {
		int durationMins = 0;

		String query = "SELECT actual_arrive_time, actual_leave_time FROM `order` "
				+ "WHERE order_number = ? AND actual_arrive_time IS NOT NULL AND actual_leave_time IS NOT NULL";

		try (PreparedStatement stmt = conn.prepareStatement(query)) {

			stmt.setInt(1, orderNumber);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				java.sql.Time arrive = rs.getTime("actual_arrive_time");
				java.sql.Time leave = rs.getTime("actual_leave_time");
				if (arrive != null && leave != null) {
					long diffMillis = leave.getTime() - arrive.getTime();
					durationMins = (int) (diffMillis / (60 * 1000)); // convert ms to minutes
				}
			}
		} catch (SQLException e) {
			System.err.println("SQL error: " + e.getMessage());
		}

		return durationMins;
	}

	/**
	 * Updates the total parked time in the daily_report table for today. Adds the
	 * provided duration in minutes to the existing total.
	 *
	 * @param durationMins The duration to add, in minutes.
	 */

	private void updateDaily_Report_timeParked(int durationMins) {
		String today = java.time.LocalDate.now().toString(); // e.g. "2025-06-05"
		try {
			// Step 1: Check if a report for today exists
			String selectQuery = "SELECT hours_parked, mins_parked FROM daily_report WHERE date_of_day = ?";
			PreparedStatement selectStmt = conn.prepareStatement(selectQuery);
			selectStmt.setString(1, today);

			ResultSet rs = selectStmt.executeQuery();

			int totalHours = (int) (durationMins / 60);
			int totalMins = (int) (durationMins % 60);

			if (rs.next()) {
				// Record exists, update it
				int currentHours = rs.getInt("hours_parked");
				int currentMins = rs.getInt("mins_parked");

				int newMins = currentMins + totalMins;
				int carryHours = newMins / 60;
				newMins = newMins % 60;

				int newHours = currentHours + totalHours + carryHours;

				String updateQuery = "UPDATE daily_report SET hours_parked = ?, mins_parked = ? WHERE date_of_day = ?";
				PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
				updateStmt.setInt(1, newHours);
				updateStmt.setInt(2, newMins);
				updateStmt.setString(3, today);
				updateStmt.executeUpdate();

			} else {
				// No record for today, insert new
				String insertQuery = "INSERT INTO daily_report (date_of_day, hours_parked, mins_parked) VALUES (?, ?, ?)";
				PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
				insertStmt.setString(1, today);
				insertStmt.setInt(2, totalHours);
				insertStmt.setInt(3, totalMins);
				insertStmt.executeUpdate();
			}
		} catch (SQLException e) {
			System.err.println("Database error: " + e.getMessage());
		}
	}

	/**
	 * Increments the new_order_cnt field in the daily_report table for today.
	 * Creates a new record if one doesn't exist.
	 */
	private void update_dailyReport_newOrder() {
		String today = java.time.LocalDate.now().toString();

		try {
			// Check if today's report exists
			String selectQuery = "SELECT new_order_cnt FROM daily_report WHERE date_of_day = ?";
			PreparedStatement selectStmt = conn.prepareStatement(selectQuery);
			selectStmt.setString(1, today);

			ResultSet rs = selectStmt.executeQuery();

			if (rs.next()) {
				// Exists: update new_order_cnt += 1
				int currentCount = rs.getInt("new_order_cnt");
				String updateQuery = "UPDATE daily_report SET new_order_cnt = ? WHERE date_of_day = ?";
				PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
				updateStmt.setInt(1, currentCount + 1);
				updateStmt.setString(2, today);
				updateStmt.executeUpdate();

			} else {
				// Not exists: insert new record with new_order_cnt = 1, others zero
				String insertQuery = "INSERT INTO daily_report (date_of_day, new_order_cnt, hours_parked, mins_parked) VALUES (?, ?, 0, 0)";
				PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
				insertStmt.setString(1, today);
				insertStmt.setInt(2, 1);
				insertStmt.executeUpdate();
			}

		} catch (SQLException e) {
			System.err.println("Database error: " + e.getMessage());
		}
	}

	/**
	 * Increments the extension count (extension_cnt) in today's daily_report
	 * record. If no record exists for today, creates one with extension_cnt
	 * initialized to 1.
	 */
	private void update_dailyReport_ExtensionCnt() {
		String today = java.time.LocalDate.now().toString();

		try {
			String select = "SELECT extension_cnt FROM daily_report WHERE date_of_day = ?";
			PreparedStatement selectStmt = conn.prepareStatement(select);
			selectStmt.setString(1, today);
			ResultSet rs = selectStmt.executeQuery();

			if (rs.next()) {
				int current = rs.getInt("extension_cnt");
				String update = "UPDATE daily_report SET extension_cnt = ? WHERE date_of_day = ?";
				PreparedStatement updateStmt = conn.prepareStatement(update);
				updateStmt.setInt(1, current + 1);
				updateStmt.setString(2, today);
				updateStmt.executeUpdate();
			} else {
				String insert = "INSERT INTO daily_report (date_of_day, orders_cnt, extension_cnt, cancel_cnt, hours_parked, mins_parked, seconds_parked, new_order_cnt) "
						+ "VALUES (?, 0, 1, 0, 0, 0, 0, 0)";
				PreparedStatement insertStmt = conn.prepareStatement(insert);
				insertStmt.setString(1, today);
				insertStmt.executeUpdate();
			}
		} catch (SQLException e) {
			System.err.println("DB error in updateExtensionCnt: " + e.getMessage());
		}
	}

	/**
	 * Increments the cancellation count (cancel_cnt) in today's daily_report
	 * record. If no record exists for today, creates one with cancel_cnt
	 * initialized to 1.
	 */
	private void update_dailyReport_CancelCnt() {
		String today = java.time.LocalDate.now().toString();

		try {
			String select = "SELECT cancel_cnt FROM daily_report WHERE date_of_day = ?";
			PreparedStatement selectStmt = conn.prepareStatement(select);
			selectStmt.setString(1, today);
			ResultSet rs = selectStmt.executeQuery();

			if (rs.next()) {
				int current = rs.getInt("cancel_cnt");
				String update = "UPDATE daily_report SET cancel_cnt = ? WHERE date_of_day = ?";
				PreparedStatement updateStmt = conn.prepareStatement(update);
				updateStmt.setInt(1, current + 1);
				updateStmt.setString(2, today);
				updateStmt.executeUpdate();
			} else {
				String insert = "INSERT INTO daily_report (date_of_day, orders_cnt, extension_cnt, cancel_cnt, hours_parked, mins_parked, seconds_parked, new_order_cnt) "
						+ "VALUES (?, 0, 0, 1, 0, 0, 0, 0)";
				PreparedStatement insertStmt = conn.prepareStatement(insert);
				insertStmt.setString(1, today);
				insertStmt.executeUpdate();
			}
		} catch (SQLException e) {
			System.err.println("DB error in updateCancelCnt: " + e.getMessage());
		}
	}

	/**
	 * Increments the total orders count (orders_cnt) in today's daily_report
	 * record. If no record exists for today, creates one with orders_cnt
	 * initialized to 1.
	 */
	private void update_dailyReport_OrdersCnt() {
		String today = java.time.LocalDate.now().toString();

		try {
			String select = "SELECT orders_cnt FROM daily_report WHERE date_of_day = ?";
			PreparedStatement selectStmt = conn.prepareStatement(select);
			selectStmt.setString(1, today);
			ResultSet rs = selectStmt.executeQuery();

			if (rs.next()) {
				int current = rs.getInt("orders_cnt");
				String update = "UPDATE daily_report SET orders_cnt = ? WHERE date_of_day = ?";
				PreparedStatement updateStmt = conn.prepareStatement(update);
				updateStmt.setInt(1, current + 1);
				updateStmt.setString(2, today);
				updateStmt.executeUpdate();
			} else {
				String insert = "INSERT INTO daily_report (date_of_day, orders_cnt, extension_cnt, cancel_cnt, hours_parked, mins_parked, seconds_parked, new_order_cnt) "
						+ "VALUES (?, 1, 0, 0, 0, 0, 0, 0)";
				PreparedStatement insertStmt = conn.prepareStatement(insert);
				insertStmt.setString(1, today);
				insertStmt.executeUpdate();
			}
		} catch (SQLException e) {
			System.err.println("DB error in updateOrdersCnt: " + e.getMessage());
		}
	}

	/**
	 * Retrieves the email address of a user based on their username.
	 *
	 * @param username The username of the user.
	 * @return The email address if found; null otherwise.
	 */

	private String getEmail(String username) {
		String queryForId = "SELECT email FROM users WHERE username = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(queryForId)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getString("email");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null; // return null if user not found or exception occurs
	}

	/**
	 * Main entry point for starting the BPark server on a default port.
	 *
	 * @param args Command-line arguments (not used).
	 */
	public static void main(String[] args) {
		int port = 5555;
		BParkServer server = new BParkServer(port);

		try {
			server.listen(); // blocks until server is ready
			System.out.println("✅ Server started on port " + port);
		} catch (Exception e) {
			System.out.println("❌ ERROR - Could not start server: " + e.getMessage());
			e.printStackTrace();
		}
	}

	/* functionality that the system should do without the user's interactions */
	/**
	 * Starts a scheduled task that periodically checks in-parking orders to send
	 * reminder emails when their session is about to end. Runs every 2 minutes.
	 */
	public void startInParkingReminderScheduler() {
		Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(() -> {
			this.checkInParkingOrders();
		}, 0, 2, TimeUnit.MINUTES);
	}

	/**
	 * Starts a scheduled task that periodically checks active orders to enforce
	 * business rules or notify users. Runs every 2 minutes.
	 */
	public void startActiveOrderChecker() {
		Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(() -> {
			this.checkActiveOrders();
		}, 0, 2, TimeUnit.MINUTES);
	}

	/**
	 * Starts a scheduled task that periodically checks for inactive subscribers
	 * (e.g., to mark or notify them as inactive). Runs once daily.
	 */
	public void startInactiveSubscriberChecker() {
		Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(() -> {
			this.checkInactiveSubscribers();
		}, 0, 1, TimeUnit.DAYS); // Run once daily
	}

	/**
	 * Fetches all orders currently marked as 'inparking' and not yet notified about
	 * their upcoming leave time.
	 *
	 * @return A list of matching Order objects.
	 */

	private List<Order> fetchInParkingOrders() {
		List<Order> orders = new ArrayList<>();
		String query = "SELECT * FROM `order` WHERE order_status = 'inparking' AND notified_about_leaving = FALSE";

		try (PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {

			while (rs.next()) {
				Order order = new Order(rs.getInt("parking_number"), rs.getInt("order_number"),
						rs.getString("order_date"), rs.getString("order_time"), rs.getString("scheduled_date"),
						rs.getString("scheduled_time_arrive"), rs.getString("scheduled_time_leave"),
						rs.getInt("user_id"), rs.getInt("confirmation_code"), rs.getString("order_status"));
				orders.add(order);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return orders;
	}

	/**
	 * Retrieves the email address of a user by their user ID.
	 *
	 * @param userId The user's ID.
	 * @return The email address if found; null otherwise.
	 */
	private String getEmailFromUserId(int userId) {
		String query = "SELECT email FROM users WHERE user_id = ?";
		try (PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getString("email");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Checks all 'inparking' orders to see if they are within 15 minutes of their
	 * scheduled leave time. Sends reminder emails and flags them as notified to
	 * avoid repeat notifications.
	 * 
	 * Uses a semaphore to prevent concurrent executions.
	 */

	private void checkInParkingOrders() {
		try {
			if (!inparkingLock.tryAcquire()) {
				System.out.println("🔁 checkInParkingOrders skipped: already in progress.");
				return;
			}

			List<Order> orders = fetchInParkingOrders();

			for (Order order : orders) {
				try {
					LocalDateTime scheduledLeaveTime = LocalDateTime.of(LocalDate.parse(order.getScheduledDate()),
							LocalTime.parse(order.getScheduledTimeLeave()));

					long minutesLeft = java.time.Duration.between(LocalDateTime.now(), scheduledLeaveTime).toMinutes();

					if (minutesLeft <= 15 && minutesLeft >= 0) {
						// Start transaction
						conn.setAutoCommit(false);

						// Attempt to mark the order as notified
						PreparedStatement updateFlag = conn.prepareStatement(
								"UPDATE `order` SET notified_about_leaving = TRUE WHERE order_number = ? AND notified_about_leaving = FALSE");
						updateFlag.setInt(1, order.getOrderNumber());
						int updated = updateFlag.executeUpdate();

						// If the row was updated (i.e., this thread won the race)
						if (updated > 0) {
							String userEmail = getEmailFromUserId(order.getUserId());
							if (userEmail != null) {
								String message = String.format(
										"🚗 Your parking session (Order #%d) is ending at %s.\n\nPlease collect your car on time to avoid extra charges.\n\nThanks,\nBraude BPark Team",
										order.getOrderNumber(), scheduledLeaveTime.toString());
								Email.sendInfEmail(userEmail, "⏰ Parking End Reminder", message);
							}
						}

						conn.commit();
						conn.setAutoCommit(true);
					}
				} catch (Exception e) {
					try {
						conn.rollback();
					} catch (SQLException ignore) {
					}
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			inparkingLock.release();
		}
	}

	/**
	 * Periodically checks all 'active' orders to see if they have passed their
	 * scheduled arrival time plus a 15-minute grace period.
	 * 
	 * If overdue, the order is automatically canceled, flagged to prevent repeat
	 * processing, and a cancellation email is sent to the user.
	 *
	 * Uses a semaphore to ensure only one execution runs at a time.
	 */
	public void checkActiveOrders() {
		try {
			if (!activeOrderLock.tryAcquire()) {
				System.out.println("🔁 checkActiveOrders skipped: already running.");
				return;
			}

			String query = """
					    SELECT order_number, user_id, scheduled_date, scheduled_time_arrive
					    FROM `order` WHERE order_status = 'active' AND notified_about_leaving = FALSE
					""";

			try (PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
				LocalDateTime now = LocalDateTime.now();

				while (rs.next()) {
					int orderNum = rs.getInt("order_number");
					int userId = rs.getInt("user_id");
					LocalDate date = rs.getDate("scheduled_date").toLocalDate();
					LocalTime time = rs.getTime("scheduled_time_arrive").toLocalTime();
					LocalDateTime scheduledArrival = LocalDateTime.of(date, time);

					// Cancel only if 15 minutes have passed after the scheduled arrival time
					if (now.isAfter(scheduledArrival.plusMinutes(15))) {
						// Begin transaction
						conn.setAutoCommit(false);

						// Lock the row and set canceled + flagged
						try (PreparedStatement updateStmt = conn.prepareStatement(
								"UPDATE `order` SET order_status = 'canceled', notified_about_leaving = TRUE "
										+ "WHERE order_number = ? AND notified_about_leaving = FALSE")) {

							updateStmt.setInt(1, orderNum);
							int updated = updateStmt.executeUpdate();

							if (updated > 0) {
								update_dailyReport_CancelCnt();

								String email = getEmailFromUserId(userId);
								if (email != null) {
									String subject = "🚫 Your Parking Order #" + orderNum + " Has Been Canceled";
									String body = String.format(
											"Dear subscriber,\n\nYour parking reservation (Order #%d) was scheduled to start at %s,\n"
													+ "but we didn't detect your car's arrival in time.\nTherefore your order was automatically canceled.\n\n"
													+ "If this was an error, please make a new reservation.\n\nThank you,\nBraude BPark",
											orderNum,
											scheduledArrival.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
									Email.sendInfEmail(email, subject, body);
								}
							}
							conn.commit();
						} catch (SQLException e) {
							conn.rollback();
							throw e;
						} finally {
							conn.setAutoCommit(true);
						}
					}
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			activeOrderLock.release();
		}
	}

	/**
	 * Periodically scans all active subscribers to detect inactivity.
	 * 
	 * If a subscriber has not logged in for over one month, their status is updated
	 * to 'frozen' in the database.
	 *
	 * Intended to run once daily to enforce activity policy.
	 */
	private void checkInactiveSubscribers() {
		String query = """
				    SELECT user_id, last_login
				    FROM subscribers
				    WHERE subscriber_status = 'active'
				""";

		try (PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {

			LocalDate oneMonthAgo = LocalDate.now().minusMonths(1);

			while (rs.next()) {
				int userId = rs.getInt("user_id");
				Date lastLogin = rs.getDate("last_login");

				if (lastLogin != null && lastLogin.toLocalDate().isBefore(oneMonthAgo)) {
					// Mark as frozen
					try (PreparedStatement updateStmt = conn.prepareStatement(
							"UPDATE subscribers SET subscriber_status = 'frozen' WHERE user_id = ?")) {
						updateStmt.setInt(1, userId);
						updateStmt.executeUpdate();
						System.out.println("🧊 Subscriber user_id=" + userId + " marked as frozen.");
					}
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
