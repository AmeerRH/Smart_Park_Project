package server;

/**
 * Represents a parking spot in the BPark system. Holds details about its
 * number, status, owner, associated order, and time range it is taken.
 */
public class Parking {
	/** The unique number identifying this parking spot. */
	private String parkingNumber;
	/** The current status of the parking (e.g. 'available', 'taken'). */
	private String status;
	/** The ID of the user who currently owns or uses this parking spot (if any). */
	private String ownerID;
	/** The order number associated with this parking usage (if any). */
	private String orderNumber;
	/** The time until which the parking spot is reserved/taken. */
	private String takenUntil;
	/** The time from which the parking spot is reserved/taken. */
	private String takenFrom;

	/**
	 * Constructs a new Parking object with all details.
	 *
	 * @param parkingNumber the unique parking number
	 * @param status        the status of the parking (e.g. 'available', 'taken')
	 * @param ownerID       the ID of the user who owns/uses the parking
	 * @param orderNumber   the order number associated with the parking
	 * @param takenUntil    the time until which the parking is taken
	 * @param takenFrom     the time from which the parking is taken
	 */
	public Parking(String parkingNumber, String status, String ownerID, String orderNumber, String takenUntil,
			String takenFrom) {
		this.parkingNumber = parkingNumber;
		this.status = status;
		this.ownerID = ownerID;
		this.orderNumber = orderNumber;
		this.takenUntil = takenUntil;
		this.takenFrom = takenFrom;
	}

	/** @return the parking number. */
	public String getParkingNumber() {
		return parkingNumber;
	}

	/** @param parkingNumber the parking number to set. */
	public void setParkingNumber(String parkingNumber) {
		this.parkingNumber = parkingNumber;
	}

	/** @return the current status of the parking. */
	public String getStatus() {
		return status;
	}

	/** @param status the status to set (e.g. 'available', 'taken'). */
	public void setStatus(String status) {
		this.status = status;
	}

	/** @return the ID of the owner/user of the parking. */
	public String getOwnerID() {
		return ownerID;
	}

	/** @param ownerID the owner ID to set. */
	public void setOwnerID(String ownerID) {
		this.ownerID = ownerID;
	}

	/** @return the order number associated with the parking. */
	public String getOrderNumber() {
		return orderNumber;
	}

	/** @param orderNumber the order number to set. */
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	/** @return the time until which the parking is taken. */
	public String getTakenUntil() {
		return takenUntil;
	}

	/** @param takenUntil the time until which the parking is taken. */
	public void setTakenUntil(String takenUntil) {
		this.takenUntil = takenUntil;
	}

	/** @return the time from which the parking is taken. */
	public String getTakenFrom() {
		return takenFrom;
	}

	/** @param takenFrom the time from which the parking is taken. */
	public void setTakenFrom(String takenUntil) {
		this.takenFrom = takenUntil;
	}

	/**
	 * Returns a semicolon-separated string representation of the Parking object,
	 * suitable for sending over the network or for logging.
	 *
	 * @return a string containing all fields separated by semicolons.
	 */
	@Override
	public String toString() {
		return parkingNumber + ";" + status + ";" + (ownerID != null ? ownerID : "") + ";"
				+ (orderNumber != null ? orderNumber : "") + ";" + (takenFrom != null ? takenFrom : "") + ";"
				+ (takenUntil != null ? takenUntil : "");
	}

}
