package server;

/**
 * Represents a parking order in the BPARK system. An Order includes details
 * such as parking spot, times, user, and status.
 */
public class Order {
	/** The parking number assigned to this order. */
	private int parkingNumber;
	/** The unique order number. */
	private int orderNumber;
	/** The date the order was placed (YYYY-MM-DD). */
	private String orderDate;
	/** The time the order was placed (HH:mm:ss). */
	private String orderTime;
	/** The scheduled date for parking (YYYY-MM-DD). */
	private String scheduledDate;
	/** The scheduled arrival time for parking (HH:mm:ss). */
	private String scheduledTimeArrive;
	/** The scheduled leave time for parking (HH:mm:ss). */
	private String scheduledTimeLeave;
	/** The ID of the user who made the order. */
	private int userId;
	/** The confirmation code associated with the order. */
	private int confirmationCode;
	/** The current status of the order (e.g. "active", "inparking", "finished"). */
	private String orderStatus;

	/**
	 * Default constructor. Required for frameworks like JavaFX TableView that use
	 * reflection.
	 */
	public Order() {
	}

	/**
	 * Parameterized constructor to initialize all order details.
	 *
	 * @param parkingNumber       The assigned parking number.
	 * @param orderNumber         The unique order number.
	 * @param orderDate           The date the order was placed.
	 * @param orderTime           The time the order was placed.
	 * @param scheduledDate       The scheduled parking date.
	 * @param scheduledTimeArrive The scheduled arrival time.
	 * @param scheduledTimeLeave  The scheduled leave time.
	 * @param userId              The ID of the user placing the order.
	 * @param confirmationCode    The confirmation code for the order.
	 * @param orderStatus         The status of the order.
	 */
	public Order(int parkingNumber, int orderNumber, String orderDate, String orderTime, String scheduledDate,
			String scheduledTimeArrive, String scheduledTimeLeave, int userId, int confirmationCode,
			String orderStatus) {
		this.parkingNumber = parkingNumber;
		this.orderNumber = orderNumber;
		this.orderDate = orderDate;
		this.orderTime = orderTime;
		this.scheduledDate = scheduledDate;
		this.scheduledTimeArrive = scheduledTimeArrive;
		this.scheduledTimeLeave = scheduledTimeLeave;
		this.userId = userId;
		this.confirmationCode = confirmationCode;
		this.orderStatus = orderStatus;
	}

	/** @return the parking number. */
	public int getParkingNumber() {
		return parkingNumber;
	}

	/** @param parkingNumber the parking number to set. */
	public void setParkingNumber(int parkingNumber) {
		this.parkingNumber = parkingNumber;
	}

	/** @return the order number. */

	public int getOrderNumber() {
		return orderNumber;
	}

	/** @param orderNumber the order number to set. */
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	/** @return the date the order was placed. */
	public String getOrderDate() {
		return orderDate;
	}

	/** @param orderDate the order date to set. */
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	/** @return the time the order was placed. */
	public String getOrderTime() {
		return orderTime;
	}

	/** @param orderTime the order time to set. */
	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	/** @return the scheduled parking date. */
	public String getScheduledDate() {
		return scheduledDate;
	}

	/** @param scheduledDate the scheduled date to set. */
	public void setScheduledDate(String scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	/** @return the scheduled arrival time. */
	public String getScheduledTimeArrive() {
		return scheduledTimeArrive;
	}

	/** @param scheduledTimeArrive the arrival time to set. */
	public void setScheduledTimeArrive(String scheduledTimeArrive) {
		this.scheduledTimeArrive = scheduledTimeArrive;
	}

	/** @return the scheduled leave time. */
	public String getScheduledTimeLeave() {
		return scheduledTimeLeave;
	}

	/** @param scheduledTimeLeave the leave time to set. */
	public void setScheduledTimeLeave(String scheduledTimeLeave) {
		this.scheduledTimeLeave = scheduledTimeLeave;
	}

	/** @return the ID of the user who placed the order. */
	public int getUserId() {
		return userId;
	}

	/** @param userId the user ID to set. */
	public void setUserId(int userId) {
		this.userId = userId;
	}

	/** @return the confirmation code for the order. */
	public int getConfirmationCode() {
		return confirmationCode;
	}

	/** @param confirmationCode the confirmation code to set. */
	public void setConfirmationCode(int confirmationCode) {
		this.confirmationCode = confirmationCode;
	}

	/** @return the status of the order. */
	public String getOrderStatus() {
		return orderStatus;
	}

	/** @param orderStatus the order status to set. */
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	/**
	 * Returns a string representation of the Order object, including all its fields
	 * in key=value pairs.
	 *
	 * @return a human-readable string describing the order.
	 */
	@Override
	public String toString() {
		return "Order{" + "parkingNumber=" + parkingNumber + ", orderNumber=" + orderNumber + ", orderDate='"
				+ orderDate + '\'' + ", orderTime='" + orderTime + '\'' + ", scheduledDate='" + scheduledDate + '\''
				+ ", scheduledTimeArrive='" + scheduledTimeArrive + '\'' + ", scheduledTimeLeave='" + scheduledTimeLeave
				+ '\'' + ", userId=" + userId + ", confirmationCode=" + confirmationCode + ", orderStatus='"
				+ orderStatus + '\'' + '}';
	}
}
