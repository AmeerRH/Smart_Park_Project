package server;

import java.io.IOException;
import java.time.LocalDateTime;

import javafx.application.Application;
import javafx.stage.Stage;
import serverGUI.ServerGUIController;

/**
 * ServerUI is the JavaFX entry point for launching the Braude BPark server
 * application. It initializes the server GUI and manages server lifecycle
 * methods such as start and stop.
 */
public class ServerUI extends Application {

	/** Default port used for the server if none is specified. */
	public static final int DEFAULT_PORT = 5555;
	/** The server instance being managed. */
	private static BParkServer server;

	/**
	 * Main entry point. Launches the JavaFX application.
	 *
	 * @param args command-line arguments
	 * @throws Exception if the JavaFX application fails to launch
	 */
	public static void main(String[] args) throws Exception {
		launch(args);
	}

	/**
	 * Starts the JavaFX primary stage and initializes the server GUI controller.
	 *
	 * @param primaryStage the primary stage for the JavaFX application
	 * @throws Exception if an error occurs during GUI startup
	 */
	public void start(@SuppressWarnings("exports") Stage primaryStage) throws Exception {
		ServerGUIController aFrame = new ServerGUIController();
		aFrame.start(primaryStage);
	}

	/**
	 * Starts the server on the specified port, begins listening for client
	 * connections, and launches background tasks such as checking in-parking
	 * orders, active orders, and inactive subscribers.
	 *
	 * @param port           the port number to listen on
	 * @param serverInstance the BParkServer instance to manage
	 */
	public static void runServer(int port, BParkServer serverInstance) {
		if (server != null && server.isListening()) {
			System.out.println("Server is already running");
			return;
		}
		server = serverInstance;
		try {
			server.listen();
			// 🎯 Start background recurring tasks here
			new Thread(() -> {
				while (true) {
					try {
						server.startInParkingReminderScheduler();
						server.startActiveOrderChecker();
						server.startInactiveSubscriberChecker();
						Thread.sleep(2 * 60 * 1000); // 2 min
					} catch (InterruptedException ie) {
						break;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}, "BackgroundOrderChecker").start();

		} catch (Exception ex) {
			System.out.println("ERROR - Could not listen for clients!");
		}
	}

	/**
	 * Stops the server if it is running, closing any open network connections and
	 * releasing resources.
	 */
	public static void stopServer() {
		if (server != null && server.isListening())
			try {
				server.close();
			} catch (IOException e) {
				System.out.println("Error closing the server: " + e.getMessage());
			}
	}
}
