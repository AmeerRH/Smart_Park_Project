package commonGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
/**
 * The {@code LoginPageGUIController} class manages the login screen of the BPARK system.
 * It handles user input for username and password, sending login requests to the server,
 * and routing to the appropriate view on success.
 *
 * <p>Main responsibilities:</p>
 * <ul>
 *   <li>Handles Connect, Clear, and Exit button actions</li>
 *   <li>Sends login request to the server</li>
 *   <li>Transitions to user-specific views on successful login</li>
 *   <li>Displays error messages on login failure</li>
 * </ul>
 *
 * @author Vaad
 * @version 1.0
 */
public class LoginPageGUIController implements Initializable {
	public static LoginPageGUIController instance;

	@FXML
	private TextField usernameInputField;

	@FXML
	private PasswordField passwordInputField;

	@FXML
	private Button connectBtn;

	@FXML
	private Button clearBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private Label ErrorMsgLabel;
	/**
	 * Handles the Connect button click.
	 * Validates input fields and sends a login request to the server.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	public void ConnectBtn(@SuppressWarnings("exports") ActionEvent event) {
		String username = usernameInputField.getText();
		String password = passwordInputField.getText();
				
		
		if (username.isEmpty() || password.isEmpty()) {
	        ErrorMsgLabel.setText("Please fill in both user number and password.");
	        ErrorMsgLabel.setTextFill(Color.web("#DC143C"));
	        return;
	    }

	    // Check if user number contains only digits
	    if (!username.matches("\\d+")) {
	        ErrorMsgLabel.setText("User number must contain only digits.");
	        ErrorMsgLabel.setTextFill(Color.web("#DC143C"));
	        return;
	    }
	    
	    
		String[] loginRequest = new String[] { "login", username, password };

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setLoginPageGUIController(this);
			ClientUI.bParkClient.requestFromServer(loginRequest);
		}
	}
	/**
	 * Handles the Clear button click.
	 * Clears all input fields and resets the error message label.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	public void ClearBtn(@SuppressWarnings("exports") ActionEvent event) {
		usernameInputField.clear();
		passwordInputField.clear();
		ErrorMsgLabel.setText("Inputs are cleared");
		this.ErrorMsgLabel.setTextFill(Color.web("#228B22"));
	}
	/**
	 * Handles the Exit button click.
	 * Closes the client connection if connected and exits the application.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	public void ExitBtn(@SuppressWarnings("exports") ActionEvent event) {
		// Get the current window (stage) and close it
		if (ClientUI.bParkClient != null && ClientUI.bParkClient.isConnected()) {
	        ClientUI.bParkClient.requestFromServer("DisConnect");
	        ClientUI.bParkClient.quit(); // Thigs will now notify server

	    } else {
	        System.exit(0);
	    }
		
	}
	/**
	 * Initializes the controller.
	 * Clears the error message label on GUI load.
	 *
	 * @param arg0 the location used to resolve relative paths for the root object
	 * @param arg1 the resources used to localize the root object
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		ErrorMsgLabel.setText(""); // Clear error message on GUI load
	}
	/**
	 * Called on successful login.
	 * Loads the user-specific view based on the role and closes the login window.
	 *
	 * @param link the path to the FXML file to load
	 */
	public void onLoginSuccess(String link) {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/" + link)); // prepend '/' to search from classpath root
	        Parent root = loader.load();

	        Stage stage = new Stage();
	        stage.setTitle("View");
	        stage.setScene(new Scene(root));
	        stage.show();

	        // Close the login window
	        Stage currentStage = (Stage) usernameInputField.getScene().getWindow();
	        currentStage.close();
	    } catch (IOException e) {
	        System.err.println("Failed to load FXML: " + link);
	        e.printStackTrace();
	    }
	}
	/**
	 * Called on login failure.
	 * Clears input fields and displays an error message.
	 */
	public void onLoginFailure() {
		usernameInputField.clear();
		passwordInputField.clear();
		ErrorMsgLabel.setText("Username or Password is incorrect"); // Error ==> username does not exist
		this.ErrorMsgLabel.setTextFill(Color.web("#DC143C"));
	}
}
