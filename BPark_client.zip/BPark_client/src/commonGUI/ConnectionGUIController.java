package commonGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.BParkClient;
import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * The {@code ConnectionGUIController} class manages the initial server
 * connection screen. It allows the user to enter the server address and
 * attempts to establish a connection to the BPARK server using the
 * {@link BParkClient} singleton.
 *
 * <p>
 * It also provides navigation to the Login page on successful connection, and
 * displays error messages on failure.
 * </p>
 *
 * <ul>
 * <li>Handles Connect and Exit buttons</li>
 * <li>Manages server address input</li>
 * <li>Transitions to Login page after connection</li>
 * </ul>
 *
 * @author Vaad
 * @version 1.0
 */
public class ConnectionGUIController implements Initializable {
	private String server_connection_data;

	@FXML
	private Button connectBtn;

	@FXML
	private Label txtId;

	@FXML
	private Button exitBtn;

	@FXML
	private TextField inputField;

	/**
	 * Starts and displays the connection GUI.
	 *
	 * @param primaryStage the primary stage of the JavaFX application
	 * @throws Exception if loading the FXML fails
	 */
	public void start(@SuppressWarnings("exports") Stage primaryStage) throws Exception {
		Parent root = FXMLLoader.<Parent>load(getClass().getResource("/commonGUI/connectionGUI.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Client Connect");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	/**
	 * Handles the Exit button click. Closes the client connection if connected, and
	 * exits the application.
	 *
	 * @param event the ActionEvent triggered by the button
	 * @throws Exception if there is an error during quit
	 */
	@FXML
	void ExitBtn(ActionEvent event) throws Exception {
		if (ClientUI.bParkClient != null && ClientUI.bParkClient.isConnected()) {
			ClientUI.bParkClient.quit(); // This will now notify server

		} else {
			System.exit(0);
		}
	}

	/**
	 * Handles the Connect button click. Attempts to establish a connection to the
	 * server using the provided address. Navigates to the Login page on success or
	 * shows an error on failure.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	void ConnectBtn(ActionEvent event) {
		this.server_connection_data = inputField.getText();
		try {
			if (ClientUI.bParkClient != null && ClientUI.bParkClient.isConnected()) {
				// Already connected, no need to reconnect
				navigateToLoginPage(event);
				return;
			}
			ClientUI.bParkClient = BParkClient.getInstance(this.server_connection_data, 5555);
			navigateToLoginPage(event);
			ClientUI.bParkClient.requestFromServer("Connect");
		} catch (IOException e) {
			showConnectionError();
		}
	}

	/**
	 * Loads and navigates to the Login page GUI after successful connection.
	 *
	 * @param event the ActionEvent that triggered the navigation
	 * @throws IOException if the FXML file cannot be loaded
	 */
	private void navigateToLoginPage(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
		Pane root = loader.load();
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		primaryStage.setTitle("Client Home Page");
		primaryStage.setScene(new Scene(root));
		primaryStage.show();
	}

	/**
	 * Displays a connection error in the input field and logs to console.
	 */
	private void showConnectionError() {
		inputField.setStyle("-fx-text-fill: #DC143C;");
		inputField.setText("❌ Connection Failed");
		System.err.println("Connection Error");
	}

	/**
	 * Initializes the controller by setting the default server address.
	 *
	 * @param arg0 the location used to resolve relative paths for the root object
	 * @param arg1 the resources used to localize the root object
	 */

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.inputField.setText("localhost");
	}
}
