package client;

import commonGUI.ConnectionGUIController;
import commonGUI.LoginPageGUIController;
import javafx.application.Platform;
import managerGUI.ManagerAddParkingsController;
import managerGUI.ManagerNewSubscriberController;
import managerGUI.ManagerViewParkingsController;
import managerGUI.ManagerViewReportsController;
import managerGUI.ManagerViewSubscriberDetailsController;
import managerGUI.ManagerViewUsersController;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import attendantGUI.AttendantNewSubscriberController;
import attendantGUI.AttendantViewParkingsController;
import attendantGUI.AttendantViewSubscriberDetailsController;
import subscriberGUI.DepositCarController;
import subscriberGUI.NewOrderGUIController;
import subscriberGUI.ReservationsPageGUIController;
import subscriberGUI.SubscriberViewDetailsController;
import subscriberGUI.SubscriberViewParkingsController;
import subscriberGUI.UpdateEmailController;
import subscriberGUI.UpdatePasswordController;
import subscriberGUI.UpdatePhoneNumberController;
import subscriberGUI.ReceiveCarPageController;
import ocsf.client.AbstractClient;

/**
 * The {@code BParkClient} class represents the client-side networking component
 * of the BPARK parking management system. It extends {@link AbstractClient}
 * from the OCSF framework and facilitates communication between the client GUI
 * and the backend server.
 *
 * <p>
 * This class uses the Singleton design pattern and keeps references to all
 * relevant GUI controllers to allow proper routing of server responses.
 * </p>
 *
 * <p>
 * Main responsibilities include:
 * </p>
 * <ul>
 * <li>Opening and maintaining a connection to the server</li>
 * <li>Sending user requests</li>
 * <li>Receiving server responses</li>
 * <li>Dispatching responses to appropriate GUI controllers based on user
 * role</li>
 * </ul>
 *
 * @author bashar
 * @version 1.0
 */

public class BParkClient extends AbstractClient implements ChatIF {

	public SubscriberViewDetailsController subscriberViewDetailsController;

	private UpdatePhoneNumberController updatePhoneNumberController;

	private AttendantViewParkingsController attendantViewParkingsController;

	private AttendantNewSubscriberController attendantNewSubscriberController;

	private ReservationsPageGUIController reservationsPageGUIController;

	private ConnectionGUIController connectionGUIController;

	private AttendantViewSubscriberDetailsController attendantViewSubscriberDetailsController;

	private ManagerViewParkingsController managerViewParkingsController;

	private SubscriberViewParkingsController subscriberViewParkingsController;

	private ManagerNewSubscriberController managerNewSubscriberController;

	private ManagerViewSubscriberDetailsController managerViewSubscriberDetailsController;

	private ManagerAddParkingsController managerAddParkingsController;

	private ManagerViewReportsController managerViewReportsController;

	private NewOrderGUIController newOrderGUIController;

	@SuppressWarnings("unused")
	private UpdateEmailController updateEmailController;

	private UpdatePasswordController updatePasswordController;

	@SuppressWarnings("unused")
	private LoginPageGUIController loginPageGUIController;

	private ReceiveCarPageController receiveCarPageController;

	private DepositCarController depositCarController;

	private ManagerViewUsersController managerViewUsersController;

	public static final int DEFAULT_PORT = 5555;

	public static BParkClient client;

	ChatIF clientUI;

	private final Map<String, Consumer<String[]>> serverHandlers = new HashMap<>();

	public void setUpdatePasswordController(UpdatePasswordController updatePasswordController) {
		this.updatePasswordController = updatePasswordController;
	}

	public void setSubscriberViewDetailsController(SubscriberViewDetailsController subscriberViewDetailsController) {
		this.subscriberViewDetailsController = subscriberViewDetailsController;
	}

	public void setUpdatePhoneNumberController(UpdatePhoneNumberController updatePhoneNumberController) {
		this.updatePhoneNumberController = updatePhoneNumberController;
	}

	public void setAttendantViewParkingsController(AttendantViewParkingsController attendantViewParkingsController) {
		this.attendantViewParkingsController = attendantViewParkingsController;
	}

	public void setSubscriberViewParkingsController(SubscriberViewParkingsController subscriberViewParkingsController) {
		this.subscriberViewParkingsController = subscriberViewParkingsController;
	}

	public void setManagerViewUsersController(ManagerViewUsersController managerViewUsersController) {
		this.managerViewUsersController = managerViewUsersController;
	}

	public void setDepositCarController(DepositCarController depositCarController) {
		this.depositCarController = depositCarController;
	}

	public void setAttendantNewSubscriberController(AttendantNewSubscriberController attendantNewSubscriberController) {
		this.attendantNewSubscriberController = attendantNewSubscriberController;
	}

	public void setReservationsPageController(ReservationsPageGUIController reservationsPageGUIController) {
		this.reservationsPageGUIController = reservationsPageGUIController;
	}

	public void setConnectionController(ConnectionGUIController connectionGUIController) {
		this.connectionGUIController = connectionGUIController;
	}

	public void setUpdateEmailController(UpdateEmailController updateEmailController) {
		this.updateEmailController = updateEmailController;
	}

	public void setLoginPageGUIController(LoginPageGUIController loginPageGUIController) {
		this.loginPageGUIController = loginPageGUIController;
	}

	public void setReceiveCarPageController(ReceiveCarPageController receiveCarPageController) {
		this.receiveCarPageController = receiveCarPageController;
	}

	public void setAttendantViewSubscriberDetailsController(
			AttendantViewSubscriberDetailsController attendantViewSubscriberDetailsController) {
		this.attendantViewSubscriberDetailsController = attendantViewSubscriberDetailsController;
	}

	public void setManagerViewParkingsController(ManagerViewParkingsController managerViewParkingsController) {
		this.managerViewParkingsController = managerViewParkingsController;
	}

	public void setManagerNewSubscriberController(ManagerNewSubscriberController managerNewSubscriberController) {
		this.managerNewSubscriberController = managerNewSubscriberController;
	}

	public void setManagerViewSubscriberDetailsController(
			ManagerViewSubscriberDetailsController managerViewSubscriberDetailsController) {
		this.managerViewSubscriberDetailsController = managerViewSubscriberDetailsController;
	}

	public void setManagerAddParkingsController(ManagerAddParkingsController managerAddParkingsController) {
		this.managerAddParkingsController = managerAddParkingsController;
	}

	public void setManagerViewReportsController(ManagerViewReportsController managerViewReportsController) {
		this.managerViewReportsController = managerViewReportsController;
	}

	public void setNewOrderGUIController(NewOrderGUIController newOrderGUIController) {
		this.newOrderGUIController = newOrderGUIController;
	}

	/**
	 * Sends a request object to the server.
	 *
	 * @param request the object representing the client request
	 */
	public void requestFromServer(Object Request) {
		try {
			if (isConnected()) {
				sendToServer(Request);
			} else {
				System.exit(1);
			}
		} catch (IOException e) {
			System.out.println("Error sending request to server: " + e.getMessage());
		}
	}

	/**
	 * Constructs a new {@code BParkClient}, connects to the server, and initializes
	 * message handler mappings.
	 *
	 * @param host the server hostname
	 * @param port the port number to connect to
	 */
	public BParkClient(String host, int port) {
		super(host, port);
		this.clientUI = this;
		initializeMessageHandlers();
		try {
			openConnection();
		} catch (IOException e) {
		}
	}

	/**
	 * Displays a message from the server to the standard output.
	 *
	 * @param message the message to be displayed
	 */
	public void display(String message) {
		System.out.print("> " + message);
	}

	/**
	 * Sends a disconnect message to the server and closes the connection.
	 */
	public void disconnectAndNotify() {
		try {
			sendToServer("DISCONNECT_NOTIFICATION"); // Send special message
			closeConnection();
		} catch (IOException e) {
			System.out.println("Error during disconnection: " + e.getMessage());
		}
	}

	/**
	 * Disconnects the client and terminates the application.
	 */

	public void quit() {
		disconnectAndNotify();
		System.exit(0);
	}

	/**
	 * Initializes a map of command strings to handler methods for processing server
	 * responses.
	 */
	public void initializeMessageHandlers() {
		serverHandlers.put("login", this::handleLoginResponse);
		serverHandlers.put("updateEmail", this::handleUpdateEmailResponse);
		serverHandlers.put("updatePhoneNumber", this::handleUpdatePhoneNumber);
		serverHandlers.put("updatePassword", this::handleUpdatePassword);
		serverHandlers.put("showOrders", msg -> handleShowOrders(msg[1]));
		serverHandlers.put("cancelOrder", msg -> handleCancelOrder(msg[1]));
		serverHandlers.put("ReceiveCar", msg -> handleReceiveCarResponse(msg[1]));
		serverHandlers.put("sendParkingCodeViaEmail", msg -> handeSendParkingCodeViaEmail(msg[1]));
		serverHandlers.put("requestExtesnsion", msg -> handleRequestExtension(msg[1]));
		serverHandlers.put("ViewParkings", msg -> handleViewParkings(msg[1], msg[2], msg[3]));
		serverHandlers.put("addNewSubscriber", msg -> handleNewSubscriber(msg[1], msg[2]));
		serverHandlers.put("ViewSubscriberDetails", this::handleViewSubscriberDetails);
		serverHandlers.put("AddParkings", msg -> handleAddParkings(msg[1]));
		serverHandlers.put("reports", this::handleShowReports);
		serverHandlers.put("checkAvailability", msg -> handleNewOrderResponse(msg[1]));
		serverHandlers.put("addNewOrder", msg -> handleNewOrderResponse(msg[1]));
		serverHandlers.put("checkAvailablityNow", this::handleCheckAvailablityNow);
		serverHandlers.put("depositeCar", this::handleCheckAvailablityNow);
		serverHandlers.put("createImmediateOrder", this::handleCheckAvailablityNow);
		serverHandlers.put("viewUsersFromDB", this::handleShowUsers);
	}

	/**
	 * Dispatches an incoming message from the server to the appropriate handler.
	 *
	 * @param msg the message received from the server
	 */
	public void handleMessageFromServer(Object msg) {
		try {
			String[] message = (String[]) msg;
			String command = message[0];
			Consumer<String[]> handler = serverHandlers.get(command);
			if (handler != null) {
				handler.accept(message);
			} else {
				System.err.println("Unhandled server command: " + command);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	old handle message from server, replaced with hash
//	public void handleMessageFromServer(Object msg) {
//		String[] message = (String[]) msg;
//		if (message[0].equals("login"))
//			handleLoginResponse(message);
//		else if (message[0].equals("updateEmail"))
//			handleUpdateEmailResponse(message);
//		else if (message[0].equals("updatePhoneNumber"))
//			handleUpdatePhoneNumber(message);
//		else if (message[0].equals("updatePassword"))
//			handleUpdatePassword(message);
//		else if (message[0].equals("showOrders"))
//			handleShowOrders(message[1]);
//		else if (message[0].equals("cancelOrder"))
//			handleCancelOrder(message[1]);
//		else if (message[0].equals("ReceiveCar"))
//			handleReceiveCarResponse(message[1]);
//		else if (message[0].equals("sendParkingCodeViaEmail"))
//			handeSendParkingCodeViaEmail(message[1]);
//		else if (message[0].equals("requestExtesnsion"))
//			handleRequestExtension(message[1]);
//		else if (message[0].equals("ViewParkings"))
//			handleViewParkings(message[1], message[2], message[3]);
//		else if (message[0].equals("addNewSubscriber"))
//			handleNewSubscriber(message[1], message[2]);
//		else if (message[0].equals("ViewSubscriberDetails"))
//			handleViewSubscriberDetails(message);
//		else if(message[0].equals("AddParkings"))
//			handleAddParkings(message[1]);
//		else if(message[0].equals("reports"))
//			handleShowReports(message);
//		else if(message[0].equals("checkAvailability") || message[0].equals("addNewOrder"))
//			handleNewOrderResponse(message[1]);
//		else if(message[0].equals("checkAvailablityNow"))
//			handleCheckAvailablityNow(message);
//		else if(message[0].equals("depositeCar") || message[0].equals("createImmediateOrder"))
//			handleCheckAvailablityNow(message);
//		else if(message[0].equals("viewUsersFromDB"))
//			handleShowUsers(message);
//		}

	/**
	 * Handles the server response to show all users in the manager view.
	 *
	 * @param msg The server message containing user data.
	 */
	private void handleShowUsers(String[] msg) {
		Platform.runLater(() -> {
			if (ManagerViewUsersController.instance != null) {
				ManagerViewUsersController.instance.ShowUsers(msg);
			}
		});
	}

	/**
	 * Handles responses for immediate availability checks and car deposits.
	 *
	 * @param response The server message with availability data.
	 */
	private void handleCheckAvailablityNow(String[] response) { // the same for checkAvailablityNow and depositeCar
		Platform.runLater(() -> {
			if (DepositCarController.instance != null) {
				DepositCarController.instance.showServerResponse(response);
			}
		});

	}

	/**
	 * Handles the response for creating or checking a new order.
	 *
	 * @param response The server message with order status.
	 */
	private void handleNewOrderResponse(String response) {
		Platform.runLater(() -> {
			if (NewOrderGUIController.instance != null) {
				NewOrderGUIController.instance.showServerResponse(response);
			}
		});

	}

	/**
	 * Displays reports sent from the server to the manager reports controller.
	 *
	 * @param msg The server message containing report data.
	 */
	private void handleShowReports(String[] msg) {
		Platform.runLater(() -> {
			if (ManagerViewReportsController.instance != null) {
				ManagerViewReportsController.instance.ShowReports(msg);
			}
		});
	}

	/**
	 * Handles the server response for adding new parking spots.
	 *
	 * @param msg The server message confirming addition.
	 */
	private void handleAddParkings(String msg) {
		Platform.runLater(() -> {
			if (ManagerAddParkingsController.instance != null) {
				ManagerAddParkingsController.instance.ShowMsg(msg);
			}
		});
	}

	/**
	 * Handles the server response with subscriber details, routing to attendant or
	 * manager view.
	 *
	 * @param msg The server message with subscriber data.
	 */
	private void handleViewSubscriberDetails(String[] msg) {
		Platform.runLater(() -> {
			if (msg[1].equals("attendant")) {
				if (AttendantViewSubscriberDetailsController.instance != null) {
					AttendantViewSubscriberDetailsController.instance.DisplaySubscriber(msg);
				}
			} else if (msg[1].equals("subscriber")) {
				if (SubscriberViewDetailsController.instance != null) {
					SubscriberViewDetailsController.instance.DisplaySubscriber(msg);
				}
			} else {
				if (ManagerViewSubscriberDetailsController.instance != null) {
					ManagerViewSubscriberDetailsController.instance.DisplaySubscriber(msg);
				}
			}
		});
	}

	/**
	 * Handles confirmation of new subscriber creation.
	 *
	 * @param user The user role (attendant or manager).
	 * @param msg  The server response message.
	 */
	private void handleNewSubscriber(String user, String msg) {

		Platform.runLater(() -> {
			if (user.equals("attendant")) {
				if (AttendantNewSubscriberController.instance != null) {
					AttendantNewSubscriberController.instance.ShowMsg(msg);
				}
			} else {
				if (ManagerNewSubscriberController.instance != null) {
					ManagerNewSubscriberController.instance.ShowMsg(msg);
				}
			}
		});
	}

	/**
	 * Displays available and taken parking spots to the appropriate GUI.
	 *
	 * @param user       The user role (manager or attendant).
	 * @param takens     Taken parking data.
	 * @param availables Available parking data.
	 */
	private void handleViewParkings(String user, String takens, String availables) {
		Platform.runLater(() -> {
			if (user.equals("manager")) {
				if (ManagerViewParkingsController.instance != null) {
					ManagerViewParkingsController.instance.DisplayParkings(availables, takens);
				}
			} else if (user.equals("subscriber")) {
				if (SubscriberViewParkingsController.instance != null) {
					SubscriberViewParkingsController.instance.DisplayAvailableParkings(availables);
				}
			} else {
				if (AttendantViewParkingsController.instance != null) {
					AttendantViewParkingsController.instance.DisplayParkings(availables, takens);
				}
			}
		});
	}

	/**
	 * Handles the server response for reservation extension requests.
	 *
	 * @param msg The server response message.
	 */

	private void handleRequestExtension(String msg) {
		Platform.runLater(() -> {
			if (ReservationsPageGUIController.instance != null) {
				ReservationsPageGUIController.instance.showMsg(msg);
			}
		});
	}

	/**
	 * Handles the server response for sending a parking code via email.
	 *
	 * @param message The server response message.
	 */
	private void handeSendParkingCodeViaEmail(String message) {
		Platform.runLater(() -> {
			if (receiveCarPageController.instance != null) {
				receiveCarPageController.instance.displayServerMessage(message);
			}
		});

	}

	/**
	 * Handles the server response for receiving a car.
	 *
	 * @param msg The server response message.
	 */
	private void handleReceiveCarResponse(String msg) {
		Platform.runLater(() -> {
			if (receiveCarPageController.instance != null) {
				receiveCarPageController.instance.displayServerMessage(msg);
			}
		});
	}

	/**
	 * Handles the server response for cancelling an order.
	 *
	 * @param msg The server response message.
	 */
	private void handleCancelOrder(String msg) {
		Platform.runLater(() -> {
			if (ReservationsPageGUIController.instance != null) {
				ReservationsPageGUIController.instance.showMsg(msg);
				ReservationsPageGUIController.instance.ActiveCheckBox(null);
			}
		});
	}

	/**
	 * Displays a list of orders for the subscriber.
	 *
	 * @param str The server message containing order details.
	 */
	private void handleShowOrders(String str) {
		if (str.equals("User not found") || str.equals("Error retrieving orders")) {
			Platform.runLater(() -> {
				if (ReservationsPageGUIController.instance != null) {
					ReservationsPageGUIController.instance.showMsg(str);
				}
			});
		} else {
			Platform.runLater(() -> {
				if (ReservationsPageGUIController.instance != null) {
					ReservationsPageGUIController.instance.Display(str);
				}
			});
		}

	}

	/**
	 * Handles the server response for updating the user's password.
	 *
	 * @param message The server response message.
	 */
	private void handleUpdatePassword(String[] message) {
		if (message[1].equals("Update Successful")) {
			Platform.runLater(() -> {
				if (UpdatePasswordController.instance != null) {
					UpdatePasswordController.instance.showMsg("Password Updated Successfully");
				}
			});
		} else if (message[1].equals("Update Failed")) {
			Platform.runLater(() -> {
				if (UpdatePasswordController.instance != null) {
					UpdatePasswordController.instance.showMsg("Something Went Wrong, Please Try Agian!");
				}
			});
		}
	}

	/**
	 * Handles the server response for updating the user's phone number.
	 *
	 * @param message The server response message.
	 */
	private void handleUpdatePhoneNumber(String[] message) {
		if (message[1].equals("Update Successful")) {
			Platform.runLater(() -> {
				if (UpdatePhoneNumberController.instance != null) {
					UpdatePhoneNumberController.instance.showMsg("Phone Number Updated Successfully");
				}
			});
		} else if (message[1].equals("Update Failed")) {
			Platform.runLater(() -> {
				if (UpdatePhoneNumberController.instance != null) {
					UpdatePhoneNumberController.instance.showMsg("Something Went Wrong, Please Try Agian!");
				}
			});
		}
	}

	/**
	 * Handles the server response for updating the user's email address.
	 *
	 * @param message The server response message.
	 */
	private void handleUpdateEmailResponse(String[] message) {
		if (message[1].equals("Update Successful")) {
			Platform.runLater(() -> {
				if (UpdateEmailController.instance != null) {
					UpdateEmailController.instance.showMsg("Email Updated Successfully");
				}
			});
		} else if (message[1].equals("Update Failed")) {
			Platform.runLater(() -> {
				if (UpdateEmailController.instance != null) {
					UpdateEmailController.instance.showMsg("Something Went Wrong, Please Try Agian!");
				}
			});
		}
	}

	/**
	 * Handles the server response for login attempts, routing users to the correct
	 * GUI based on role.
	 *
	 * @param message The server response message.
	 */
	private void handleLoginResponse(String[] message) {
		// username and password found successfully
		if ("isThere".equals(message[1])) {
			Platform.runLater(() -> {
				if (LoginPageGUIController.instance != null) {
					User.getInstance().setUsername(message[3]);
					if (message[2].equals("subscriber")) {
						User.getInstance().setType(message[2]);
						LoginPageGUIController.instance.onLoginSuccess("subscriberGUI/SubscriberViewReservations.fxml");
					} else if (message[2].equals("attendant")) {
						User.getInstance().setType(message[2]);
						LoginPageGUIController.instance.onLoginSuccess("attendantGUI/AttendantViewParkings.fxml");
					} else if (message[2].equals("manager")) {
						User.getInstance().setType(message[2]);
						LoginPageGUIController.instance.onLoginSuccess("managerGUI/ManagerViewParkings.fxml");
					}
				}
			});
			// username and password are wrong insserted
		} else if ("notThere".equals(message[1])) {
			Platform.runLater(() -> {
				if (LoginPageGUIController.instance != null) {
					LoginPageGUIController.instance.onLoginFailure();
				}
			});
		}
	}

	/**
	 * Returns the singleton instance of {@code BParkClient}. Creates it if it does
	 * not yet exist or if the existing instance is disconnected. Uses thread-safe
	 * lazy initialization.
	 *
	 * @param host the server hostname
	 * @param port the server port number
	 * @return the singleton instance of {@code BParkClient}
	 * @throws IOException if opening the connection fails
	 */
	public static BParkClient getInstance(String host, int port) throws IOException {
		if (client == null || !client.isConnected()) {
			synchronized (BParkClient.class) {
				if (client == null || !client.isConnected()) {
					client = new BParkClient(host, port);
				}
			}
		}
		return client;
	}

	/**
	 * Returns the singleton instance of the client. Creates it if not yet created
	 * or disconnected.
	 *
	 * @param host server hostname
	 * @param port server port
	 * @return singleton instance of {@code BParkClient}
	 * @throws IOException if connection fails
	 */
	public static void createInstance(String host, int port) throws IOException {
		if (client == null) {
			client = new BParkClient(host, port);
		}
	}

}
