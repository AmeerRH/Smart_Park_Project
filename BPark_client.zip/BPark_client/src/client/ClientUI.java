package client;

/**
 * The {@code ClientUI} class is the entry point of the BPARK client application.
 * It extends {@link javafx.application.Application} to launch the JavaFX GUI.
 * 
 * <p>Responsibilities:</p>
 * <ul>
 *   <li>Starting the initial connection screen.</li>
 *   <li>Holding a static reference to the {@link BParkClient} instance.</li>
 * </ul>
 *
 * <p>This class uses {@link ConnectionGUIController} to manage the first GUI screen.</p>
 *
 * @author bashar
 * @version 1.0
 */
import commonGUI.ConnectionGUIController;
import javafx.application.Application;
import javafx.stage.Stage;

public class ClientUI extends Application {
	ConnectionGUIController connectionGUIController;
	/**
	 * The singleton client instance shared across the application.
	 */
	public static BParkClient bParkClient;

	/**
	 * The main entry point. Launches the JavaFX application.
	 *
	 * @param args command-line arguments
	 */
	public static void main(String[] args) {
		launch(args);
	}

	/**
	 * Starts the JavaFX application by loading the initial connection screen.
	 *
	 * @param primaryStage the primary stage for this application
	 * @throws Exception if an error occurs during startup
	 */

	@Override
	public void start(@SuppressWarnings("exports") Stage primaryStage) throws Exception {
		this.connectionGUIController = new ConnectionGUIController();
		this.connectionGUIController.start(primaryStage);
	}
}
