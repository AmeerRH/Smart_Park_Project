package client;

/**
 * The {@code Parking} class represents a single parking spot in the BPARK
 * system. It contains information such as the parking number, current status
 * (available/taken), the owner's ID, order number, and reservation times.
 *
 * <p>
 * This class is also designed to support JavaFX TableView for easy display in
 * the UI.
 * </p>
 *
 * @author Vaad
 * @version 1.0
 */

public class Parking {
	private String parkingNumber;
	private String status;
	private String ownerID;
	private String orderNumber;
	private String takenUntil;
	private String takenFrom;

	/**
	 * Constructs a {@code Parking} object with all its details.
	 *
	 * @param parkingNumber the parking spot number
	 * @param status        the current status (e.g. "Available", "Taken")
	 * @param ownerID       the ID of the car owner (if occupied)
	 * @param orderNumber   the order associated with the reservation
	 * @param takenUntil    the time until which the spot is reserved
	 * @param takenFrom     the time from which the spot is reserved
	 */
	public Parking(String parkingNumber, String status, String ownerID, String orderNumber, String takenUntil,
			String takenFrom) {
		this.parkingNumber = parkingNumber;
		this.status = status;
		this.ownerID = ownerID;
		this.orderNumber = orderNumber;
		this.takenUntil = takenUntil;
		this.takenFrom = takenFrom;
	}

	/**
	 * Gets the parking spot number.
	 * 
	 * @return the parking number
	 */

	public String getParkingNumber() {
		return parkingNumber;
	}

	/**
	 * Sets the parking spot number.
	 * 
	 * @param parkingNumber the new parking number
	 */
	public void setParkingNumber(String parkingNumber) {
		this.parkingNumber = parkingNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOwnerID() {
		return ownerID;
	}

	public void setOwnerID(String ownerID) {
		this.ownerID = ownerID;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getTakenUntil() {
		return takenUntil;
	}

	public void setTakenUntil(String takenUntil) {
		this.takenUntil = takenUntil;
	}

	public String getTakenFrom() {
		return takenFrom;
	}

	public void setTakenFrom(String takenUntil) {
		this.takenFrom = takenUntil;
	}

	@Override
	public String toString() {
		return parkingNumber + ";" + status + ";" + (ownerID != null ? ownerID : "") + ";"
				+ (orderNumber != null ? orderNumber : "") + ";" + (takenFrom != null ? takenFrom : "") + ";"
				+ (takenUntil != null ? takenUntil : "");
	}

}
