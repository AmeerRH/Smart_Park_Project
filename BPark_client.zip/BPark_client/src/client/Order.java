package client;

/**
 * The {@code Order} class represents a reservation or parking order in the
 * BPARK system. It contains all relevant details such as parking number, order
 * number, scheduled dates and times, user information, confirmation code, and
 * order status.
 *
 * <p>
 * This class is designed to be compatible with JavaFX TableView.
 * </p>
 *
 * @author bashar
 * @version 1.0
 */
public class Order {
	private int parkingNumber;
	private int orderNumber;
	private String orderDate;
	private String orderTime;
	private String scheduledDate;
	private String scheduledTimeArrive;
	private String scheduledTimeLeave;
	private int userId;
	private int confirmationCode;
	private String orderStatus;

	/**
	 * Default no-argument constructor. Required for JavaFX TableView and frameworks
	 * that use reflection.
	 */

	public Order() {
	}

	/**
	 * Constructs an {@code Order} with all details.
	 *
	 * @param parkingNumber       the parking spot number
	 * @param orderNumber         the unique order number
	 * @param orderDate           the date the order was created
	 * @param orderTime           the time the order was created
	 * @param scheduledDate       the scheduled parking date
	 * @param scheduledTimeArrive the planned arrival time
	 * @param scheduledTimeLeave  the planned departure time
	 * @param userId              the ID of the user who made the order
	 * @param confirmationCode    the code confirming the order
	 * @param orderStatus         the current status of the order
	 */
	public Order(int parkingNumber, int orderNumber, String orderDate, String orderTime, String scheduledDate,
			String scheduledTimeArrive, String scheduledTimeLeave, int userId, int confirmationCode,
			String orderStatus) {
		this.parkingNumber = parkingNumber;
		this.orderNumber = orderNumber;
		this.orderDate = orderDate;
		this.orderTime = orderTime;
		this.scheduledDate = scheduledDate;
		this.scheduledTimeArrive = scheduledTimeArrive;
		this.scheduledTimeLeave = scheduledTimeLeave;
		this.userId = userId;
		this.confirmationCode = confirmationCode;
		this.orderStatus = orderStatus;
	}

	// Getters and setters
	public int getParkingNumber() {
		return parkingNumber;
	}

	public void setParkingNumber(int parkingNumber) {
		this.parkingNumber = parkingNumber;
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	public String getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(String scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getScheduledTimeArrive() {
		return scheduledTimeArrive;
	}

	public void setScheduledTimeArrive(String scheduledTimeArrive) {
		this.scheduledTimeArrive = scheduledTimeArrive;
	}

	public String getScheduledTimeLeave() {
		return scheduledTimeLeave;
	}

	public void setScheduledTimeLeave(String scheduledTimeLeave) {
		this.scheduledTimeLeave = scheduledTimeLeave;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getConfirmationCode() {
		return confirmationCode;
	}

	public void setConfirmationCode(int confirmationCode) {
		this.confirmationCode = confirmationCode;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	@Override
	public String toString() {
		return "Order{" + "parkingNumber=" + parkingNumber + ", orderNumber=" + orderNumber + ", orderDate='"
				+ orderDate + '\'' + ", orderTime='" + orderTime + '\'' + ", scheduledDate='" + scheduledDate + '\''
				+ ", scheduledTimeArrive='" + scheduledTimeArrive + '\'' + ", scheduledTimeLeave='" + scheduledTimeLeave
				+ '\'' + ", userId=" + userId + ", confirmationCode=" + confirmationCode + ", orderStatus='"
				+ orderStatus + '\'' + '}';
	}
}
