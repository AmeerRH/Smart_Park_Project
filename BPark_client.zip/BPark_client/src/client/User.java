package client;

/**
 * The {@code User} class is a Singleton that represents the currently logged-in
 * user in the BPARK system. It holds the username and the user type (e.g.
 * subscriber, attendant, manager).
 *
 * <p>
 * This Singleton ensures that user information is accessible from anywhere in
 * the client application.
 * </p>
 *
 * @author Vaad
 * @version 1.0
 */
public class User {
	private static User instance;
	private String username;
	private String type;

	/**
	 * Private constructor to enforce Singleton pattern.
	 */
	private User() {
		// private constructor to prevent instantiation
	}

	/**
	 * Returns the Singleton instance of {@code User}, creating it if it does not
	 * exist.
	 *
	 * @return the singleton User instance
	 */

	public static User getInstance() {
		if (instance == null) {
			instance = new User();
		}
		return instance;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void clear() {
		this.username = null;
		this.type = null;
	}
}
