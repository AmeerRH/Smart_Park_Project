package subscriberGUI;

import client.ClientUI;
import client.Parking;
import client.User;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * The {@code SubscriberViewParkingsController} class manages the JavaFX
 * interface where subscribers can view the list of available parking spots in
 * the BPARK system.
 *
 * <p>
 * Main responsibilities include:
 * </p>
 * <ul>
 * <li>Displaying a table of available parking spots</li>
 * <li>Auto-refreshing parking data periodically</li>
 * <li>Navigating to other subscriber-related screens</li>
 * </ul>
 *
 * <p>
 * Uses JavaFX components such as {@link TableView}, {@link TableColumn},
 * {@link Button}, and {@link Label} for interaction and display.
 * </p>
 *
 * @author waad
 * @version 1.0
 */

public class SubscriberViewParkingsController {
	public static SubscriberViewParkingsController instance;

	@FXML
	private Label usernameLabel;

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private TableView<Parking> dataTable;

	@FXML
	private TableColumn<Parking, String> parkingNumberCol;

	@FXML
	private TableColumn<Parking, String> statusCol;

	@FXML
	private Label ServerMsgLabel;

	private ObservableList<Parking> parkingData = FXCollections.observableArrayList();

	/**
	 * Initializes the View Parkings screen by setting up the table, binding
	 * controller, and loading available parking data with auto-refresh.
	 */

	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(User.getInstance().getUsername()); // Set username dynamically if needed
		setupTable();
		ServerMsgLabel.setText("");
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setSubscriberViewParkingsController(this);
			refreshParkings(); // First load
			startAutoRefresh(); // Start periodic auto-refresh
		}
	}

	/**
	 * Configures table columns for displaying parking number and status.
	 */

	private void setupTable() {
		parkingNumberCol.setCellValueFactory(new PropertyValueFactory<>("parkingNumber"));
		statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
	}

	/**
	 * Sends a request to the server to fetch the latest parking availability data.
	 */

	private void refreshParkings() {
		String[] toSend = { "viewParkings", "subscriber" };
		ClientUI.bParkClient.requestFromServer(toSend);
	}

	/**
	 * Starts a periodic refresh of the parking data every 10 seconds.
	 */

	private void startAutoRefresh() {
		Timeline refreshTimeline = new Timeline(new KeyFrame(Duration.seconds(10), event -> {
			refreshParkings();
		}));
		refreshTimeline.setCycleCount(Animation.INDEFINITE);
		refreshTimeline.play();
	}

	/**
	 * Logs out the user and navigates to the login screen.
	 *
	 * @param event the ActionEvent triggered by the Exit button
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View My Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Reservations page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Deposit Car page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Receive Car page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the New Order page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Email page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Password page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the current View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Parses and displays available parking spots from a server response string.
	 *
	 * @param msgAvailable a string containing parking data in the format:
	 *                     "parkingNumber;status|parkingNumber;status|..."
	 */

	public void DisplayAvailableParkings(String msgAvailable) {
		ObservableList<Parking> parkingData = FXCollections.observableArrayList();

		if (msgAvailable == null || msgAvailable.isEmpty())
			return;

		String[] records = msgAvailable.split("\\|");
		for (String record : records) {
			String[] fields = record.split(";");
			Parking parking = new Parking(getField(fields, 0), // parkingNumber
					getField(fields, 1), // status
					"", // ownerID (empty for available)
					"", // orderNumber
					"", // takenUntil
					"" // takenFrom
			);
			parkingData.add(parking);
		}

		dataTable.setItems(parkingData);
	}

	/**
	 * Utility method to safely extract a field from a string array.
	 *
	 * @param fields the array of field values
	 * @param index  the index to retrieve
	 * @return the field value at the specified index, or an empty string if out of
	 *         bounds
	 */

	private String getField(String[] fields, int index) {
		return (index < fields.length && fields[index] != null) ? fields[index] : "";
	}
}
