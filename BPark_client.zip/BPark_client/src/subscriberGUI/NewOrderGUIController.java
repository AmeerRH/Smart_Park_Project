package subscriberGUI;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import client.ClientUI;
import client.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * The {@code NewOrderGUIController} class manages the JavaFX screen where
 * subscribers can create new parking orders in the BPARK system.
 *
 * <p>
 * Main responsibilities include:
 * </p>
 * <ul>
 * <li>Allowing the user to select a date and time range for a new parking
 * order</li>
 * <li>Validating user input (time, duration, date range)</li>
 * <li>Sending requests to the server to check availability or add new
 * orders</li>
 * <li>Displaying feedback and enabling/disabling the confirmation button</li>
 * <li>Providing navigation to other subscriber pages</li>
 * </ul>
 *
 * <p>
 * Uses JavaFX components such as {@link Button}, {@link Spinner},
 * {@link DatePicker}, and {@link Label}.
 * </p>
 *
 * @author waad
 * @version 1.0
 */

public class NewOrderGUIController {
	public static NewOrderGUIController instance;

	@FXML
	private DatePicker DateInput;
	@FXML
	private Button confirmButton;
	@FXML
	private Button backButton;
	@FXML
	private Label ServerMsgLabel;
	@FXML
	private Button checkAvailabilityBtn;
	@FXML
	private Spinner<Integer> startTimeHoursField;
	@FXML
	private Spinner<Integer> startTimeMinutesField;
	@FXML
	private Spinner<Integer> endTimeHoursField;
	@FXML
	private Spinner<Integer> endTimeMinutesField;
	@FXML
	private Label usernameLabel;

	private String currentUsername = User.getInstance().getUsername();

	/**
	 * Initializes the New Order screen, setting up spinners, labels, and controller
	 * references.
	 */
	@FXML
	void initialize() {
		instance = this;
		confirmButton.setDisable(true);
		usernameLabel.setText(currentUsername);

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setNewOrderGUIController(this);
		}

		// Set spinner value factories for start time
		startTimeHoursField.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 23, 6)); // Default
																											// 06:00
		startTimeMinutesField.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 45, 0, 15)); // 0,
																													// 15,
																													// 30,
																													// 45

		// Set default values for end time
		endTimeHoursField.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 23, 7));
		endTimeMinutesField.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 45, 0, 15));

		// Disable direct editing
		startTimeHoursField.setEditable(false);
		startTimeMinutesField.setEditable(false);
		endTimeHoursField.setEditable(false);
		endTimeMinutesField.setEditable(false);
		ServerMsgLabel.setText("");
	}

	/**
	 * Navigates to the View Reservations screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Logs the user out and navigates to the Login screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View My Details screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Reservations screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Deposit Car screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Receive Car screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the New Order screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Email screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Password screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Validates the selected date and time, ensures duration limits, and sends a
	 * request to the server to check parking availability.
	 *
	 * @param event the ActionEvent triggered by the Check Availability button
	 */
	@FXML
	void CheckAvailabilityBtn(ActionEvent event) {
		String[] toSend = new String[5];
		toSend[0] = "checkAvailability";

		LocalDate date = DateInput.getValue();
		if (date == null) {
			ServerMsgLabel.setText("❌ Please select a date.");
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
			return;
		}

		try {
			int startHour = startTimeHoursField.getValue();
			int startMin = startTimeMinutesField.getValue();
			int endHour = endTimeHoursField.getValue();
			int endMin = endTimeMinutesField.getValue();

			if (startTimeHoursField.getValue() == null || startTimeMinutesField.getValue() == null
					|| endTimeHoursField.getValue() == null || endTimeMinutesField.getValue() == null) {
				ServerMsgLabel.setText("❌ Please fill all time fields.");
				ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
				return;
			}

			LocalTime start = LocalTime.of(startHour, startMin);
			LocalTime end = LocalTime.of(endHour, endMin);

			if (!validateNewOrderTime(date, start)) {
				ServerMsgLabel.setText("❌ Date and time must be between 24 hours and 7 days from now.");
				ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
				return;
			}

			if (!end.isAfter(start)) {
				ServerMsgLabel.setText("❌ End time must be after start time.");
				ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
				return;
			}

			long durationMinutes = java.time.Duration.between(start, end).toMinutes();
			if (durationMinutes > 240) {
				ServerMsgLabel.setText("❌ Duration cannot exceed 4 hours.");
				ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
				return;
			}

			String startTime = String.format("%02d:%02d", startHour, startMin);
			String endTime = String.format("%02d:%02d", endHour, endMin);

			toSend[1] = date.toString();
			toSend[2] = startTime;
			toSend[3] = endTime;
			toSend[4] = User.getInstance().getUsername();

			if (ClientUI.bParkClient != null) {
				ClientUI.bParkClient.setNewOrderGUIController(this);
				ServerMsgLabel.setStyle("Sending availability request...");
				ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
				ClientUI.bParkClient.requestFromServer(toSend);
			}

		} catch (NullPointerException | DateTimeParseException e) {
			ServerMsgLabel.setText("❌ Invalid time selection.");
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
			e.printStackTrace();
		}
	}

	/**
	 * Validates user inputs and sends a request to the server to add a new parking
	 * order.
	 *
	 * @param event the ActionEvent triggered by the Confirm button
	 */
	@FXML
	void handleConfirm(ActionEvent event) {
		String[] toSend = new String[7];
		toSend[0] = "addNewOrder";

		// Get date
		LocalDate date = DateInput.getValue();
		if (date == null) {
			ServerMsgLabel.setText("❌ Please select a date.");
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
			return;
		}

		try {
			// Get values from spinners
			int startHour = startTimeHoursField.getValue();
			int startMin = startTimeMinutesField.getValue();
			int endHour = endTimeHoursField.getValue();
			int endMin = endTimeMinutesField.getValue();
			// Ensure all spinners have values
			if (startTimeHoursField.getValue() == null || startTimeMinutesField.getValue() == null
					|| endTimeHoursField.getValue() == null || endTimeMinutesField.getValue() == null) {
				ServerMsgLabel.setText("❌ Please fill all time fields.");
				ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
				return;
			}
			// Format values to strings with leading zeros
			String startTime = String.format("%02d:%02d", startHour, startMin);
			String endTime = String.format("%02d:%02d", endHour, endMin);

			LocalTime start = LocalTime.of(startHour, startMin);
			LocalTime end = LocalTime.of(endHour, endMin);

			if (start.isAfter(end) || start.equals(end)) {
				ServerMsgLabel.setText("❌ End time must be after start time.");
				ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
				return;
			}

			if (java.time.Duration.between(start, end).toHours() > 4) {
				ServerMsgLabel.setText("❌ Duration cannot exceed 4 hours.");
				ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
				return;
			}

			// Set data to send
			toSend[1] = date.toString(); // Date
			toSend[2] = startTime; // Start Time
			toSend[3] = endTime; // End Time
			toSend[4] = User.getInstance().getUsername(); // Username
			toSend[5] = String.valueOf(generateRandomCode());
			toSend[6] = String.valueOf(generateConfirmationCode());

			if (ClientUI.bParkClient != null) {
				ClientUI.bParkClient.setNewOrderGUIController(this);
				ServerMsgLabel.setStyle("Sending new order request...");
				ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
				ClientUI.bParkClient.requestFromServer(toSend);
			}

		} catch (NullPointerException | DateTimeParseException e) {
			ServerMsgLabel.setText("❌ Invalid time selection.");
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
			e.printStackTrace();
		}
	}

	/**
	 * Generates a random 4-digit code for order identification.
	 *
	 * @return the generated code
	 */

	private int generateRandomCode() {
		return (int) (Math.random() * 9000) + 1000; // טווח 1000–9999
	}

	/**
	 * Generates a random confirmation code for the new order.
	 *
	 * @return the generated confirmation code
	 */
	private int generateConfirmationCode() {
		return (int) (Math.random() * 999000) + 1000; // טווח 1000–999999
	}

	/**
	 * Handles server responses by updating the UI with availability status and
	 * feedback messages.
	 *
	 * @param msg the server response message
	 */
	public void showServerResponse(String msg) {
		Platform.runLater(() -> {

			if (msg.contains("Order can be placed")) {
				confirmButton.setDisable(false);
				ServerMsgLabel.setText(msg + " You can press the button to confirm adding the order.");
				ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
			} else if (msg.contains("Not enough availability")) {
				confirmButton.setDisable(true);
				ServerMsgLabel.setText(msg + " Try another timing to park!");
				ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
			} else if (msg.contains("Order added successfully")) {
				confirmButton.setDisable(true);
				ServerMsgLabel.setText(msg);
				ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
			} else {
				confirmButton.setDisable(true);
				ServerMsgLabel.setText(msg);
			}
		});
	}

	/**
	 * Checks if the selected date is between tomorrow and 7 days from now.
	 *
	 * @param date the selected date
	 * @param time the selected time
	 * @return true if valid, false otherwise
	 */
	private boolean validatesDate24Hrs(LocalDate date, LocalTime time) {
		LocalDate today = LocalDate.now();
		LocalDate maxValid = today.plusDays(7);

		// Date must not be today and must be within next 1–7 days
		return !date.isEqual(today) && (date.isAfter(today) && !date.isAfter(maxValid));
	}

	/**
	 * Validates that the selected date and time are at least 24 hours in the
	 * future, and no more than 7 days ahead.
	 *
	 * @param date the selected date
	 * @param time the selected time
	 * @return true if valid, false otherwise
	 */
	private boolean validateNewOrderTime(LocalDate date, LocalTime time) {
		if (!validatesDate24Hrs(date, time)) {
			return false;
		}
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime orderDateTime = LocalDateTime.of(date, time);

		return orderDateTime.isAfter(now.plusHours(24));
	}

}
