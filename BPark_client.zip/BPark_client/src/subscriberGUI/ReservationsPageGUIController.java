package subscriberGUI;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

import client.ClientUI;
import client.Order;
import client.User;

/**
 * The {@code ReservationsPageGUIController} class manages the subscriber's
 * reservations page in the BPARK JavaFX application.
 *
 * <p>
 * Main responsibilities:
 * </p>
 * <ul>
 * <li>Displaying the user's parking orders in a {@link TableView} with
 * filtering by status</li>
 * <li>Allowing the user to cancel existing orders</li>
 * <li>Allowing the user to request time extensions for existing orders</li>
 * <li>Sending requests to the server and handling server responses</li>
 * <li>Providing navigation to other subscriber-related screens (Deposit,
 * Receive, New Order, etc.)</li>
 * </ul>
 *
 * <p>
 * This controller relies on JavaFX UI components such as {@link TableView},
 * {@link Button}, {@link Label}, {@link TextField}, and {@link CheckBox} to
 * manage user interactions.
 * </p>
 *
 * <p>
 * It communicates with the server via the {@link ClientUI} singleton to send
 * and receive order data and updates.
 * </p>
 *
 * @author waad
 * @version 1.0
 */
public class ReservationsPageGUIController implements Initializable {
	// User
	private String UserName = User.getInstance().getUsername();

	public static ReservationsPageGUIController instance;

	// Labels
	@FXML
	private Label ReservationPageLabel;
	@FXML
	private Label orderNumberLabel1;
	@FXML
	private Label orderNumberLabel2;
	@FXML
	private Label ServerMsgLabel;
	@FXML
	private Label usernameLabel;

	// Buttons
	@FXML
	private Button exitBtn;
	@FXML
	private Button cancelBtn;
	@FXML
	private Button requestBtn;

	// TextFields
	@FXML
	private TextField orderNumberInput1;
	@FXML
	private TextField orderNumberInput2;
	@FXML
	private TextField HoursInput;

	// CheckBoxes
	@FXML
	private CheckBox activeCheckBox;
	@FXML
	private CheckBox finishedCheckBox;
	@FXML
	private CheckBox allOrdersCheckBox;
	@FXML
	private CheckBox inparkingCheckBox;
	@FXML
	private CheckBox cancelledCheckBox;

	// TableView & Columns
	@FXML
	private TableView<Order> reservationTable;

	@FXML
	private TableColumn<Order, Integer> parkingSpaceColumn;
	@FXML
	private TableColumn<Order, Integer> OrderNumberColumn;
	@FXML
	private TableColumn<Order, String> orderDateColumn;
	@FXML
	private TableColumn<Order, Integer> confermationCodeColumn;
	@FXML
	private TableColumn<Order, Integer> subscriberIDColumn;
	@FXML
	private TableColumn<Order, String> dateOfPlacingOrderColumn;
	@FXML
	private TableColumn<Order, Integer> receiveCodeColumn;
	@FXML
	private TableColumn<Order, String> statusColumn;

	private ObservableList<Order> OrderData = FXCollections.observableArrayList();

	private String username = User.getInstance().getUsername();

	/**
	 * Initializes the Reservations Page controller.
	 *
	 * <p>
	 * Sets up the TableView columns, populates the username label, and makes the
	 * default selection for the "inparking" checkbox. Also triggers an initial
	 * request to the server to load current in-parking orders for the logged-in
	 * user.
	 * </p>
	 *
	 * @param location  the location used to resolve relative paths for the root
	 *                  object, or null if unknown.
	 * @param resources the resources used to localize the root object, or null if
	 *                  not localized.
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
		ServerMsgLabel.setText("");
		inparkingCheckBox.setSelected(true);
		usernameLabel.setText(username);
		OrderNumberColumn.setCellValueFactory(new PropertyValueFactory<>("orderNumber"));
		parkingSpaceColumn.setCellValueFactory(new PropertyValueFactory<>("parkingNumber"));
		orderDateColumn.setCellValueFactory(new PropertyValueFactory<>("scheduledDate"));
		confermationCodeColumn.setCellValueFactory(new PropertyValueFactory<>("confirmationCode"));
		subscriberIDColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
		dateOfPlacingOrderColumn.setCellValueFactory(new PropertyValueFactory<>("orderDate"));
		statusColumn.setCellValueFactory(new PropertyValueFactory<>("orderStatus"));

		reservationTable.setItems(OrderData);

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setReservationsPageController(this);
			String[] toSend = { "showOrders", UserName, "inparking" };
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Navigates to the View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Handles the Exit button action.
	 *
	 * <p>
	 * Clears the user session data and navigates back to the Login page.
	 * </p>
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View My Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Reservations page (this screen).
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Deposit Car page for subscribers.
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Receive Car page for subscribers.
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the New Order page where subscribers can create a new
	 * reservation.
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number page for subscribers.
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number page for subscribers.
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Password page for subscribers.
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Displays a server response message in the UI label.
	 *
	 * <p>
	 * Colors the message red for errors and dark green for success.
	 * </p>
	 *
	 * @param message the message string to display
	 */
	public void showMsg(String string) {
		ServerMsgLabel.setText(string); //
		if (string.equals("request denied") || string.equals("car is not in the parking")
				|| string.equals("order not found") || string.equals("User not found")
				|| string.equals("Error retrieving orders") || string.equals("Cancel Failed")
				|| string.equals("User not found") || string.equals("Error Canceling Error"))
			this.ServerMsgLabel.setTextFill(Color.web("#DC143C"));
		else
			this.ServerMsgLabel.setTextFill(Color.web("#006400"));
	}

	/**
	 * Handles the Cancel button action.
	 *
	 * <p>
	 * Sends a cancel request for the specified order number to the server.
	 * </p>
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	public void CancelBtn(ActionEvent event) {
		String orderNumber = orderNumberInput1.getText();
		String[] toSend = new String[3];
		toSend[0] = "cancelOrder";
		toSend[1] = UserName;
		toSend[2] = orderNumber;
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setReservationsPageController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Handles the Request Extension button action.
	 *
	 * <p>
	 * Sends an extension request to the server for the specified order number and
	 * number of hours. Validates that inputs are numeric before sending.
	 * </p>
	 *
	 * @param event the {@link ActionEvent} triggered by the button click
	 */
	public void RequestBtn(ActionEvent event) {
		String orderNumber = orderNumberInput2.getText();
		String hours = HoursInput.getText();

		// Validate input
		if (!isNumeric(orderNumber) || !isNumeric(hours)) {
			ServerMsgLabel.setText("❌ Please enter valid numeric values for both Order Number and Hours.");
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
			return;
		}

		String[] toSend = { "requestExtesnsion", User.getInstance().getUsername(), orderNumber, hours };

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setReservationsPageController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Utility method to check if a given string is numeric.
	 *
	 * @param str the string to check
	 * @return true if the string is composed only of digits, false otherwise
	 */
	private boolean isNumeric(String str) {
		return str != null && str.matches("\\d+");
	}

	/**
	 * Handles the Active Orders checkbox selection.
	 *
	 * <p>
	 * Marks this checkbox selected, deselects others, and requests active orders
	 * from the server.
	 * </p>
	 *
	 * @param event the {@link ActionEvent} triggered by the checkbox
	 */
	public void ActiveCheckBox(ActionEvent event) {
		activeCheckBox.setSelected(true);
		finishedCheckBox.setSelected(false);
		allOrdersCheckBox.setSelected(false);
		inparkingCheckBox.setSelected(false);
		cancelledCheckBox.setSelected(false);
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setReservationsPageController(this);
			String[] toSend = new String[3];
			toSend[0] = "showOrders";
			toSend[1] = UserName;
			toSend[2] = "active";
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Handles the All Orders checkbox selection.
	 *
	 * <p>
	 * Marks this checkbox selected, deselects others, and requests all orders from
	 * the server.
	 * </p>
	 *
	 * @param event the {@link ActionEvent} triggered by the checkbox
	 */
	public void AllOrdersCheckBox(ActionEvent event) {
		activeCheckBox.setSelected(false);
		finishedCheckBox.setSelected(false);
		allOrdersCheckBox.setSelected(true);
		inparkingCheckBox.setSelected(false);
		cancelledCheckBox.setSelected(false);
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setReservationsPageController(this);
			String[] toSend = new String[3];
			toSend[0] = "showOrders";
			toSend[1] = UserName;
			toSend[2] = "all";
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Handles the Finished Orders checkbox selection.
	 *
	 * <p>
	 * Marks this checkbox selected, deselects others, and requests finished orders
	 * from the server.
	 * </p>
	 *
	 * @param event the {@link ActionEvent} triggered by the checkbox
	 */
	public void FinishedCheckBox(ActionEvent event) {
		activeCheckBox.setSelected(false);
		finishedCheckBox.setSelected(true);
		allOrdersCheckBox.setSelected(false);
		inparkingCheckBox.setSelected(false);
		cancelledCheckBox.setSelected(false);
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setReservationsPageController(this);
			String[] toSend = new String[3];
			toSend[0] = "showOrders";
			toSend[1] = UserName;
			toSend[2] = "finished";
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Handles the In-Parking Orders checkbox selection.
	 *
	 * <p>
	 * Marks this checkbox selected, deselects others, and requests in-parking
	 * orders from the server.
	 * </p>
	 *
	 * @param event the {@link ActionEvent} triggered by the checkbox
	 */
	public void InparkingCheckBox(ActionEvent event) {
		activeCheckBox.setSelected(false);
		finishedCheckBox.setSelected(false);
		allOrdersCheckBox.setSelected(false);
		inparkingCheckBox.setSelected(true);
		cancelledCheckBox.setSelected(false);
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setReservationsPageController(this);
			String[] toSend = new String[3];
			toSend[0] = "showOrders";
			toSend[1] = UserName;
			toSend[2] = "inparking";
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Handles the Cancelled Orders checkbox selection.
	 *
	 * <p>
	 * Marks this checkbox selected, deselects others, and requests canceled orders
	 * from the server.
	 * </p>
	 *
	 * @param event the {@link ActionEvent} triggered by the checkbox
	 */
	public void CancelledCheckBox(ActionEvent event) {
		activeCheckBox.setSelected(false);
		finishedCheckBox.setSelected(false);
		allOrdersCheckBox.setSelected(false);
		inparkingCheckBox.setSelected(false);
		cancelledCheckBox.setSelected(true);
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setReservationsPageController(this);
			String[] toSend = new String[3];
			toSend[0] = "showOrders";
			toSend[1] = UserName;
			toSend[2] = "canceled";
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Populates the reservations TableView with order data from the server
	 * response.
	 *
	 * <p>
	 * Parses the server message, extracts order fields, and creates {@link Order}
	 * objects to display in the TableView.
	 * </p>
	 *
	 * @param msg the server response string containing order data
	 */

	public void Display(String msg) {
		Platform.runLater(() -> {
			this.OrderData.clear();

			if (msg == null || msg.length() < 2)
				return;

			String newmsg = msg.substring(1, msg.length() - 1);
			String[] entries = newmsg.split("Order\\{");

			for (String entry : entries) {
				if (entry.trim().isEmpty())
					continue;

				try {
					entry = entry.replaceAll("\\}$", "");
					String[] fields = entry.split(", ");
					int parkingNumber = 0, orderNumber = 0, confirmationCode = 0, userId = 0;
					String orderDate = "", orderTime = "", scheduledDate = "", scheduledTimeArrive = "",
							scheduledTimeLeave = "", orderStatus = "";

					for (String field : fields) {
						String[] kv = field.split("=", 2);
						if (kv.length != 2)
							continue;

						String key = kv[0].trim();
						String value = kv[1].trim().replace("'", "");

						switch (key) {
						case "parkingNumber":
							parkingNumber = Integer.parseInt(value);
							break;
						case "orderNumber":
							orderNumber = Integer.parseInt(value);
							break;
						case "orderDate":
							orderDate = value;
							break;
						case "orderTime":
							orderTime = value;
							break;
						case "scheduledDate":
							scheduledDate = value;
							break;
						case "scheduledTimeArrive":
							scheduledTimeArrive = value;
							break;
						case "scheduledTimeLeave":
							scheduledTimeLeave = value;
							break;
						case "userId":
							userId = Integer.parseInt(value);
							break;
						case "confirmationCode":
							confirmationCode = Integer.parseInt(value);
							break;
						case "orderStatus":
							orderStatus = value.replace("}", "");
							break;
						}
					}

					Order newOrder = new Order(parkingNumber, orderNumber, orderDate, orderTime, scheduledDate,
							scheduledTimeArrive, scheduledTimeLeave, userId, confirmationCode, orderStatus);
					this.OrderData.add(newOrder);
				} catch (Exception e) {
					System.out.println("❌ Error parsing entry: " + entry);
					e.printStackTrace();
				}
			}

			reservationTable.setItems(OrderData);
		});
	}
}
