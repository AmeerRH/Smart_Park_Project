package subscriberGUI;

import java.net.URL;
import java.util.ResourceBundle;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Controller class for the "Update Password" screen in the subscriber GUI.
 * <p>
 * This controller allows a logged-in subscriber to:
 * <ul>
 * <li>Enter their current (old) password and a new password</li>
 * <li>Send a request to the server to update their password</li>
 * <li>Navigate between different parts of the subscriber UI (reservations,
 * deposit, etc.)</li>
 * </ul>
 *
 * The controller interacts with the server via {@link ClientUI}, and displays
 * messages based on the server response using {@link Label}s.
 *
 * <p>
 * Username is retrieved from the {@link User} singleton instance.
 * </p>
 *
 * @author waad
 * @version 1.0
 * @since 2025-06
 */

public class UpdatePasswordController implements Initializable {
	public static UpdatePasswordController instance;

	@FXML
	private Button viewReservationsBtn;
	@FXML
	private Button depositCarBtn;
	@FXML
	private Button receiveCarBtn;
	@FXML
	private Button newOrderBtn;
	@FXML
	private Button updatePhoneNumberBtn;
	@FXML
	private Button updateEmeilBtn;
	@FXML
	private Button updatePasswordBtn;
	@FXML
	private Button exitBtn;

	@FXML
	private Label usernameLabel;
	@FXML
	private Label ServerMsgLabel;

	@FXML
	private TextField oldPasswordInput;
	@FXML
	private TextField newPasswordInput;

	@FXML
	private Button updatePasswordNewBtn;
	@FXML
	private Button clearBtn;

	// username that is connected
	private String username = User.getInstance().getUsername();

	/**
	 * Initializes the Update Password screen. Sets the username label to the
	 * current logged-in user and clears any server message.
	 *
	 * @param arg0 the location used to resolve relative paths for the root object,
	 *             or null if unknown
	 * @param arg1 the resources used to localize the root object, or null if none
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		usernameLabel.setText(username);
		ServerMsgLabel.setText(""); // Clear error message on GUI load
	}

	/**
	 * Handles the action of the Exit button. Logs out the current user, clears the
	 * session, and navigates back to the Login page.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View My Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Subscriber View Reservations screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Subscriber Deposit Car screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Subscriber Receive Car screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Subscriber New Order screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Email screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */

	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the Update Password screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Sends a request to the server to update the user's password. Collects the old
	 * and new password inputs, builds a message, and sends it via the ClientUI.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	void UpdateNewPasswordBtn(ActionEvent event) {
		String oldPassword = oldPasswordInput.getText();
		String newPassword = newPasswordInput.getText();
		String[] toSend = new String[4];
		toSend[0] = "updatePassword";
		toSend[1] = username;
		toSend[2] = oldPassword;
		toSend[3] = newPassword;

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setUpdatePasswordController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Displays a server response message in the GUI. Sets text color to green for
	 * success, red for errors.
	 *
	 * @param string the message received from the server
	 */

	public void showMsg(String string) {
		ServerMsgLabel.setText(string); // Error ==> username does not exist
		if (string.equals("Password Updated Successfully"))
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		else
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");

	}

	/**
	 * Clears both password input fields and displays a success message.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	void ClearBtn(ActionEvent event) {
		oldPasswordInput.setText("");
		newPasswordInput.setText("");
		ServerMsgLabel.setText("Inputs are Cleared successfully");
		ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
	}
}
