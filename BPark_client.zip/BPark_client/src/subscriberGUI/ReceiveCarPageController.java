package subscriberGUI;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * The {@code ReceiveCarPageController} class manages the JavaFX screen where
 * subscribers can confirm receiving their parked car in the BPARK system.
 *
 * <p>
 * Main responsibilities include:
 * </p>
 * <ul>
 * <li>Collecting the parking code from the user for validation</li>
 * <li>Handling input for username, email, and order number to request the
 * parking code via email</li>
 * <li>Sending requests to the server to confirm car retrieval</li>
 * <li>Displaying server feedback messages clearly with color cues</li>
 * <li>Providing navigation to other subscriber screens</li>
 * </ul>
 *
 * <p>
 * This controller uses JavaFX components such as {@link TextField},
 * {@link Label}, and {@link Button} to handle user interactions.
 * </p>
 *
 * @author waad
 * @version 1.0
 */
public class ReceiveCarPageController {

	@FXML
	private VBox page;

	@FXML
	private Button qrCodeBtn;

	@FXML
	private TextField enterParkingCodeInput;

	@FXML
	private Label ServerMsgLabel;

	@FXML
	private Label usernameLabel;

	@FXML
	private TextField usernameInput;

	@FXML
	private TextField emailInput;

	@FXML
	private TextField orderNumberInput;

	public static ReceiveCarPageController instance;

	private String username = User.getInstance().getUsername();

	/**
	 * Initializes the Receive Car page by setting the username and clearing server
	 * messages.
	 */

	@FXML
	void initialize() {
		instance = this;
		usernameLabel.setText(username);
		ServerMsgLabel.setText("");
		page.setVisible(false);
	}

	/**
	 * Logs out the user and navigates back to the login page.
	 *
	 * @param event the ActionEvent triggered by the Exit button
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Reservations page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View My Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Deposit Car page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the Receive Car page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the New Order page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Email page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Password page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Sends a request to the server to email the receive code for a specific order,
	 * using the provided username, email, and order number.
	 *
	 * @param event the ActionEvent triggered by the Send button
	 */
	@FXML
	public void SendParkingCodeBtn(ActionEvent event) {
		String username = usernameInput.getText();
		String email = emailInput.getText();
		String orderNumber = orderNumberInput.getText();

		if (ClientUI.bParkClient != null) {
			String[] toSend = { "sendParkingCodeViaEmail", username, email, orderNumber };
			ClientUI.bParkClient.setReceiveCarPageController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		} else {
			displayServerMessage("Client not connected. Please ensure you are connected to the server.");
		}
	}

	/**
	 * Confirms the reception of a parked car by validating the entered parking code
	 * and sending it to the server.
	 *
	 * @param event the ActionEvent triggered by the Confirm button
	 */
	@FXML
	void ConfirmBtn(ActionEvent event) {
		String parkingCode = enterParkingCodeInput.getText();

		if (ServerMsgLabel != null) {
			ServerMsgLabel.setText("");
		}

		if (parkingCode.isEmpty()) {
			displayServerMessage("Please enter a parking code.");
			return;
		}

		if (ClientUI.bParkClient != null) {
			String[] message = { "receiveCar", username, parkingCode };
			ClientUI.bParkClient.setReceiveCarPageController(this);
			ClientUI.bParkClient.requestFromServer(message);
		} else {
			displayServerMessage("Client not connected. Please ensure you are connected to the server.");
		}
	}

	/**
	 * Displays server response messages on the UI with appropriate color formatting
	 * (success in green, errors in red).
	 *
	 * @param message the server message to display
	 */

	public void displayServerMessage(String message) {
		if (ServerMsgLabel == null)
			return;

		String color = "#000000"; // Default: black
		String formattedMsg = message;

		switch (message) {
		case "Car received successfully.":
			formattedMsg = "✔ The car has been received successfully and the spot is now available.";
			color = "#228B22";
			enterParkingCodeInput.clear();
			break;

		case "No matching order found with status 'inparking'.":
			formattedMsg = "❌ No active parking order found for this code.";
			color = "#DC143C";
			break;

		case "Invalid parking code format.":
			formattedMsg = "❌ Please enter a valid numeric parking code.";
			color = "#DC143C";
			break;

		case "Database error: Error Receiving Car":
		case "Database error: Error Receiving Car (Database update failed)":
		case "Database error: Error Receiving Car (Server side error)":
			formattedMsg = "❌ Something went wrong during car reception. Try again later.";
			color = "#DC143C";
			break;

		case "You will get a Mail including your Receive_code soon.":
			color = "#228B22";
			break;

		case "Username is not correct!":
			formattedMsg = "❌ Invalid username. Please verify your credentials.";
			color = "#DC143C";
			break;

		case "Order Number does not Exist!":
			formattedMsg = "❌ No order found with the provided number.";
			color = "#DC143C";
			break;

		case "This Order is NOT for you":
			formattedMsg = "❌ This order does not belong to you.";
			color = "#DC143C";
			break;

		case "Order has been cancelled before":
			formattedMsg = "❌ This order has already been canceled.";
			color = "#DC143C";
			break;

		case "Order is taken long time ago":
			formattedMsg = "❌ This order has already been completed.";
			color = "#DC143C";
			break;
		}

		// Generic pattern check
		if (formattedMsg.toLowerCase().contains("success") || formattedMsg.toLowerCase().contains("✔")) {
			color = "#228B22";
		} else if (formattedMsg.toLowerCase().contains("error") || formattedMsg.toLowerCase().contains("❌")
				|| formattedMsg.toLowerCase().contains("failed") || formattedMsg.toLowerCase().contains("not found")
				|| formattedMsg.toLowerCase().contains("invalid") || formattedMsg.toLowerCase().contains("denied")) {
			color = "#DC143C";
		}

		ServerMsgLabel.setText(formattedMsg);
		ServerMsgLabel.setStyle("-fx-text-fill: " + color + ";");
	}

	/**
	 * Reveals the QR code input section for car retrieval.
	 *
	 * @param event the ActionEvent triggered by the QR Code button
	 */

	@FXML
	public void QrCodeBtn(ActionEvent event) {
		page.setVisible(true);
		qrCodeBtn.setVisible(false);

		ServerMsgLabel.setText("Welcome Back to Braude BPark");
		ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
	}

}