package subscriberGUI;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.LocalTime;
import client.ClientUI;
import client.User;

/**
 * The {@code DepositCarController} class manages the GUI for the subscriber to
 * deposit their car in the BPARK system.
 *
 * <p>
 * Main responsibilities include:
 * </p>
 * <ul>
 * <li>Allowing the user to check parking availability for a selected time
 * period</li>
 * <li>Creating immediate orders for parking</li>
 * <li>Displaying server responses and feedback messages</li>
 * <li>Providing navigation to other subscriber screens</li>
 * </ul>
 *
 * <p>
 * This controller uses JavaFX UI components such as {@link Button},
 * {@link Spinner}, and {@link Label} to enable user interaction.
 * </p>
 *
 * @author waad
 * @version 1.0
 */
public class DepositCarController {

	public static DepositCarController instance;
	@FXML
	private VBox page;
	@FXML
	private Button handleClear;
	@FXML
	private Label checkAvailabilityLabel;
	@FXML
	private Label iHaveAnOrderLabel;
	@FXML
	private Label orderNumberLabel;
	@FXML
	private Button qrCodeBtn;
	@FXML
	private Label parkingTimeLabel;
	@FXML
	private Label hoursLabel;
	@FXML
	private Label minutesLabel;
	@FXML
	private Label checkAvailabilityLabel2;
	@FXML
	private Spinner<Integer> hoursSpinner;
	@FXML
	private Spinner<Integer> minutesSpinner;
	@FXML
	private Label availabilityLabel;
	@FXML
	private Button checkAvailabilityBtn;
	@FXML
	private Button depositBtn;
	@FXML
	private Button confirmNowBtn;
	@FXML
	private TextField orderNumberinput;
	@FXML
	private Label ServerMsgLabel;
	@FXML
	private Button exitBtn;
	@FXML
	private Label usernameLabel;

	private String username = User.getInstance().getUsername();

	/**
	 * Initializes the DepositCar screen by configuring spinners, hiding unused
	 * fields, and setting the username label.
	 */
	@FXML
	public void initialize() {
		instance = this;
		hoursSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 4, 0));
		minutesSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 45, 15, 15));
		usernameLabel.setText(username);
		hoursSpinner.setEditable(false);
		minutesSpinner.setEditable(false);
		ServerMsgLabel.setText("");
		page.setVisible(false);
	}

	/**
	 * Logs the user out and navigates back to the login screen.
	 *
	 * @param event the ActionEvent triggered by the Exit button
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View My Details screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Reservations screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the Deposit Car screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Receive Car screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the New Order screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Email screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Password screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Parkings screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Checks the availability of parking for the selected future time and sends a
	 * request to the server.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	void CheckAvailabilityBtn(ActionEvent event) {
		String[] toSend = new String[5];
		try {
			int hours = hoursSpinner.getValue();
			int minutes = minutesSpinner.getValue();

			// Get current date
			LocalDate currentDate = LocalDate.now();
			LocalTime currentTime = LocalTime.now();
			LocalTime futureTime = currentTime.plusHours(hours).plusMinutes(minutes);

			// 🧠 Enforce max 4 hours (240 minutes)
			long durationMinutes = java.time.Duration.between(currentTime, futureTime).toMinutes();
			if (durationMinutes > 240) {
				ServerMsgLabel.setText("❌ Duration cannot exceed 4 hours.");
				confirmNowBtn.setVisible(false); // Hide confirm
				ServerMsgLabel.setStyle("-fx-text-fill: red;");

				return;
			}

			toSend[0] = "checkAvailablityNow";
			toSend[1] = username;
			toSend[2] = currentDate.toString(); // Format: yyyy-MM-dd
			toSend[3] = currentTime.toString();
			toSend[4] = futureTime.toString(); // Format: HH:mm
			if (ClientUI.bParkClient != null) {
				ClientUI.bParkClient.setDepositCarController(this);
				ClientUI.bParkClient.requestFromServer(toSend);
			}

		} catch (Exception e) {
			ServerMsgLabel.setText("❌ Error while checking availability.");
			e.printStackTrace();
		}
	}

	/**
	 * Sends a deposit request to the server with the provided order number.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	void DepositBtn(ActionEvent event) {
		String[] toSend = new String[3];
		toSend[0] = "depositeCar";
		toSend[1] = username;
		toSend[2] = orderNumberinput.getText();

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setDepositCarController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Clears user inputs and resets the form to its initial state.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	void handleClear(ActionEvent event) {
		hoursSpinner.getValueFactory().setValue(0);
		minutesSpinner.getValueFactory().setValue(15);
		ServerMsgLabel.setText("Inputs are Cleared successfully");
		ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		orderNumberinput.clear();
		availabilityLabel.setVisible(false);
		confirmNowBtn.setVisible(false);
	}

	/**
	 * Displays the server's response to the user, updating UI elements such as
	 * visibility and feedback labels accordingly.
	 *
	 * @param msg the server response array
	 */

	public void showServerResponse(String[] msg) {

		if ("AVAILABLE".equals(msg[1])) {
			availabilityLabel.setVisible(true);
			ServerMsgLabel.setText("✔ Available parking detected, You can place a new Order");
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
			confirmNowBtn.setVisible(true); // still show the button
		} else if (msg[1].contains("email & SMS")) {
			ServerMsgLabel.setText(msg[1]);
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		} else if ("Deposit successful. Car is now parked.".equals(msg[1])) {
			ServerMsgLabel.setText(msg[1]);
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		} else if ("FULL".equals(msg[1])) {
			availabilityLabel.setVisible(false);
			ServerMsgLabel.setText("❌ Parking Full, Unfortunately, no spots are available right now.");
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
			confirmNowBtn.setVisible(false); // hide the button
		} else {
			ServerMsgLabel.setText(msg[1]);
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
		}
	}

	/**
	 * Creates and sends an immediate parking order to the server based on
	 * user-selected duration and current time.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	void handleImmediateConfirm(ActionEvent event) {
		try {
			int hours = hoursSpinner.getValue();
			int minutes = minutesSpinner.getValue();

			LocalDate currentDate = LocalDate.now();
			LocalTime currentTime = LocalTime.now();
			LocalTime futureTime = currentTime.plusHours(hours).plusMinutes(minutes);

			String date = currentDate.toString();
			String startTime = currentTime.toString().substring(0, 8); // HH:mm:ss
			String endTime = futureTime.toString().substring(0, 8);

			// 🧠 Enforce max 4 hours (240 minutes)
			long durationMinutes = java.time.Duration.between(currentTime, futureTime).toMinutes();
			if (durationMinutes > 240) {
				ServerMsgLabel.setText("❌ Duration cannot exceed 4 hours.");
				this.ServerMsgLabel.setTextFill(Color.RED);
				confirmNowBtn.setVisible(false); // Hide confirm

				return;
			}
			String confirmationCode = String.valueOf((int) (Math.random() * 999000) + 1000);
			String receiveCode = String.valueOf((int) (Math.random() * 9000) + 1000);

			String[] toSend = new String[7];
			toSend[0] = "createImmediateOrder";
			toSend[1] = date;
			toSend[2] = startTime;
			toSend[3] = endTime;
			toSend[4] = username;
			toSend[5] = confirmationCode;
			toSend[6] = receiveCode;

			if (ClientUI.bParkClient != null) {
				ClientUI.bParkClient.setDepositCarController(this);
				ClientUI.bParkClient.requestFromServer(toSend);
			}

			ServerMsgLabel.setText("✅ Order request sent.");
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
			confirmNowBtn.setVisible(false); // Hide button after sending

		} catch (Exception e) {
			ServerMsgLabel.setText("❌ Error creating immediate order.");
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
			e.printStackTrace();
		}
	}

	/**
	 * Displays the fields for entering parking time when QR Code button is pressed.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	public void QrCodeBtn(ActionEvent event) {
		page.setVisible(true);
		qrCodeBtn.setVisible(false);

		ServerMsgLabel.setText("Welcome to Braude BPark");
		ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
	}

}
