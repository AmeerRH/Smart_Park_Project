package subscriberGUI;

import java.net.URL;
import java.util.ResourceBundle;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * The {@code UpdateEmailController} class manages the "Update Email" screen for
 * subscribers in the BPARK JavaFX application.
 *
 * <p>
 * Main responsibilities:
 * </p>
 * <ul>
 * <li>Displays the logged-in subscriber's username</li>
 * <li>Allows the user to enter their old and new email addresses</li>
 * <li>Handles updating the user's email in the system via server request</li>
 * <li>Shows server response messages with success or error indication</li>
 * <li>Provides navigation to other subscriber-related screens (reservations,
 * deposit car, receive car, new order, phone number/password update)</li>
 * </ul>
 *
 * <p>
 * This controller uses JavaFX UI components such as {@link TextField},
 * {@link Button}, and {@link Label} to enable user interaction. It communicates
 * with the server via the {@link ClientUI} singleton to perform email update
 * requests.
 * </p>
 *
 * @author waad
 * @version 1.0
 */
public class UpdateEmailController implements Initializable {
	public static UpdateEmailController instance;

	@FXML
	private Button viewReservationsBtn;
	@FXML
	private Button depositCarBtn;
	@FXML
	private Button receiveCarBtn;
	@FXML
	private Button newOrderBtn;
	@FXML
	private Button updatePhoneNumberBtn;
	@FXML
	private Button updateEmeilBtn;
	@FXML
	private Button updatePasswordBtn;
	@FXML
	private Button exitBtn;

	@FXML
	private Label usernameLabel;
	@FXML
	private Label ServerMsgLabel;

	@FXML
	private TextField oldEmailInput;
	@FXML
	private TextField newEmailInput;

	@FXML
	private Button updateNewEmailbtn;
	@FXML
	private Button clearBtn3;

	// username that is connected
	private String username = User.getInstance().getUsername();

	/**
	 * Initializes the Update Email screen. Sets the username label to the current
	 * logged-in user, clears any existing server message, and establishes this
	 * controller as the singleton instance.
	 *
	 * @param arg0 the location used to resolve relative paths for the root object,
	 *             or null if unknown
	 * @param arg1 the resources used to localize the root object, or null if none
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		ServerMsgLabel.setText(""); // Clear error message on GUI load
		usernameLabel.setText(username);
	}

	/**
	 * Handles the action of the Exit button. Clears the current user session and
	 * navigates back to the Login page.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View My Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Subscriber View Reservations screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Subscriber Deposit Car screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Subscriber Receive Car screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Subscriber New Order screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the Update Email screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Password screen.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Sends a request to the server to update the user's email address. Collects
	 * the old and new email inputs, builds a message, and sends it via the
	 * ClientUI.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */
	@FXML
	void UpdateNewEmailbtn(ActionEvent event) {
		String oldEmail = oldEmailInput.getText();
		String newEmail = newEmailInput.getText();
		String[] toSend = new String[4];
		toSend[0] = "updateEmail";
		toSend[1] = username;
		toSend[2] = oldEmail;
		toSend[3] = newEmail;

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setUpdateEmailController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Displays a server response message in the GUI. Sets text color to green for
	 * success, red for errors.
	 *
	 * @param string the message received from the server
	 */
	public void showMsg(String string) {
		ServerMsgLabel.setText(string); // Error ==> username does not exist
		if (string.equals("Email Updated Successfully"))
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		else
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");

	}

	/**
	 * Clears both email input fields and shows a success message.
	 *
	 * @param event the ActionEvent triggered by clicking the button
	 */

	@FXML
	void ClearBtn(ActionEvent event) {
		oldEmailInput.setText("");
		newEmailInput.setText("");
		ServerMsgLabel.setText("Inputs are Cleared successfully");
		ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
	}

}
