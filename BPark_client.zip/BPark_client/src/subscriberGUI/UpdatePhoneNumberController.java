package subscriberGUI;

import java.net.URL;
import java.util.ResourceBundle;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Manages the update phone number screen for subscribers. Handles user input
 * for old and new phone numbers, sends the update request to the server, and
 * displays server responses.
 */

public class UpdatePhoneNumberController implements Initializable {
	public static UpdatePhoneNumberController instance;

	@FXML
	private Button viewReservationsBtn;
	@FXML
	private Button depositCarBtn;
	@FXML
	private Button receiveCarBtn;
	@FXML
	private Button newOrderBtn;
	@FXML
	private Button updatePhoneNumberBtn;
	@FXML
	private Button updateEmeilBtn;
	@FXML
	private Button updatePasswordBtn;
	@FXML
	private Button exitBtn;

	@FXML
	private Label usernameLabel;
	@FXML
	private Label ServerMsgLabel;

	@FXML
	private TextField oldPhoneNumberInput;
	@FXML
	private TextField newPhoneNumberInput;

	@FXML
	private Button updateNewPhoneNumberBtn;
	@FXML
	private Button clearBtn;

	// username that is connected
	private String username = User.getInstance().getUsername();

	/**
	 * Initializes the controller. Sets the logged-in username label, clears any
	 * server messages, and prepares UI components for use.
	 *
	 * @param location  The location used to resolve relative paths for the root
	 *                  object.
	 * @param resources The resources used to localize the root object.
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		ServerMsgLabel.setText(""); // Clear error message on GUI load
		usernameLabel.setText(username);
	}

	/**
	 * Handles the action when the user clicks the "Exit" button. Clears the current
	 * user session and navigates back to the Login Page.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View My Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates the user to the "View Reservations" page.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates the user to the "Deposit Car" page.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates the user to the "Receive Car" page.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates the user to the "New Order" page.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the "Update Phone Number" page. Useful for refreshing the current
	 * view.
	 *
	 * @param event The action event triggered by the button click.
	 */

	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates the user to the "Update Email" page.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates the user to the "Update Password" page.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Handles the action of submitting an update request for the phone number.
	 * Sends the old and new phone numbers to the server for processing.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	void UpdateNewPhoneNumberBtn(ActionEvent event) {
		String oldNumber = oldPhoneNumberInput.getText();
		String newNumber = newPhoneNumberInput.getText();
		String[] toSend = new String[4];
		toSend[0] = "updatePhoneNumber";
		toSend[1] = username;
		toSend[2] = oldNumber;
		toSend[3] = newNumber;

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setUpdatePhoneNumberController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Navigates to the View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Displays a server response message to the user. Sets the text color depending
	 * on whether it's a success or error message.
	 *
	 * @param string The message returned from the server.
	 */
	public void showMsg(String string) {
		ServerMsgLabel.setText(string); // Error ==> username does not exist
		if (string.equals("Password Updated Successfully"))
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		else
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");

	}

	/**
	 * Clears the input fields for the old and new phone numbers, and displays a
	 * confirmation message to the user.
	 *
	 * @param event The action event triggered by the button click.
	 */
	@FXML
	void ClearBtn(ActionEvent event) {
		oldPhoneNumberInput.setText("");
		newPhoneNumberInput.setText("");
		ServerMsgLabel.setText("Inputs are Cleared successfully");
		ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
	}
}
