package subscriberGUI;

import java.net.URL;
import java.util.ResourceBundle;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * The {@code SubscriberViewDetailsController} class manages the JavaFX
 * interface for displaying subscriber account details in the BPARK system.
 *
 * <p>
 * Main responsibilities include:
 * </p>
 * <ul>
 * <li>Retrieving and displaying subscriber personal information</li>
 * <li>Providing navigation to other subscriber-related screens</li>
 * <li>Displaying feedback from the server</li>
 * </ul>
 *
 * <p>
 * This controller uses JavaFX components like {@link TextField}, {@link Label},
 * and {@link Button} for UI interactions.
 * </p>
 *
 * @author waad
 * @version 1.0
 */

public class SubscriberViewDetailsController {
	public static SubscriberViewDetailsController instance;

	@FXML
	private Label ServerMsgLabel;

	@FXML
	private TextField usernameOutput;

	@FXML
	private TextField idOutput;

	@FXML
	private TextField subscriberNumberOutput;

	@FXML
	private TextField firstNameOutput;

	@FXML
	private TextField lastNameOutput;

	@FXML
	private TextField phoneNumberOutput;

	@FXML
	private TextField emailOutput;

	@FXML
	private TextField passwordOutput;

	@FXML
	private Label usernameLabel;

	private String username = User.getInstance().getUsername();

	/**
	 * Initializes the subscriber details screen by setting the username label,
	 * sending a request to load subscriber data, and binding this controller.
	 */

	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(username);
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setSubscriberViewDetailsController(this);
			String[] toSend = { "ViewSubscriberDetails", "subscriber", User.getInstance().getUsername() };
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Logs out the current user and navigates to the login screen.
	 *
	 * @param event the ActionEvent triggered by the Exit button
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Login Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Login Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Parkings");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the current View Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewMyDetails(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the View Reservations page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewReservationsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberViewReservations.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("View Reservation");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading View Reservation Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Deposit Car page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void DepositCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberDepositCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Deposit Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Deposit Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Receive Car page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ReceiveCarBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberReceiveCar.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Receive Car");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Receive Car Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the New Order page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void NewOrderBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberNewOrder.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Order");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading New Order Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Phone Number page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void UpdatePhoneNumberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePhoneNumber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Phone Number");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Phone Number Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Email page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void UpdateEmeilBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdateEmail.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Email");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Email Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Update Password page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void UpdatePasswordBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SubscriberUpdatePassword.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Update Password");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Update Password Page: " + e.getMessage());
		}
	}

	/**
	 * Displays subscriber details received from the server. If successful, updates
	 * UI fields with personal data. Otherwise, displays an error message.
	 *
	 * @param msg an array of subscriber data and server response status
	 */

	public void DisplaySubscriber(String[] msg) {
		if (msg[10].equals("success")) {
			ServerMsgLabel.setText("");
			usernameOutput.setText(msg[2]);
			idOutput.setText(msg[3]);
			subscriberNumberOutput.setText(msg[4]);
			firstNameOutput.setText(msg[5]);
			lastNameOutput.setText(msg[6]);
			phoneNumberOutput.setText(msg[7]);
			emailOutput.setText(msg[8]);
			passwordOutput.setText(msg[9]);
			return;
		}
		ServerMsgLabel.setText(msg[10]);
		ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
	}
}
