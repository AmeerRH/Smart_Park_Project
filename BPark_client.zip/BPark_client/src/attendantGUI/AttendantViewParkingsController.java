package attendantGUI;

import java.io.IOException;

import client.ClientUI;
import client.Parking;
import client.User;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * Controller for the "View Parkings" screen used by parking attendants.
 * <p>
 * Responsible for:
 * <ul>
 * <li>Displaying real-time parking spot data (taken/available)</li>
 * <li>Periodic auto-refresh of parking data from the server</li>
 * <li>Navigation to other GUI pages (Add Subscriber, View Subscriber
 * Details)</li>
 * <li>Handling server messages and displaying them on the interface</li>
 * </ul>
 * </p>
 * This class is tied to a TableView and uses a singleton instance for GUI
 * access.
 * 
 * @author bashar
 * @version 1.0
 */
public class AttendantViewParkingsController {

	/** Singleton instance for accessing the controller from other parts of the system. */
	public static AttendantViewParkingsController instance;

	// --- FXML UI elements ---
	@FXML
	private Label usernameLabel;

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private TableView<Parking> dataTable;

	@FXML
	private TableColumn<Parking, String> parkingNumberCol;

	@FXML
	private TableColumn<Parking, String> statusCol;

	@FXML
	private TableColumn<Parking, String> IDCol;

	@FXML
	private TableColumn<Parking, String> orderNumberCol;

	@FXML
	private TableColumn<Parking, String> takenUntilCol;

	@FXML
	private TableColumn<Parking, String> takenFromCol;

	@FXML
	private Label ServerMsgLabel;
	
	/** Observable list used to bind parking data to the table view. */
	private ObservableList<Parking> parkingData = FXCollections.observableArrayList();

	/**
     * Initializes the controller, sets up the table, binds user info,
     * and starts the automatic refresh timer.
     */
	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(User.getInstance().getUsername()); // Set username dynamically if needed
		setupTable();
		ServerMsgLabel.setText("");
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setAttendantViewParkingsController(this);
			refreshParkings(); // First load
			startAutoRefresh(); // Start periodic auto-refresh
		}
	}
	
	/**
     * Starts a periodic refresh task that runs every 10 seconds to update parking data.
     */
	private void startAutoRefresh() {
		Timeline refreshTimeline = new Timeline(new KeyFrame(Duration.seconds(10), event -> {
			refreshParkings();
		}));
		refreshTimeline.setCycleCount(Animation.INDEFINITE);
		refreshTimeline.play();
	}
	
	 /**
     * Sends a request to the server to retrieve the most recent parking data.
     */
	private void refreshParkings() {
		String[] toSend = { "viewParkings", "attendant" };
		ClientUI.bParkClient.requestFromServer(toSend);
	}

	 /**
     * Configures the table columns and binds them to the Parking model fields.
     */
	private void setupTable() {
		parkingNumberCol.setCellValueFactory(new PropertyValueFactory<>("parkingNumber"));
		statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
		IDCol.setCellValueFactory(new PropertyValueFactory<>("ownerID"));
		orderNumberCol.setCellValueFactory(new PropertyValueFactory<>("orderNumber"));
		takenFromCol.setCellValueFactory(new PropertyValueFactory<>("takenFrom"));
		takenUntilCol.setCellValueFactory(new PropertyValueFactory<>("takenUntil"));
	}

	/**
     * Reloads parking data from the server.
     * 
     * @param event the action event triggered by clicking "View Parkings"
     */
	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		String[] toSend = { "viewParkings" };
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setAttendantViewParkingsController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
     * Navigates to the "Add New Subscriber" screen.
     * 
     * @param event the action event triggered by clicking the button
     */
	@FXML
	private void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AttendantNewSubscriber.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
     * Navigates to the "Subscriber Details" screen.
     * 
     * @param event the action event triggered by clicking the button
     */
	@FXML
	private void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AttendantViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	
	/**
     * Logs the user out and returns to the login screen.
     * 
     * @param event the action event triggered by clicking the button
     */
	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	
	/**
     * Updates the parking table with both available and taken parking spots.
     * 
     * @param msgAvailable string from the server with available parking spots
     * @param msgTaken string from the server with taken parking spots
     */
	public void DisplayParkings(String msgAvailable, String msgTaken) {
		Platform.runLater(() -> {
			TakenParkings(msgTaken);
			AvailableParkings(msgAvailable);
		});
	}

	/**
     * Parses and displays taken parking data.
     * 
     * @param msgTaken server-formatted string with taken parking info
     */
	private void TakenParkings(String msgTaken) {
		parkingData.clear(); // Clear previous data

		if (msgTaken == null || msgTaken.isEmpty())
			return;

		String[] records = msgTaken.split("\\|");
		for (String record : records) {
			String[] fields = record.split(";");
			Parking parking = new Parking(getField(fields, 0), // parkingNumber
					getField(fields, 1), // status
					getField(fields, 2), // ownerID
					getField(fields, 3), // orderNumber
					getField(fields, 5), // takenFrom
					getField(fields, 4) // takenUntil
			);
			parkingData.add(parking);
		}

		dataTable.setItems(parkingData);
	}

	/**
     * Parses and displays available parking data.
     * 
     * @param msgAvailable server-formatted string with available parking info
     */
	private void AvailableParkings(String msgAvailable) {
		if (msgAvailable == null || msgAvailable.isEmpty())
			return;

		String[] records = msgAvailable.split("\\|");
		for (String record : records) {
			String[] fields = record.split(";");
			Parking parking = new Parking(getField(fields, 0), // parkingNumber
					getField(fields, 1), // status
					"", // ownerID
					"", // orderNumber
					"", // takenUntil
					"" // takenFrom
			);
			parkingData.add(parking);
		}

		dataTable.setItems(parkingData);
	}

	/**
     * Utility method to safely retrieve a field from a split array.
     * 
     * @param fields array of string fields
     * @param index index to retrieve
     * @return field value or empty string if not present
     */
	private String getField(String[] fields, int index) {
		return (index < fields.length && fields[index] != null) ? fields[index] : "";
	}
}
