package attendantGUI;

import java.io.IOException;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * Controller class for the "Add New Subscriber" screen used by parking
 * attendants.
 * <p>
 * This controller handles:
 * <ul>
 * <li>Collecting subscriber details from input fields</li>
 * <li>Sending subscription request to the server</li>
 * <li>Routing to other screens: View Parkings, Subscriber Details, etc.</li>
 * <li>Displaying server responses and input validation</li>
 * </ul>
 * </p>
 * 
 * @author bashar
 * @version 1.0
 */
public class AttendantNewSubscriberController {

	/** Singleton instance of the controller for external access. */
	public static AttendantNewSubscriberController instance;

	// --- FXML UI elements ---

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Label usernameLabel;

	@FXML
	private Button exitBtn;

	@FXML
	private TextField usernameInput;

	@FXML
	private TextField firstNameInput;

	@FXML
	private TextField lasNameInput;

	@FXML
	private TextField idInput;

	@FXML
	private TextField phoneNumberInput;

	@FXML
	private TextField emailInput;

	@FXML
	private TextField passwordInput;

	@FXML
	private Button addNewBtn;

	@FXML
	private Button clearBtn;

	@FXML
	private Label ServerMsgLabel;

	/**
	 * Initializes the controller: sets the instance reference and displays the
	 * logged-in user's name.
	 */
	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(User.getInstance().getUsername()); // Set username dynamically if needed
		ServerMsgLabel.setText("");
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setAttendantNewSubscriberController(this);
		}
	}

	/**
	 * Navigates to the View Parkings screen.
	 * 
	 * @param event triggered when the button is clicked
	 */
	@FXML
	void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AttendantViewParkings.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Reloads the current screen (Add New Subscriber).
	 * 
	 * @param event triggered when the button is clicked
	 */
	@FXML
	private void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AttendantNewSubscriber.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the View Subscriber Details screen.
	 * 
	 * @param event triggered when the button is clicked
	 */
	@FXML
	void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AttendantViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Logs out the current user and redirects to the login screen.
	 * 
	 * @param event triggered when the button is clicked
	 */
	@FXML
	void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	/**
	 * Collects subscriber input fields and sends a registration request to the
	 * server.
	 * 
	 * @param event triggered when the button is clicked
	 */
	@FXML
	void AddNewBtn(ActionEvent event) {
		String username = usernameInput.getText();
		String firstName = firstNameInput.getText();
		String lastName = lasNameInput.getText();
		String id = idInput.getText();
		String phone = phoneNumberInput.getText();
		String email = emailInput.getText();
		String password = passwordInput.getText();

		if (username.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || id.isEmpty() || phone.isEmpty()
				|| email.isEmpty() || password.isEmpty()) {
			ServerMsgLabel.setText("Please fill in all fields.");
			return;
		}

		String[] toSend = { "addNewSubscriber", username, firstName, lastName, id, phone, email, password, "attendant",
				"subscriber" };

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setAttendantNewSubscriberController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}

	}

	/**
	 * Clears all input fields in the form.
	 * 
	 * @param event triggered when the button is clicked
	 */
	@FXML
	void ClearBtn(ActionEvent event) {
		usernameInput.clear();
		firstNameInput.clear();
		lasNameInput.clear();
		idInput.clear();
		phoneNumberInput.clear();
		emailInput.clear();
		passwordInput.clear();
		ServerMsgLabel.setText("All fields cleared.");
	}

	/**
	 * Displays a message from the server in the message label with color feedback.
	 * 
	 * @param msg the message received from the server
	 */
	public void ShowMsg(String msg) {
		ServerMsgLabel.setText(msg);

		if (msg.toLowerCase().contains("successfully")) {
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		} else {
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
		}
	}
}
