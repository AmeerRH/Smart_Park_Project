package attendantGUI;

import java.io.IOException;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Controller for the "View Subscriber Details" screen used by parking
 * attendants.
 * <p>
 * Responsibilities include:
 * <ul>
 * <li>Searching for subscribers by username</li>
 * <li>Displaying subscriber details in read-only fields</li>
 * <li>Navigation between screens (View Parkings, Add Subscriber)</li>
 * <li>Communicating with the server to fetch subscriber data</li>
 * </ul>
 * </p>
 * This class also maintains a static instance reference to allow server
 * responses to update the GUI directly.
 * 
 * @author bashar
 * @version 1.0
 */
public class AttendantViewSubscriberDetailsController {
	/** Singleton reference for this controller, set during initialization. */
	public static AttendantViewSubscriberDetailsController instance;

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private Button searchBtn;

	@FXML
	private Button clearBtn;

	@FXML
	private Label usernameLabel;

	@FXML
	private Label ServerMsgLabel;

	@FXML
	private TextField usernameOutput;

	@FXML
	private TextField idOutput;

	@FXML
	private TextField subscriberNumberOutput;

	@FXML
	private TextField firstNameOutput;

	@FXML
	private TextField lastNameOutput;

	@FXML
	private TextField phoneNumberOutput;

	@FXML
	private TextField emailOutput;

	@FXML
	private TextField passwordOutput;

	@FXML
	private TextField usernameInput;

	/**
	 * Initializes the controller, binds the logged-in user's name, disables editing
	 * for output fields, and registers the controller in the client.
	 */
	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(User.getInstance().getUsername()); // Set username dynamically if needed
		ServerMsgLabel.setText("");
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setAttendantViewSubscriberDetailsController(this);
		}

		// Set output fields to read-only
		usernameOutput.setEditable(false);
		idOutput.setEditable(false);
		subscriberNumberOutput.setEditable(false);
		firstNameOutput.setEditable(false);
		lastNameOutput.setEditable(false);
		phoneNumberOutput.setEditable(false);
		emailOutput.setEditable(false);
		passwordOutput.setEditable(false);
	}

	/**
	 * Navigates to the "View Parkings" screen.
	 *
	 * @param event triggered by clicking the View Parkings button
	 */
	@FXML
	void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AttendantViewParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Navigates to the "Add New Subscriber" screen.
	 *
	 * @param event triggered by clicking the Add Subscriber button
	 */
	@FXML
	void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AttendantNewSubscriber.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to reload page");
		}
	}

	/**
	 * Reloads the current "View Subscriber Details" screen.
	 *
	 * @param event triggered by clicking the Subscriber Details button
	 */
	@FXML
	void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AttendantViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Logs out the user and returns to the login screen.
	 *
	 * @param event triggered by clicking the Exit button
	 */
	@FXML
	void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	/**
	 * Sends a request to the server to retrieve subscriber details based on the
	 * entered username.
	 *
	 * @param event triggered by clicking the Search button
	 */
	@FXML
	void SearchBtn(ActionEvent event) {
		String username = usernameInput.getText();
		String[] toSend = { "ViewSubscriberDetails", "attendant", username };
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setAttendantViewSubscriberDetailsController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Clears the input and output fields.
	 *
	 * @param event triggered by clicking the Clear button
	 */
	@FXML
	void ClearBtn(ActionEvent event) {
		usernameInput.clear();
		ClearAll();
	}

	/**
	 * Clears all subscriber information fields and server message.
	 */
	private void ClearAll() {
		usernameOutput.clear();
		idOutput.clear();
		subscriberNumberOutput.clear();
		firstNameOutput.clear();
		lastNameOutput.clear();
		phoneNumberOutput.clear();
		emailOutput.clear();
		passwordOutput.clear();
		ServerMsgLabel.setText("");
	}

	/**
	 * Displays subscriber information on the screen.
	 *
	 * @param msg an array of strings from the server response containing subscriber
	 *            info
	 */
	public void DisplaySubscriber(String[] msg) {

		if (msg[10].equals("success")) {
			ServerMsgLabel.setText("");
			usernameOutput.setText(msg[2]);
			idOutput.setText(msg[3]);
			subscriberNumberOutput.setText(msg[4]);
			firstNameOutput.setText(msg[5]);
			lastNameOutput.setText(msg[6]);
			phoneNumberOutput.setText(msg[7]);
			emailOutput.setText(msg[8]);
			passwordOutput.setText(msg[9]);
			return;
		}
		ClearAll();
		ServerMsgLabel.setText(msg[10]);
		ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
	}
}
