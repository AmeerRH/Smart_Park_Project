module BPark_client {
    requires javafx.fxml;
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.base;
    requires java.sql;

    exports client;
    exports commonGUI;

    opens commonGUI to javafx.fxml;
    opens subscriberGUI to javafx.fxml;
    opens attendantGUI to javafx.fxml;
    opens managerGUI to javafx.fxml;
}
