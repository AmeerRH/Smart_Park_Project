package managerGUI;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.time.LocalTime;
import java.io.IOException;
import java.time.LocalDate;

import client.ClientUI;
import client.User;

/**
 * The {@code ManagerViewReportsController} class handles the manager's view of
 * statistical reports in the BPARK parking management system.
 *
 * <p>
 * It supports:
 * </p>
 * <ul>
 * <li>Viewing statistics for order types (new, cancel, extension)</li>
 * <li>Viewing total parked time in a bar chart</li>
 * <li>Sending search requests with date range</li>
 * <li>Navigating between manager screens</li>
 * </ul>
 *
 * <p>
 * The class uses JavaFX components like {@link BarChart}, {@link DatePicker},
 * and {@link Label} to present data and allow user interaction.
 * </p>
 *
 * @author Vaad
 * @version 1.0
 */
public class ManagerViewReportsController {
	public static ManagerViewReportsController instance;

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button addParkingsBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Button viewReportsBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private Button viewUsersBtn;

	@FXML
	private Button searchBtn;

	@FXML
	private Label usernameLabel;

	@FXML
	private Label ServerMsgLabel;

	@FXML
	private DatePicker fromDatePicker;

	@FXML
	private DatePicker toDatePicker;

	@FXML
	private BarChart<String, Number> barChartOrders;

	@FXML
	private BarChart<String, Number> barChartParkedTime;

	@FXML
	private CategoryAxis xAxis;

	@FXML
	private NumberAxis yAxis;

	/**
	 * Initializes the report page with default bar chart setup, clears messages,
	 * and displays the current username.
	 */

	@FXML
	public void initialize() {
		instance = this;
		ServerMsgLabel.setText("");

		// Initialize barChartOrders
		if (barChartOrders != null) {
			barChartOrders.setTitle("Orders Report");
			barChartOrders.getXAxis().setLabel("Orders");
			barChartOrders.getYAxis().setLabel("Count");
			barChartOrders.getData().clear(); // clear any default
		}

		// Initialize barChartParkedTime
		if (barChartParkedTime != null) {
			barChartParkedTime.setTitle("Total Parked Time");
			barChartParkedTime.getXAxis().setLabel("Time Span");
			barChartParkedTime.getYAxis().setLabel("Hours");
			barChartParkedTime.getData().clear();
		}

		// Show user name if available
		if (User.getInstance() != null) {
			usernameLabel.setText(" " + User.getInstance().getUsername());
		}
	}

	/**
	 * Navigates to the View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewParkings.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the View Users page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void ViewUsersBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewUsers.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the New Subscriber registration page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerNewSubscriber.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the Subscriber Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Logs the user out and returns to the Login page.
	 *
	 * @param event the ActionEvent from the button
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Add Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	public void AddParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerAddParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Reloads the current Reports page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	public void ViewReportsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewReports.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Sends a request to the server to fetch reports within the selected date
	 * range.
	 *
	 * @param event the ActionEvent triggered by the Search button
	 */
	@FXML
	public void SearchBtn(ActionEvent event) {
		LocalDate from = fromDatePicker.getValue();
		LocalDate to = toDatePicker.getValue();

		String[] toSend = { "reports", from.toString(), to.toString() };
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerViewReportsController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Displays the statistical reports in two bar charts: one for orders (e.g.,
	 * new, cancel, extensions) and another for total parked time.
	 *
	 * @param msg the message array received from the server, where msg[1..] contain
	 *            key:value pairs
	 */
	public void ShowReports(String[] msg) {
		if (msg == null || msg.length < 2) {
			System.out.println("Invalid report data");
			return;
		}

		Platform.runLater(() -> {
			barChartOrders.getData().clear();
			barChartParkedTime.getData().clear();

			XYChart.Series<String, Number> ordersSeries = new XYChart.Series<>();
			ordersSeries.setName("Orders");

			XYChart.Series<String, Number> timeSeries = new XYChart.Series<>();
			timeSeries.setName("Total Parked Time");

			ObservableList<String> orderCategories = FXCollections.observableArrayList();
			ObservableList<String> timeCategories = FXCollections.observableArrayList();

			for (int i = 1; i < msg.length; i++) {
				String[] parts = msg[i].split(":", 2);
				if (parts.length != 2)
					continue;

				String key = parts[0].trim();
				String valueStr = parts[1].trim();

				try {
					switch (key) {
					case "orders_cnt":
					case "extension_cnt":
					case "cancel_cnt":
					case "new_order_cnt":
						int count = Integer.parseInt(valueStr);
						ordersSeries.getData().add(new XYChart.Data<>(key, count));
						orderCategories.add(key);
						break;

					case "parked_time":
						LocalTime time = LocalTime.parse(valueStr);
						double hours = time.getHour() + time.getMinute() / 60.0;
						String display = String.format("Total [%02d:%02d]", time.getHour(), time.getMinute());
						timeSeries.getData().add(new XYChart.Data<>(display, hours));
						timeCategories.add(display);
						break;

					default:
						break;
					}
				} catch (Exception e) {
					System.out.println("Failed to parse " + key + ": " + e.getMessage());
				}
			}

			// Add categories explicitly to ensure spacing
			if (barChartOrders.getXAxis() instanceof CategoryAxis) {
				CategoryAxis axis = (CategoryAxis) barChartOrders.getXAxis();
				axis.setCategories(orderCategories);
			}
			if (barChartParkedTime.getXAxis() instanceof CategoryAxis) {
				CategoryAxis axis = (CategoryAxis) barChartParkedTime.getXAxis();
				axis.setCategories(timeCategories);
			}

			barChartOrders.getData().add(ordersSeries);
			barChartParkedTime.getData().add(timeSeries);
		});
	}

}
