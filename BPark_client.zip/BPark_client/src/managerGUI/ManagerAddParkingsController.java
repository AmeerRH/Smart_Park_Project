package managerGUI;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.ClientUI;
import client.User;

/**
 * The {@code ManagerAddParkingsController} class manages the GUI for adding new
 * parking spots in the BPARK management system. It allows the manager to
 * navigate to different views, specify the number of new parkings to add, and
 * send this request to the server.
 *
 * <p>
 * Main responsibilities:
 * </p>
 * <ul>
 * <li>Handles navigation buttons to other manager views</li>
 * <li>Captures user input for number of new parking spots</li>
 * <li>Sends "AddParkings" requests to the server</li>
 * <li>Displays server confirmation or error messages</li>
 * </ul>
 *
 * @author Vaad
 * @version 1.0
 */
public class ManagerAddParkingsController implements Initializable {

	public static ManagerAddParkingsController instance;

	@FXML
	private Label usernameLabel;

	@FXML
	private Label ServerMsgLabel;

	@FXML
	private Spinner<Integer> numberInput;

	@FXML
	private Button addParkingsBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button newAttendandBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Button viewReportsBtn;

	@FXML
	private Button viewUsersBtn;

	/**
	 * Initializes the controller. Sets up the spinner for selecting the number of
	 * parkings and resets messages.
	 *
	 * @param location  The location used to resolve relative paths
	 * @param resources The resources used to localize the root object
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// Initialize the spinner with a range from 1 to 100 and default value 1
		SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 1);
		numberInput.setValueFactory(valueFactory);
		ServerMsgLabel.setText("");
		instance = this;
	}

	/**
	 * Navigates to the ManagerViewParkings screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewParkings.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the ManagerNewSubscriber screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerNewSubscriber.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the ManagerViewUsers screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void ViewUsersBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewUsers.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the ManagerViewSubscriberDetails screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Logs out the manager and returns to the Login page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	/**
	 * Reloads the ManagerAddParkings screen (refresh).
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	public void AddParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerAddParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Navigates to the ManagerViewReports screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	public void ViewReportsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewReports.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Sends the AddParkings request to the server with the selected number.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	public void AddParkingsToSystemBtn(ActionEvent event) {
		int num = numberInput.getValue();
		String[] toSend = new String[2];
		toSend[0] = "AddParkings";
		toSend[1] = String.valueOf(num);
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerAddParkingsController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Displays a message from the server in the GUI. Colors the text green if it
	 * indicates success, red otherwise.
	 *
	 * @param msg the message to display
	 */
	public void ShowMsg(String msg) {
		ServerMsgLabel.setText(msg);

		if (msg.toLowerCase().contains("successfully")) {
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		} else {
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
		}
	}
}
