package managerGUI;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.io.IOException;

import client.ClientUI;
import client.User;

/**
 * The {@code ManagerViewUsersController} class manages the GUI for viewing user
 * activity reports in the BPARK system.
 *
 * <p>
 * Main responsibilities include:
 * </p>
 * <ul>
 * <li>Displaying a bar chart of active vs. inactive users</li>
 * <li>Requesting user data from the server</li>
 * <li>Providing navigation between manager screens</li>
 * </ul>
 *
 * <p>
 * This controller uses JavaFX {@link BarChart}, {@link Button}, and
 * {@link Label} to enable interactive data visualization and navigation.
 * </p>
 *
 * @author Waad
 * @version 1.0
 */
public class ManagerViewUsersController {

	public static ManagerViewUsersController instance;

	@FXML
	private Label usernameLabel;

	@FXML
	private Label ServerMsgLabel;

	@FXML
	private BarChart<String, Number> barChartUsers;

	@FXML
	private CategoryAxis categoryAxis;

	@FXML
	private Button viewParkingsBtn, newSubscriberBtn, addParkingsBtn, subscriberDetailsBtn, viewReportsBtn,
			viewUsersBtn, exitBtn;

	/**
	 * Initializes the controller, sets up the bar chart categories, requests user
	 * data from the server, and configures UI labels.
	 */
	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(User.getInstance().getUsername()); // example existing code
		ServerMsgLabel.setText("");

		if (barChartUsers != null) {
			barChartUsers.setTitle("Users");

			// Set categories explicitly:
			categoryAxis.setCategories(FXCollections.observableArrayList("Active Users", "Fozen Users"));
			categoryAxis.setLabel("User Status");
		}
		// Request data from server if needed
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerViewUsersController(this);
			String[] toSend = { "viewUsersFromDB" };
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Navigates to the View Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewParkings.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the New Subscriber registration page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerNewSubscriber.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Reloads the current View Users page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ViewUsersBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewUsers.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the Subscriber Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Logs out the current user and returns to the login screen.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Add Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	public void AddParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerAddParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Navigates to the Reports page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	public void ViewReportsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewReports.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Populates the bar chart with the number of active and inactive users.
	 *
	 * <p>
	 * This method is called after receiving a response from the server. It clears
	 * the existing chart, creates a new data series, and applies a custom color
	 * style.
	 * </p>
	 *
	 * @param msg a string array where:
	 *            <ul>
	 *            <li>msg[1] = number of active users</li>
	 *            <li>msg[2] = number of inactive users</li>
	 *            </ul>
	 */

	public void ShowUsers(String[] msg) {
		if (msg == null || msg.length < 3) {
			System.out.println("Invalid input array");
			return;
		}

		Platform.runLater(() -> {
			barChartUsers.getData().clear();
			XYChart.Series<String, Number> series = new XYChart.Series<>();
			series.setName("User Activity");

			try {
				int active = Integer.parseInt(msg[1].trim());
				int inactive = Integer.parseInt(msg[2].trim());

				series.getData().add(new XYChart.Data<>("Active Users", active));
				series.getData().add(new XYChart.Data<>("Inactive Users", inactive));

				barChartUsers.getData().add(series);

				for (XYChart.Data<String, Number> data : series.getData()) {
					if (data.getNode() != null) {
						data.getNode().setStyle("-fx-bar-fill: #3F2B63;");
					} else {
						data.nodeProperty().addListener((obs, oldNode, newNode) -> {
							if (newNode != null) {
								newNode.setStyle("-fx-bar-fill: #3F2B63;");
							}
						});
					}
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid number format in input: " + e.getMessage());
			}
		});
	}
}
