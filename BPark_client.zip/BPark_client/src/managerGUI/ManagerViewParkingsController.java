package managerGUI;

import java.io.IOException;

import client.ClientUI;
import client.Parking;
import client.User;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * The {@code ManagerViewParkingsController} class controls the manager's View
 * Parkings page in the BPARK system.
 *
 * <p>
 * Main responsibilities:
 * </p>
 * <ul>
 * <li>Displays parking data (available and taken)</li>
 * <li>Requests data refresh from the server</li>
 * <li>Handles navigation to other manager pages</li>
 * <li>Manages auto-refresh functionality</li>
 * </ul>
 *
 * @author waad
 * @version 1.0
 */

public class ManagerViewParkingsController {

	public static ManagerViewParkingsController instance;

	@FXML
	private Label usernameLabel;

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private Button addParkingsBtn;

	@FXML
	private Button viewReportsBtn;

	@FXML
	private Button newAttendandBtn;

	@FXML
	private Button viewUsersBtn;

	@FXML
	private TableView<Parking> dataTable;

	@FXML
	private TableColumn<Parking, String> parkingNumberCol;

	@FXML
	private TableColumn<Parking, String> statusCol;

	@FXML
	private TableColumn<Parking, String> IDCol;

	@FXML
	private TableColumn<Parking, String> orderNumberCol;

	@FXML
	private TableColumn<Parking, String> takenUntilCol;

	@FXML
	private TableColumn<Parking, String> takenFromCol;

	@FXML
	private Label ServerMsgLabel;

	private ObservableList<Parking> parkingData = FXCollections.observableArrayList();

	/**
	 * Initializes the controller by setting up the table, configuring the username
	 * label, and starting auto-refresh.
	 */

	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(User.getInstance().getUsername()); // Set username dynamically if needed
		setupTable();
		ServerMsgLabel.setText("");

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerViewParkingsController(this);
			refreshParkings(); // First load
			startAutoRefresh(); // Start periodic auto-refresh
		}
	}

	/**
	 * Starts a Timeline to automatically refresh parking data every 10 seconds.
	 */

	private void startAutoRefresh() {
		Timeline refreshTimeline = new Timeline(new KeyFrame(Duration.seconds(10), event -> {
			refreshParkings();
		}));
		refreshTimeline.setCycleCount(Animation.INDEFINITE);
		refreshTimeline.play();
	}

	/**
	 * Sends a request to the server to fetch updated parking data.
	 */
	private void refreshParkings() {
		String[] toSend = { "viewParkings", "manager" };
		ClientUI.bParkClient.requestFromServer(toSend);
	}

	/**
	 * Navigates to the ManagerViewUsers screen.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void ViewUsersBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewUsers.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Configures the TableView columns to match Parking object properties.
	 */
	private void setupTable() {
		parkingNumberCol.setCellValueFactory(new PropertyValueFactory<>("parkingNumber"));
		statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
		IDCol.setCellValueFactory(new PropertyValueFactory<>("ownerID"));
		orderNumberCol.setCellValueFactory(new PropertyValueFactory<>("orderNumber"));
		takenFromCol.setCellValueFactory(new PropertyValueFactory<>("takenFrom"));
		takenUntilCol.setCellValueFactory(new PropertyValueFactory<>("takenUntil"));
	}

	/**
	 * Requests to refresh parking data from the server manually.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		String[] toSend = { "viewParkings" };
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerViewParkingsController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Navigates to the ManagerNewSubscriber screen.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerNewSubscriber.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the ManagerViewSubscriberDetails screen.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Logs the user out and returns to the Login page.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the ManagerAddParkings screen.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	public void AddParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerAddParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Navigates to the ManagerViewReports screen.
	 *
	 * @param event the ActionEvent from the button
	 */

	@FXML
	public void ViewReportsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewReports.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Receives parking data from the server and updates the TableView.
	 *
	 * @param msgAvailable available parking spots as a delimited String
	 * @param msgTaken     taken parking spots as a delimited String
	 */
	public void DisplayParkings(String msgAvailable, String msgTaken) {
		Platform.runLater(() -> {
			TakenParkings(msgTaken);
			AvailableParkings(msgAvailable);
		});
	}

	/**
	 * Parses and displays taken parking data.
	 *
	 * @param msgTaken delimited String containing taken parking info
	 */

	private void TakenParkings(String msgTaken) {
		parkingData.clear(); // Clear previous data

		if (msgTaken == null || msgTaken.isEmpty())
			return;

		String[] records = msgTaken.split("\\|");
		for (String record : records) {
			String[] fields = record.split(";");
			Parking parking = new Parking(getField(fields, 0), // parkingNumber
					getField(fields, 1), // status
					getField(fields, 2), // ownerID
					getField(fields, 3), // orderNumber
					getField(fields, 5), // takenFrom
					getField(fields, 4) // takenUntil
			);
			parkingData.add(parking);
		}

		dataTable.setItems(parkingData);
	}

	/**
	 * Safely retrieves a field from the split array.
	 *
	 * @param fields the split record array
	 * @param index  the index to retrieve
	 * @return the field value or empty string if out of bounds
	 */

	private void AvailableParkings(String msgAvailable) {
		if (msgAvailable == null || msgAvailable.isEmpty())
			return;

		String[] records = msgAvailable.split("\\|");
		for (String record : records) {
			String[] fields = record.split(";");
			Parking parking = new Parking(getField(fields, 0), // parkingNumber
					getField(fields, 1), // status
					"", // ownerID
					"", // orderNumber
					"", // takenUntil
					"" // takenFrom
			);
			parkingData.add(parking);
		}

		dataTable.setItems(parkingData);
	}

	private String getField(String[] fields, int index) {
		return (index < fields.length && fields[index] != null) ? fields[index] : "";
	}
}
