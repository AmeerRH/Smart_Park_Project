package managerGUI;

import java.io.IOException;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * The {@code ManagerViewSubscriberDetailsController} class manages the GUI for
 * viewing and searching subscriber details in the BPARK system.
 *
 * <p>
 * Main features include:
 * </p>
 * <ul>
 * <li>Searching for subscriber information by username</li>
 * <li>Displaying subscriber details in read-only fields</li>
 * <li>Navigating between manager pages</li>
 * <li>Clearing input/output fields</li>
 * </ul>
 *
 * <p>
 * This controller uses JavaFX {@link TextField}, {@link Button}, and
 * {@link Label} to enable manager interactions.
 * </p>
 *
 * @author Vaad
 * @version 1.0
 */
public class ManagerViewSubscriberDetailsController {

	public static ManagerViewSubscriberDetailsController instance;

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Button addParkingsBtn;

	@FXML
	private Button viewReportsBtn;

	@FXML
	private Button newAttendandBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private Button searchBtn;

	@FXML
	private Button clearBtn;

	@FXML
	private Button viewUsersBtn;

	@FXML
	private Label usernameLabel;

	@FXML
	private Label ServerMsgLabel;

	@FXML
	private TextField usernameOutput;

	@FXML
	private TextField idOutput;

	@FXML
	private TextField subscriberNumberOutput;

	@FXML
	private TextField firstNameOutput;

	@FXML
	private TextField lastNameOutput;

	@FXML
	private TextField phoneNumberOutput;

	@FXML
	private TextField emailOutput;

	@FXML
	private TextField passwordOutput;

	@FXML
	private TextField usernameInput;

	/**
	 * Initializes the subscriber details page, disables editing for output fields,
	 * and sets up the controller reference.
	 */

	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(User.getInstance().getUsername()); // Set username dynamically if needed
		ServerMsgLabel.setText("");
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerViewSubscriberDetailsController(this);
		}

		// Disable editing for output fields
		usernameOutput.setEditable(false);
		idOutput.setEditable(false);
		subscriberNumberOutput.setEditable(false);
		firstNameOutput.setEditable(false);
		lastNameOutput.setEditable(false);
		phoneNumberOutput.setEditable(false);
		emailOutput.setEditable(false);
		passwordOutput.setEditable(false);
	}

	/**
	 * Initializes the subscriber details page, disables editing for output fields,
	 * and sets up the controller reference.
	 */

	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewParkings.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the View Users page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void ViewUsersBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewUsers.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the New Subscriber registration page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerNewSubscriber.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Reloads the current Subscriber Details page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	private void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Logs out the current user and navigates back to the Login page.
	 *
	 * @param event the ActionEvent triggered by the Exit button
	 */
	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the Add Parkings page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */

	@FXML
	public void AddParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerAddParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Navigates to the Reports page.
	 *
	 * @param event the ActionEvent triggered by the button
	 */
	@FXML
	public void ViewReportsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewReports.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Sends a request to the server to fetch subscriber details for the entered
	 * username.
	 *
	 * @param event the ActionEvent triggered by the Search button
	 */
	@FXML
	void SearchBtn(ActionEvent event) {
		String username = usernameInput.getText();
		String[] toSend = { "ViewSubscriberDetails", "manager", username };
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerViewSubscriberDetailsController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}
	}

	/**
	 * Clears all input and output fields on the screen.
	 *
	 * @param event the ActionEvent triggered by the Clear button
	 */
	@FXML
	void ClearBtn(ActionEvent event) {
		usernameInput.clear();
		ClearAll();
	}

	private void ClearAll() {
		usernameOutput.clear();
		idOutput.clear();
		subscriberNumberOutput.clear();
		firstNameOutput.clear();
		lastNameOutput.clear();
		phoneNumberOutput.clear();
		emailOutput.clear();
		passwordOutput.clear();
		ServerMsgLabel.setText("");
	}

	/**
	 * Displays the subscriber details received from the server in the GUI.
	 *
	 * @param msg the array of subscriber details, including a success or error
	 *            message
	 */
	public void DisplaySubscriber(String[] msg) {

		if (msg[10].equals("success")) {
			ServerMsgLabel.setText("");
			usernameOutput.setText(msg[2]);
			idOutput.setText(msg[3]);
			subscriberNumberOutput.setText(msg[4]);
			firstNameOutput.setText(msg[5]);
			lastNameOutput.setText(msg[6]);
			phoneNumberOutput.setText(msg[7]);
			emailOutput.setText(msg[8]);
			passwordOutput.setText(msg[9]);
			return;
		}
		ClearAll();
		ServerMsgLabel.setText(msg[10]);
		ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
	}
}
