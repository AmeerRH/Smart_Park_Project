package managerGUI;

import java.io.IOException;

import client.ClientUI;
import client.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * The {@code ManagerNewSubscriberController} class manages the GUI for adding
 * new subscribers or attendants in the BPARK system.
 *
 * <p>
 * Main responsibilities:
 * </p>
 * <ul>
 * <li>Collects user input for new accounts</li>
 * <li>Validates input and sends add requests to the server</li>
 * <li>Handles navigation between manager views</li>
 * <li>Displays server responses as messages to the user</li>
 * </ul>
 *
 * @author waad
 * @version 1.0
 */
public class ManagerNewSubscriberController {

	public static ManagerNewSubscriberController instance;

	@FXML
	private Button viewParkingsBtn;

	@FXML
	private Button newSubscriberBtn;

	@FXML
	private Button subscriberDetailsBtn;

	@FXML
	private Label usernameLabel;

	@FXML
	private Button exitBtn;

	@FXML
	private Button addParkingsBtn;

	@FXML
	private Button viewReportsBtn;

	@FXML
	private Button newAttendandBtn;

	@FXML
	private Button viewUsersBtn;

	@FXML
	private TextField usernameInput;

	@FXML
	private TextField firstNameInput;

	@FXML
	private TextField lasNameInput;

	@FXML
	private TextField idInput;

	@FXML
	private TextField phoneNumberInput;

	@FXML
	private TextField emailInput;

	@FXML
	private TextField passwordInput;

	@FXML
	private Button addNewBtn;

	@FXML
	private Button clearBtn;

	@FXML
	private Label ServerMsgLabel;

	@FXML
	private CheckBox subscriberCheckBox;

	@FXML
	private CheckBox attendantCheckBox;

	/**
	 * Initializes the controller. Sets username label and clears the server message
	 * label.
	 */
	@FXML
	public void initialize() {
		instance = this;
		usernameLabel.setText(User.getInstance().getUsername()); // Set username dynamically if needed
		ServerMsgLabel.setText("");
		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerNewSubscriberController(this);
		}
	}

	/**
	 * Navigates to the ManagerViewParkings screen.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void ViewParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewParkings.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Reloads the ManagerNewSubscriber screen.
	 *
	 * @param event the ActionEvent from the button
	 */

	@FXML
	private void NewSubscriberBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerNewSubscriber.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the ManagerViewUsers screen.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void ViewUsersBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewUsers.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) viewParkingsBtn.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to load View Parkings screen.");
		}
	}

	/**
	 * Navigates to the ManagerViewSubscriberDetails screen.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void SubscriberDetailsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewSubscriberDetails.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Logs the user out and returns to the Login page.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	private void ExitBtn(ActionEvent event) {
		User.getInstance().clear();
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/commonGUI/LoginPageGUI.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Display Orders Page");
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error loading Connect Page: " + e.getMessage());
		}
	}

	/**
	 * Navigates to the ManagerAddParkings screen.
	 *
	 * @param event the ActionEvent from the button
	 */

	@FXML
	public void AddParkingsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerAddParkings.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Navigates to the ManagerViewReports screen.
	 *
	 * @param event the ActionEvent from the button
	 */
	@FXML
	public void ViewReportsBtn(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerViewReports.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			ServerMsgLabel.setText("Failed to open View Parkings page");
		}
	}

	/**
	 * Validates and sends the request to add a new subscriber or attendant to the
	 * server.
	 *
	 * @param event the ActionEvent from the Add button
	 */
	@FXML
	void AddNewBtn(ActionEvent event) {
		String username = usernameInput.getText();
		String type;
		String firstName = firstNameInput.getText();
		String lastName = lasNameInput.getText();
		String id = idInput.getText();
		String phone = phoneNumberInput.getText();
		String email = emailInput.getText();
		String password = passwordInput.getText();

		if (attendantCheckBox.isSelected()) {
			type = "attendant";
		} else if (subscriberCheckBox.isSelected()) {
			type = "subscriber";
		} else {
			ServerMsgLabel.setText("Please choose the type of the user.");
			return;
		}

		if (username.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || id.isEmpty() || phone.isEmpty()
				|| email.isEmpty() || password.isEmpty()) {
			ServerMsgLabel.setText("Please fill in all fields.");
			return;
		}

		String[] toSend = { "addNewSubscriber", username, firstName, lastName, id, phone, email, password, "manager",
				type };

		if (ClientUI.bParkClient != null) {
			ClientUI.bParkClient.setManagerNewSubscriberController(this);
			ClientUI.bParkClient.requestFromServer(toSend);
		}

	}

	/**
	 * Clears all input fields and resets the message label.
	 *
	 * @param event the ActionEvent from the Clear button
	 */
	@FXML
	void ClearBtn(ActionEvent event) {
		usernameInput.clear();
		firstNameInput.clear();
		lasNameInput.clear();
		idInput.clear();
		phoneNumberInput.clear();
		emailInput.clear();
		passwordInput.clear();
		ServerMsgLabel.setText("All fields cleared.");
	}

	/**
	 * Displays the server's response message in the label. Colors the text green on
	 * success, red on failure.
	 *
	 * @param msg the message from the server
	 */
	public void ShowMsg(String msg) {
		ServerMsgLabel.setText(msg);
		if (msg.toLowerCase().contains("successfully")) {
			ServerMsgLabel.setStyle("-fx-text-fill: #228B22;");
		} else {
			ServerMsgLabel.setStyle("-fx-text-fill: #DC143C;");
		}
	}

	/**
	 * Sets the subscriber checkbox selected and unselects the attendant checkbox.
	 *
	 * @param event the ActionEvent from the checkbox
	 */
	public void SubscriberCheckBox(ActionEvent event) {
		subscriberCheckBox.setSelected(true);
		attendantCheckBox.setSelected(false);
	}

	/**
	 * Sets the attendant checkbox selected and unselects the subscriber checkbox.
	 *
	 * @param event the ActionEvent from the checkbox
	 */
	public void AttendantCheckBox(ActionEvent event) {
		subscriberCheckBox.setSelected(false);
		attendantCheckBox.setSelected(true);
	}
}
